/**
 * A very small client-side router.
 *
 * The whole hub is one page — moving between the landing page, a game's setup
 * screen, the lobby and the board never reloads. Routes are real paths (the
 * server falls back to index.html) so a room link can be shared and deep-linked.
 *
 *   /                 the hub
 *   /g/:gameId        player count + mode, then create
 *   /join             join by code (optionally ?code=ABC12)
 *   /r/:code          a room — lobby or game, whichever it's in
 */

const routes = [];
let notFound = null;
/** Run before every navigation — used to tear down body-level overlays. */
const navigationListeners = new Set();
/** Called before leaving the current route; may cancel navigation. */
let leaveGuard = null;

/** Register a route. `pattern` uses :params, e.g. '/r/:code'. */
export function route(pattern, handler) {
  const names = [];
  const regex = new RegExp(
    `^${pattern.replace(/:[^/]+/g, (match) => {
      names.push(match.slice(1));
      return '([^/]+)';
    })}/?$`,
  );
  routes.push({ regex, names, handler });
}

export function setNotFound(handler) {
  notFound = handler;
}

/**
 * Register a cleanup to run before each navigation.
 *
 * Screens live inside #app and are replaced wholesale, but modals and toasts
 * are attached to document.body so they can sit above everything. Without this
 * they would survive a route change and hang over the next screen.
 */
export function onNavigate(fn) {
  navigationListeners.add(fn);
  return () => navigationListeners.delete(fn);
}

/**
 * Ask to be consulted before the next navigation.
 * Used by the game screen to confirm before abandoning a game in progress.
 */
export function setLeaveGuard(guard) {
  leaveGuard = guard;
}

export function clearLeaveGuard() {
  leaveGuard = null;
}

/** Navigate, running any leave guard first. */
export async function go(path, { replace = false, force = false } = {}) {
  if (leaveGuard && !force) {
    const allowed = await leaveGuard(path);
    if (!allowed) return false;
  }
  leaveGuard = null;

  if (replace) history.replaceState({}, '', path);
  else history.pushState({}, '', path);

  await resolve();
  return true;
}

/** Match the current URL and run its handler. */
export async function resolve() {
  for (const listener of navigationListeners) listener();

  const path = location.pathname.replace(/\/+$/, '') || '/';

  for (const { regex, names, handler } of routes) {
    const match = path.match(regex);
    if (!match) continue;

    const params = Object.fromEntries(names.map((name, i) => [name, decodeURIComponent(match[i + 1])]));
    const query = Object.fromEntries(new URLSearchParams(location.search));
    await handler({ params, query, path });
    return;
  }

  if (notFound) await notFound({ path });
}

export function start() {
  // Back/forward should re-render, but must not re-run a leave guard.
  window.addEventListener('popstate', () => {
    leaveGuard = null;
    resolve();
  });

  // Intercept in-app links so they route instead of reloading the page.
  document.addEventListener('click', (event) => {
    const link = event.target.closest('a[data-link]');
    if (!link) return;
    event.preventDefault();
    go(link.getAttribute('href'));
  });

  resolve();
}
