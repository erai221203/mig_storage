/**
 * Confetti, sound and floating reactions — shared by every game.
 *
 * Sound is synthesised with the Web Audio API rather than loaded from files,
 * so there are no assets to ship and nothing to wait on.
 */

import { el, $ } from './ui.js';

/* ── Sound ───────────────────────────────────────────────────────────────── */

const MUTE_KEY = 'game-night.muted';

export const sound = {
  muted: localStorage.getItem(MUTE_KEY) === 'true',
  _context: null,

  /** Browsers only allow audio after a gesture, so build the context lazily. */
  _ctx() {
    if (!this._context) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return null;
      this._context = new AudioContextClass();
    }
    if (this._context.state === 'suspended') this._context.resume();
    return this._context;
  },

  unlock() {
    if (!this.muted) this._ctx();
  },

  toggleMute() {
    this.muted = !this.muted;
    localStorage.setItem(MUTE_KEY, String(this.muted));
    if (!this.muted) this._ctx();
    return this.muted;
  },

  _note(freq, { delay = 0, duration = 0.5, gain = 0.13, type = 'sine', slideTo = null } = {}) {
    const ctx = this._ctx();
    if (!ctx) return;

    const start = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const env = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, start);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, start + duration);

    env.gain.setValueAtTime(0, start);
    env.gain.linearRampToValueAtTime(gain, start + 0.015);
    env.gain.exponentialRampToValueAtTime(0.0001, start + duration);

    osc.connect(env).connect(ctx.destination);
    osc.start(start);
    osc.stop(start + duration + 0.05);
  },

  /** A quick rattle for the dice. */
  dice() {
    if (this.muted) return;
    for (let i = 0; i < 4; i++) {
      this._note(180 + Math.random() * 120, {
        delay: i * 0.055,
        duration: 0.07,
        gain: 0.07,
        type: 'square',
      });
    }
  },

  /** A little hop per square. */
  hop() {
    if (this.muted) return;
    this._note(620, { duration: 0.09, gain: 0.05, type: 'triangle' });
  },

  /** Climbing a ladder: a cheerful rising run. */
  ladder() {
    if (this.muted) return;
    [523, 659, 784, 1046].forEach((f, i) =>
      this._note(f, { delay: i * 0.07, duration: 0.28, gain: 0.1 }),
    );
  },

  /** Sliding down a snake: a comic descending whoop. */
  snake() {
    if (this.muted) return;
    this._note(700, { duration: 0.6, gain: 0.12, type: 'sawtooth', slideTo: 150 });
  },

  win() {
    if (this.muted) return;
    [523, 659, 784, 1046, 1318].forEach((f, i) =>
      this._note(f, { delay: i * 0.1, duration: 0.9, gain: 0.13 }),
    );
  },

  nope() {
    if (this.muted) return;
    this._note(300, { duration: 0.22, gain: 0.1, type: 'triangle' });
    this._note(240, { delay: 0.1, duration: 0.3, gain: 0.1, type: 'triangle' });
  },
};

/* ── Confetti ────────────────────────────────────────────────────────────── */

const canvas = $('#confetti');
const ctx = canvas.getContext('2d');
const COLORS = ['#e17f7f', '#dac262', '#62da92', '#62c2da', '#a2a2ec', '#e17fcd', '#e8b44f'];

let particles = [];
let handle = null;

function resize() {
  const ratio = window.devicePixelRatio || 1;
  canvas.width = window.innerWidth * ratio;
  canvas.height = window.innerHeight * ratio;
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
}
resize();
window.addEventListener('resize', resize);

function spawn(count) {
  const width = window.innerWidth;
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * width,
      y: -20 - Math.random() * window.innerHeight * 0.4,
      w: 6 + Math.random() * 6,
      h: 9 + Math.random() * 8,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      vy: 1.6 + Math.random() * 2.6,
      vx: -0.9 + Math.random() * 1.8,
      spin: -0.12 + Math.random() * 0.24,
      angle: Math.random() * Math.PI * 2,
      sway: Math.random() * Math.PI * 2,
      swaySpeed: 0.02 + Math.random() * 0.03,
    });
  }
}

function frame() {
  ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
  const floor = window.innerHeight + 40;

  particles = particles.filter((p) => {
    p.sway += p.swaySpeed;
    p.x += p.vx + Math.sin(p.sway) * 0.9;
    p.y += p.vy;
    p.angle += p.spin;

    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.angle);
    ctx.fillStyle = p.color;
    ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
    ctx.restore();

    return p.y < floor;
  });

  if (particles.length > 0) {
    handle = requestAnimationFrame(frame);
  } else {
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    handle = null;
  }
}

export const confetti = {
  celebrate() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    spawn(90);
    setTimeout(() => spawn(60), 500);
    if (!handle) handle = requestAnimationFrame(frame);
  },
  stop() {
    particles = [];
    if (handle) cancelAnimationFrame(handle);
    handle = null;
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
  },
};

/* ── Floating reactions ──────────────────────────────────────────────────── */

export function floatReaction(emoji, name) {
  const stage = $('#reaction-stage');
  // Cap what's on screen: with 15 players this could otherwise pile up.
  if (stage.children.length > 12) stage.firstElementChild?.remove();

  const node = el(
    'div',
    { class: 'floater', style: { left: `${8 + Math.random() * 58}%` } },
    el('div', { class: 'floater-emoji', text: emoji }),
    el('div', { class: 'floater-name', text: name }),
  );
  stage.appendChild(node);
  node.addEventListener('animationend', () => node.remove(), { once: true });
}
