/**
 * Socket plumbing plus the small amount of identity kept in the browser.
 *
 * Each game has its own Socket.IO namespace, so `connectGame('snake-and-ladder')`
 * gives you an isolated socket for that game and nothing else.
 *
 * The session (room code + member id) lives in sessionStorage rather than
 * localStorage on purpose: it survives a refresh, but each browser tab is its
 * own player — exactly what you want when testing 15 players on one machine.
 */

/* global io */

const SESSION_KEY = 'game-night.session';

/** namespace → socket, so re-entering a game reuses its connection. */
const sockets = new Map();

export function connectGame(gameId) {
  if (sockets.has(gameId)) return sockets.get(gameId);

  const socket = io(`/${gameId}`, {
    transports: ['websocket', 'polling'],
    reconnectionDelay: 400,
    reconnectionDelayMax: 3000,
  });
  sockets.set(gameId, socket);
  return socket;
}

/**
 * Resolve once the socket is connected, or after `timeout` either way.
 * A freshly created socket needs a moment, and the first thing a player does
 * is usually press a button — so we wait rather than refusing the action.
 */
export function whenConnected(socket, timeout = 5000) {
  if (socket.connected) return Promise.resolve(true);
  return new Promise((resolve) => {
    const done = (result) => {
      clearTimeout(timer);
      socket.off('connect', onConnect);
      resolve(result);
    };
    const onConnect = () => done(true);
    const timer = setTimeout(() => done(false), timeout);
    socket.once('connect', onConnect);
  });
}

/**
 * Emit and resolve with the server's acknowledgement.
 * Every action goes through here so a failure always comes back as something
 * we can show the player rather than vanishing.
 */
export async function send(socket, event, payload = {}) {
  const ready = await whenConnected(socket);
  if (!ready) {
    return { ok: false, message: 'Still connecting — one moment…' };
  }

  return new Promise((resolve) => {
    const timer = setTimeout(
      () => resolve({ ok: false, message: 'The server is not responding.' }),
      8000,
    );
    socket.emit(event, payload, (response) => {
      clearTimeout(timer);
      resolve(response ?? { ok: false, message: 'No response from the server.' });
    });
  });
}

export function saveSession(session) {
  try {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch {
    /* private browsing — the game still works, refreshes just won't restore */
  }
}

export function loadSession() {
  try {
    return JSON.parse(sessionStorage.getItem(SESSION_KEY) ?? 'null');
  } catch {
    return null;
  }
}

export function clearSession() {
  try {
    sessionStorage.removeItem(SESSION_KEY);
  } catch {
    /* ignore */
  }
}

/** Remember the display name so the join form can prefill it next time. */
export function rememberName(name) {
  try {
    localStorage.setItem('game-night.name', name);
  } catch {
    /* ignore */
  }
}

export function lastName() {
  try {
    return localStorage.getItem('game-night.name') ?? '';
  } catch {
    return '';
  }
}

/** Small fetch helper that never throws — callers get null on failure. */
export async function getJSON(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  }
}
