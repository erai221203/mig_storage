/**
 * Application entry point and route table.
 *
 * The hub owns the routes; each game exports a `mount()` that takes over the
 * #app element for a room. Adding a game means adding one line to GAME_MOUNTS
 * below (plus its registry entry on the server).
 */

import { route, setNotFound, start, go, onNavigate } from './router.js';
import { getJSON } from './net.js';
import { $, toast, dismissOverlays } from './ui.js';
import { sound } from './effects.js';

import { renderLanding, renderSetup, renderJoin, renderMissing } from '../landing/landing.js';

/** id → dynamic import of that game's client entry. */
const GAME_MOUNTS = {
  'snake-and-ladder': () => import('../games/snake-and-ladder/snl.js'),
  bingo: () => import('../games/bingo/bingo.js'),
  'tic-tac-toe': () => import('../games/tic-tac-toe/tic-tac-toe.js'),
  ludo: () => import('../games/ludo/ludo.js'),
  chess: () => import('../games/chess/chess.js'),
};

/** Catalogue, fetched once and reused by every screen. */
export const hub = { games: [], limits: {}, loaded: false };

async function loadHub() {
  if (hub.loaded) return hub;
  const data = await getJSON('/api/games');
  if (data) {
    hub.games = data.games;
    hub.limits = data.limits;
    hub.tokenColors = data.tokenColors;
  }
  hub.loaded = true;
  return hub;
}

const app = () => $('#app');

// ── routes ─────────────────────────────────────────────────────────────────

route('/', async () => {
  await loadHub();
  renderLanding(app(), hub);
});

route('/g/:gameId', async ({ params }) => {
  await loadHub();
  const game = hub.games.find((g) => g.id === params.gameId);

  if (!game) return renderMissing(app(), 'We could not find that game.');
  if (game.status !== 'live') {
    return renderMissing(app(), `${game.title} isn't ready yet — but it's on the way!`);
  }
  renderSetup(app(), game);
});

route('/join', async ({ query }) => {
  await loadHub();
  renderJoin(app(), hub, query.code ?? '');
});

/**
 * A room. Codes are unique hub-wide, so we ask the server which game this
 * belongs to and hand off to that game's client — the player never needs to
 * know which game a code was for.
 */
route('/r/:code', async ({ params, query }) => {
  const code = params.code.toUpperCase();
  const info = await getJSON(`/api/rooms/${code}`);

  if (!info) {
    await loadHub();
    renderJoin(app(), hub, code, `No room called "${code}" — double-check the code? 🤔`);
    return;
  }

  const load = GAME_MOUNTS[info.gameId];
  if (!load) {
    renderMissing(app(), 'That game is not available in this build.');
    return;
  }

  const module = await load();
  await module.mount({
    root: app(),
    code,
    gameId: info.gameId,
    /** Set when arriving straight from the setup screen. */
    intent: query.new === '1' ? 'created' : 'join',
    name: query.name ?? '',
  });
});

setNotFound(async ({ path }) => {
  await loadHub();
  renderMissing(app(), `Nothing lives at ${path}.`);
});

// ── boot ───────────────────────────────────────────────────────────────────

// Modals live on document.body so they can sit above the board, which also
// means the router won't sweep them away when it swaps #app. Close them on
// every navigation so one can never hang over the next screen.
onNavigate(dismissOverlays);

// Browsers need a gesture before audio can play; use the first one we get.
document.addEventListener('click', () => sound.unlock(), { once: true });

window.addEventListener('unhandledrejection', (event) => {
  console.error('[hub] unhandled rejection:', event.reason);
  toast('Something went wrong. Try again?', 'is-warn');
});

start();

export { go };
