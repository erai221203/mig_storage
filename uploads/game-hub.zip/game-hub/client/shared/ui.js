/**
 * Shared UI helpers: DOM building, toasts, confirm dialogs, and the reusable
 * lobby / chat / reactions components every game in the hub can drop in.
 *
 * User-supplied text (names, chat) is always set with textContent, never
 * innerHTML.
 */

import { go } from './router.js';

export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

/**
 * Apply inline styles, routing CSS custom properties through setProperty().
 * Assigning them onto `element.style` looks like it works but is silently
 * ignored by the browser — which would quietly drop every token colour.
 */
function setStyles(node, styles) {
  for (const [property, value] of Object.entries(styles ?? {})) {
    if (property.startsWith('--')) node.style.setProperty(property, value);
    else node.style[property] = value;
  }
}

/**
 * Tiny element builder: el('div', { class: 'x' }, child, 'text')
 * `attrs` may be null when an element only has children.
 */
export function el(tag, attrs, ...children) {
  const node = document.createElement(tag);

  for (const [key, value] of Object.entries(attrs ?? {})) {
    if (value === undefined || value === null || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key === 'html') node.innerHTML = value; // only ever for our own markup
    else if (key === 'style') setStyles(node, value);
    else if (key.startsWith('on')) node.addEventListener(key.slice(2).toLowerCase(), value);
    else if (key === 'dataset') Object.assign(node.dataset, value);
    else node.setAttribute(key, value === true ? '' : value);
  }

  for (const child of children.flat()) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

/** Replace the contents of a node. */
export function render(root, ...children) {
  root.replaceChildren(...children.flat().filter(Boolean));
}

/* ── Toasts ──────────────────────────────────────────────────────────────── */

export function toast(message, kind = '', duration = 3200) {
  if (!message) return;
  const stack = $('#toast-stack');
  const node = el('div', { class: `toast ${kind}`.trim(), text: message });
  stack.appendChild(node);

  setTimeout(() => {
    node.classList.add('is-leaving');
    node.addEventListener('animationend', () => node.remove(), { once: true });
  }, duration);
}

/* ── Confirm dialog ──────────────────────────────────────────────────────── */

/**
 * A promise-based confirm, used for "leave a game in progress?".
 * Resolves true if the player confirms.
 */
export function confirmDialog({ title, body, confirmLabel = 'Yes', cancelLabel = 'Cancel' }) {
  return new Promise((resolve) => {
    const overlay = $('#dialog');
    $('#dialog-title').textContent = title;
    $('#dialog-body').textContent = body ?? '';
    $('#dialog-confirm').textContent = confirmLabel;
    $('#dialog-cancel').textContent = cancelLabel;
    overlay.hidden = false;

    const finish = (result) => {
      overlay.hidden = true;
      $('#dialog-confirm').removeEventListener('click', onConfirm);
      $('#dialog-cancel').removeEventListener('click', onCancel);
      overlay.removeEventListener('click', onBackdrop);
      document.removeEventListener('keydown', onKey);
      resolve(result);
    };
    const onConfirm = () => finish(true);
    const onCancel = () => finish(false);
    const onBackdrop = (event) => {
      if (event.target === overlay) finish(false);
    };
    const onKey = (event) => {
      if (event.key === 'Escape') finish(false);
    };

    $('#dialog-confirm').addEventListener('click', onConfirm);
    $('#dialog-cancel').addEventListener('click', onCancel);
    overlay.addEventListener('click', onBackdrop);
    document.addEventListener('keydown', onKey);
    $('#dialog-confirm').focus();
  });
}

/* ── Shared pieces ───────────────────────────────────────────────────────── */

/**
 * The token face — a coloured disc with initials.
 * Initials matter: with 15 players, colour alone stops being enough.
 */
export function tokenFace(member, { small = false, offline = false } = {}) {
  return el('div', {
    class: `token-face${small ? ' is-small' : ''}${offline ? ' is-offline' : ''}`,
    style: { '--token-color': member.color },
    text: member.initials ?? '?',
    title: member.name,
  });
}

/** Lobby player grid — scales from 2 to 15 without changing shape. */
export function playerGrid(players, youId) {
  return el(
    'div',
    { class: 'player-grid' },
    players.map((player) =>
      el(
        'div',
        {
          class: `player-card${player.id === youId ? ' is-you' : ''}${
            player.connected ? '' : ' is-offline'
          }`,
        },
        tokenFace(player, { offline: !player.connected }),
        el(
          'div',
          { style: { minWidth: 0 } },
          el(
            'div',
            { class: 'player-card-name' },
            player.name,
            player.isHost ? el('span', { class: 'crown', text: ' 👑', title: 'Host' }) : null,
          ),
          el('div', {
            class: 'player-card-sub',
            text: !player.connected ? 'Reconnecting…' : player.id === youId ? 'You' : '',
          }),
        ),
      ),
    ),
  );
}

/**
 * Chat + emoji reactions, shared by every game.
 * Returns the element plus the handles a game needs to feed it.
 */
export function chatPanel({ reactions, onSend, onReact, maxLength = 140 }) {
  const log = el('ol', { class: 'chat-log', 'aria-live': 'polite' });
  const input = el('input', {
    class: 'input input-sm',
    type: 'text',
    maxlength: String(maxLength),
    placeholder: 'Say something…',
  });

  const reactionButtons = reactions.map((emoji) =>
    el('button', {
      type: 'button',
      text: emoji,
      title: `React ${emoji}`,
      onClick: () => onReact(emoji),
    }),
  );

  const form = el(
    'form',
    {
      class: 'chat-form',
      autocomplete: 'off',
      onSubmit: (event) => {
        event.preventDefault();
        const text = input.value.trim();
        if (!text) return;
        input.value = '';
        onSend(text);
      },
    },
    input,
    el('button', { class: 'icon-btn', type: 'submit', 'aria-label': 'Send', text: '➤' }),
  );

  const node = el(
    'section',
    { class: 'panel chat-panel' },
    el('div', { class: 'panel-head' }, el('h2', { text: 'Chat' })),
    el('div', { class: 'reactions' }, reactionButtons),
    log,
    form,
  );

  const setEmpty = () => {
    if (log.children.length === 0) {
      log.appendChild(el('li', { class: 'chat-empty', text: 'Say hi to the others 👋' }));
    }
  };

  const trim = () => {
    while (log.children.length > 60) log.firstElementChild.remove();
    log.scrollTop = log.scrollHeight;
  };

  setEmpty();

  return {
    node,
    addMessage(message, youId) {
      log.querySelector('.chat-empty')?.remove();
      log.appendChild(
        el(
          'li',
          { class: 'chat-msg' },
          el('span', {
            class: 'who',
            style: { color: message.color },
            text: message.playerId === youId ? 'You:' : `${message.name}:`,
          }),
          el('span', { class: 'what', text: message.text }),
        ),
      );
      trim();
    },
    addSystem(text) {
      log.querySelector('.chat-empty')?.remove();
      log.appendChild(el('li', { class: 'chat-msg is-system', text }));
      trim();
    },
    setHistory(messages, youId) {
      log.replaceChildren();
      if (!messages.length) {
        setEmpty();
        return;
      }
      for (const message of messages) this.addMessage(message, youId);
    },
    /** Grey the buttons out while the 2-second reaction cooldown runs. */
    coolDown(ms) {
      for (const button of reactionButtons) button.disabled = true;
      setTimeout(() => {
        for (const button of reactionButtons) button.disabled = false;
      }, ms);
    },
  };
}

/* ── Game-over modal ─────────────────────────────────────────────────────────
   Every game ends the same way — a result, a ranking and the same three
   choices — so it lives here rather than being hand-rolled five times.

   The modal attaches to document.body so it can sit above the board, which
   means it will NOT be swept away when the router swaps out #app. Each one
   registers itself below and `dismissOverlays()` (wired to the router's
   navigation hook) guarantees it can never outlive its screen.               */

const openOverlays = new Set();

/** Close every open body-level overlay. Wired to the router in app.js. */
export function dismissOverlays() {
  for (const close of [...openOverlays]) close();
  openOverlays.clear();
}

/**
 * Show the end-of-game card.
 *
 * @param {object}   options
 * @param {string}   options.emoji      big glyph at the top
 * @param {string}   options.title
 * @param {string}   [options.subtitle] a quiet line under the title
 * @param {Node[]}   [options.content]  podium, standings — anything game-specific
 * @param {object}   [options.primary]  { label, onClick } — Play again / Rematch
 * @param {string}   [options.note]     shown instead of the primary action
 * @param {string}   [options.dismissLabel]
 * @param {Function} [options.onBack]   extra teardown before leaving for the hub
 * @returns {{ node: Node, close: Function }}
 */
export function gameOverModal({
  emoji,
  title,
  subtitle,
  content = [],
  primary,
  note,
  dismissLabel = 'See the board',
  onBack,
}) {
  const close = () => {
    document.removeEventListener('keydown', onKey);
    openOverlays.delete(close);
    overlay.remove();
  };

  const onKey = (event) => {
    if (event.key === 'Escape') close();
  };

  const overlay = el(
    'div',
    {
      class: 'overlay victory-overlay',
      // Tapping the dimmed backdrop dismisses, as a modal should.
      onClick: (event) => {
        if (event.target === overlay) close();
      },
    },
    el(
      'div',
      { class: 'overlay-card victory-card', role: 'dialog', 'aria-modal': 'true' },
      el('button', {
        class: 'modal-close',
        type: 'button',
        'aria-label': 'Close',
        title: 'Close',
        text: '×',
        onClick: close,
      }),
      el('div', { class: 'victory-emoji', text: emoji }),
      el('h2', { text: title }),
      subtitle ? el('p', { class: 'muted', text: subtitle }) : null,
      ...content,
      el(
        'div',
        { class: 'victory-actions' },
        primary
          ? el('button', {
              class: 'btn btn-go btn-lg btn-block',
              text: primary.label,
              onClick: async () => {
                // The room going back to the lobby closes this anyway, but
                // closing here keeps the click feeling immediate.
                const keepOpen = await primary.onClick();
                if (!keepOpen) close();
              },
            })
          : null,
        note ? el('p', { class: 'muted', text: note }) : null,
        el('button', {
          class: 'btn btn-ghost btn-block',
          text: 'Back to Games',
          onClick: () => {
            // Close FIRST: the router only replaces #app, so an overlay left
            // on the body would hang over the landing page with no way out.
            close();
            onBack?.();
            go('/', { force: true });
          },
        }),
        el('button', { class: 'btn btn-ghost btn-sm', text: dismissLabel, onClick: close }),
      ),
    ),
  );

  document.addEventListener('keydown', onKey);
  openOverlays.add(close);
  document.body.appendChild(overlay);

  return { node: overlay, close };
}

/** Copy text, with a friendly fallback when the clipboard is blocked. */
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
