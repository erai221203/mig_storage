/**
 * The hub screens: the landing page (game cards), the per-game setup screen
 * (player count + mode), and the join-by-code screen.
 *
 * Every card on the landing page is generated from the server's catalogue, so
 * announcing a new game is a one-entry change in server/games/registry.js.
 */

import { el, render, toast, $ } from '../shared/ui.js';
import { getJSON, connectGame, send, saveSession, rememberName, lastName } from '../shared/net.js';
import { go } from '../shared/router.js';

/* ── Landing page ────────────────────────────────────────────────────────── */

export function renderLanding(root, hub) {
  document.title = 'Gaming Hub';

  const cards = hub.games.map((game) => {
    const live = game.status === 'live';
    const players =
      game.minPlayers === game.maxPlayers
        ? `${game.minPlayers} players`
        : `${game.minPlayers}–${game.maxPlayers} players`;

    return el(
      live ? 'a' : 'div',
      {
        class: `game-card${live ? '' : ' is-soon'}`,
        style: { '--card-accent': game.accent },
        href: live ? `/g/${game.id}` : null,
        'data-link': live ? '' : null,
        'aria-disabled': live ? null : 'true',
      },
      el('div', { class: 'game-icon', text: game.icon, 'aria-hidden': 'true' }),
      el(
        'div',
        { class: 'game-body' },
        el(
          'div',
          { class: 'game-title-row' },
          el('h3', { text: game.title }),
          el('span', { class: 'pill game-players', text: players }),
        ),
        el('p', { class: 'game-tagline', text: game.tagline }),
      ),
      live
        ? el('span', { class: 'game-go', text: 'Play →' })
        : el('span', { class: 'game-soon', text: 'Coming soon' }),
    );
  });

  render(
    root,
    el(
      'section',
      { class: 'screen' },
      el(
        'div',
        { class: 'wrap wrap-wide' },
        el(
          'header',
          { class: 'hub-hero' },
          el('div', { class: 'hero-dice', 'aria-hidden': 'true' }, '🎲', '🐍', '🪜'),
          el('h1', { text: 'Gaming Hub' }),
          el('p', {
            class: 'hero-sub',
            text: 'Grab a coffee, share a code, and play something silly with the team.',
          }),
        ),

        el('div', { class: 'game-grid' }, cards),

        el(
          'div',
          { class: 'join-strip panel' },
          el(
            'div',
            null,
            el('strong', { text: 'Already have a room code?' }),
            el('p', { class: 'muted', text: 'Join straight from here — any game.' }),
          ),
          el('a', { class: 'btn btn-ghost', href: '/join', 'data-link': '', text: 'Join a room' }),
        ),

        el('p', {
          class: 'hub-footnote',
          text: 'No sign-up · Nothing stored anywhere · Works on phones',
        }),
      ),
    ),
  );
}

/* ── Setup: player count + mode, then create ─────────────────────────────── */

export function renderSetup(root, game) {
  document.title = `${game.title} — Gaming Hub`;

  const state = {
    players: 4,
    mode: 'classic',
    config: null,
  };

  const modesBox = el('div', { class: 'mode-list' });
  const modeSection = el(
    'section',
    { class: 'panel setup-panel' },
    el('p', { class: 'eyebrow', text: 'Game mode' }),
    modesBox,
  );
  const countValue = el('span', { class: 'count-value', text: '4' });
  const recommendation = el('p', { class: 'recommend' });
  const nameInput = el('input', {
    class: 'input',
    type: 'text',
    maxlength: '16',
    placeholder: "What should we call you?",
    value: lastName(),
  });
  const suggestions = el('div', { class: 'suggestions' });
  const errorBox = el('p', { class: 'form-error', hidden: true });

  const slider = el('input', {
    class: 'count-slider',
    type: 'range',
    min: String(game.minPlayers),
    max: String(game.maxPlayers),
    value: '4',
    'aria-label': 'Number of players',
  });

  const stepper = (delta) =>
    el('button', {
      class: 'icon-btn',
      type: 'button',
      text: delta > 0 ? '+' : '−',
      'aria-label': delta > 0 ? 'More players' : 'Fewer players',
      onClick: () => {
        setCount(state.players + delta);
      },
    });

  function setCount(next) {
    state.players = Math.min(game.maxPlayers, Math.max(game.minPlayers, next));
    slider.value = String(state.players);
    countValue.textContent = String(state.players);
    drawModes();
  }

  /**
   * Modes are recommended contextually — Classic drags with a big group, and
   * Race/Team are overkill for two people.
   */
  function drawModes() {
    if (!state.config) return;
    const count = state.players;

    // Not every game has modes — Bingo, for instance, has one way to play.
    if (!state.config.modes?.length) {
      modeSection.hidden = true;
      recommendation.textContent =
        count <= 3
          ? 'A cosy few — everyone gets a card and takes turns calling.'
          : 'A big table. Expect cards to fill up fast.';
      return;
    }
    modeSection.hidden = false;

    render(
      modesBox,
      state.config.modes.map((mode) => {
        const suited =
          (mode.idealMax && count <= mode.idealMax) || (mode.idealMin && count >= mode.idealMin);

        return el(
          'button',
          {
            type: 'button',
            class: `mode-card${state.mode === mode.id ? ' is-active' : ''}${suited ? ' is-suited' : ''}`,
            onClick: () => {
              state.mode = mode.id;
              drawModes();
            },
          },
          el(
            'div',
            { class: 'mode-head' },
            el('strong', { text: mode.name }),
            suited ? el('span', { class: 'mode-badge', text: 'Recommended' }) : null,
          ),
          el('p', { class: 'mode-blurb', text: mode.blurb }),
          el('span', { class: 'mode-best', text: mode.best }),
        );
      }),
    );

    recommendation.textContent =
      count <= 4
        ? 'With a small group, Classic feels most like the real board.'
        : 'With this many players, Race or Team keeps everyone rolling — nobody waits.';
  }

  slider.addEventListener('input', () => setCount(Number(slider.value)));

  const createButton = el('button', {
    class: 'btn btn-go btn-lg btn-block',
    type: 'submit',
    text: 'Create room',
  });

  const form = el(
    'form',
    {
      autocomplete: 'off',
      onSubmit: async (event) => {
        event.preventDefault();
        errorBox.hidden = true;

        const name = nameInput.value.trim();
        if (!name) {
          errorBox.textContent = 'Pick a name so everyone knows who you are 🙂';
          errorBox.hidden = false;
          nameInput.focus();
          return;
        }

        createButton.disabled = true;
        try {
          const socket = connectGame(game.id);
          // Each game namespaces its own events; the prefix comes from the
          // registry so this screen works for any game in the hub.
          const response = await send(socket, `${game.eventPrefix}:create`, {
            name,
            maxPlayers: state.players,
            // Games without modes simply ignore this.
            mode: state.mode,
          });

          if (!response.ok) {
            errorBox.textContent = response.message ?? 'Could not create the room.';
            errorBox.hidden = false;
            return;
          }

          rememberName(name);
          saveSession({ gameId: game.id, code: response.code, memberId: response.memberId, name });
          await go(`/r/${response.code}?new=1`);
        } finally {
          createButton.disabled = false;
        }
      },
    },
    el(
      'section',
      { class: 'panel setup-panel' },
      el('p', { class: 'eyebrow', text: 'How many playing?' }),
      el(
        'div',
        { class: 'count-row' },
        stepper(-1),
        el(
          'div',
          { class: 'count-display' },
          countValue,
          el('span', { class: 'count-label', text: 'players' }),
        ),
        stepper(1),
      ),
      slider,
      el(
        'div',
        { class: 'count-scale' },
        el('span', { text: String(game.minPlayers) }),
        el('span', { text: String(game.maxPlayers) }),
      ),
      recommendation,
    ),

    modeSection,

    el(
      'section',
      { class: 'panel setup-panel' },
      el('p', { class: 'eyebrow', text: 'Your name' }),
      nameInput,
      suggestions,
    ),

    errorBox,
    createButton,
  );

  render(
    root,
    el(
      'section',
      { class: 'screen' },
      el(
        'div',
        { class: 'wrap' },
        el(
          'div',
          { class: 'setup-head' },
          el('a', { class: 'btn btn-ghost btn-sm', href: '/', 'data-link': '', text: '← Games' }),
          el(
            'div',
            { class: 'setup-title' },
            el('span', { class: 'setup-icon', text: game.icon }),
            el('h1', { text: game.title }),
          ),
        ),
        form,
        el(
          'p',
          { class: 'hub-footnote' },
          'Joining someone else? ',
          el('a', { href: '/join', 'data-link': '', text: 'Use a room code instead' }),
        ),
      ),
    ),
  );

  // Open the socket now rather than on submit, so it's ready by the time
  // someone presses Create.
  connectGame(game.id);

  // Fill in the parts that need the server.
  getJSON(`/api/games/${game.id}/config`).then((data) => {
    if (!data) return;
    state.config = data.config;
    setCount(data.config.limits.DEFAULT ?? 4);
    drawModes();
  });

  loadSuggestions(suggestions, nameInput);
}

/* ── Join by code ────────────────────────────────────────────────────────── */

export function renderJoin(root, hub, prefill = '', errorMessage = '') {
  document.title = 'Join a room — Gaming Hub';

  const codeInput = el('input', {
    class: 'input input-code',
    type: 'text',
    maxlength: '8',
    placeholder: 'ABC12',
    value: prefill,
    autocapitalize: 'characters',
    spellcheck: 'false',
  });
  const nameInput = el('input', {
    class: 'input',
    type: 'text',
    maxlength: '16',
    placeholder: "What should we call you?",
    value: lastName(),
  });
  const suggestions = el('div', { class: 'suggestions' });
  const errorBox = el('p', { class: 'form-error', hidden: !errorMessage, text: errorMessage });

  codeInput.addEventListener('input', () => {
    codeInput.value = codeInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
  });

  const submit = el('button', {
    class: 'btn btn-go btn-lg btn-block',
    type: 'submit',
    text: 'Join room',
  });

  const form = el(
    'form',
    {
      autocomplete: 'off',
      onSubmit: async (event) => {
        event.preventDefault();
        errorBox.hidden = true;

        const code = codeInput.value.trim();
        const name = nameInput.value.trim();
        if (!code) {
          errorBox.textContent = 'Enter the room code your coworker shared.';
          errorBox.hidden = false;
          return;
        }
        if (!name) {
          errorBox.textContent = 'Pick a name so everyone knows who you are 🙂';
          errorBox.hidden = false;
          return;
        }

        submit.disabled = true;
        try {
          // Codes are unique across every game, so one lookup routes us.
          const info = await getJSON(`/api/rooms/${code}`);
          if (!info) {
            errorBox.textContent = `No room called "${code}" — double-check the code? 🤔`;
            errorBox.hidden = false;
            return;
          }

          rememberName(name);
          await go(`/r/${code}?name=${encodeURIComponent(name)}`);
        } finally {
          submit.disabled = false;
        }
      },
    },
    el(
      'section',
      { class: 'panel setup-panel' },
      el('p', { class: 'eyebrow', text: 'Room code' }),
      codeInput,
      el('p', { class: 'muted', text: 'Any game — the code knows where to take you.' }),
    ),
    el(
      'section',
      { class: 'panel setup-panel' },
      el('p', { class: 'eyebrow', text: 'Your name' }),
      nameInput,
      suggestions,
    ),
    errorBox,
    submit,
  );

  render(
    root,
    el(
      'section',
      { class: 'screen' },
      el(
        'div',
        { class: 'wrap' },
        el(
          'div',
          { class: 'setup-head' },
          el('a', { class: 'btn btn-ghost btn-sm', href: '/', 'data-link': '', text: '← Games' }),
          el('div', { class: 'setup-title' }, el('h1', { text: 'Join a room' })),
        ),
        form,
      ),
    ),
  );

  loadSuggestions(suggestions, nameInput);
  if (!prefill) codeInput.focus();
  else nameInput.focus();
}

/* ── Not found / not ready ───────────────────────────────────────────────── */

export function renderMissing(root, message) {
  render(
    root,
    el(
      'section',
      { class: 'screen' },
      el(
        'div',
        { class: 'wrap' },
        el(
          'div',
          { class: 'panel missing-panel' },
          el('div', { class: 'missing-icon', text: '🎲' }),
          el('h1', { text: 'Nothing to play here' }),
          el('p', { class: 'muted', text: message }),
          el('a', { class: 'btn btn-primary', href: '/', 'data-link': '', text: 'Back to Games' }),
        ),
      ),
    ),
  );
}

/* ── shared bits ─────────────────────────────────────────────────────────── */

async function loadSuggestions(container, input) {
  const data = await getJSON('/api/names');
  const names = data?.suggestions ?? ['Lucky Ducky', 'Snake Charmer', 'Coffee Break'];
  render(
    container,
    names.map((name) =>
      el('button', {
        class: 'suggestion',
        type: 'button',
        text: name,
        onClick: () => {
          input.value = name;
          input.focus();
        },
      }),
    ),
  );
}
