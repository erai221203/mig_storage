/**
 * Chess client.
 *
 * Click a piece to see exactly where it may go, click a square to move. The
 * legal-move list comes from the server, so the hints and the rules can never
 * disagree — and the client never decides legality itself.
 *
 * The board is drawn from White's point of view for White and flipped for
 * Black, which is what everyone expects.
 */

import { connectGame, send, saveSession, loadSession, clearSession, getJSON, lastName }
  from '../../shared/net.js';
import { el, render, toast, confirmDialog, tokenFace, playerGrid, chatPanel, copyText, gameOverModal }
  from '../../shared/ui.js';
import { confetti, floatReaction, sound } from '../../shared/effects.js';
import { go, setLeaveGuard, clearLeaveGuard } from '../../shared/router.js';

const GAME_ID = 'chess';

/** Unicode glyphs. Outline pieces for white, solid for black. */
const GLYPHS = {
  wK: '♔', wQ: '♕', wR: '♖', wB: '♗', wN: '♘', wP: '♙',
  bK: '♚', bQ: '♛', bR: '♜', bB: '♝', bN: '♞', bP: '♟',
};

const squareName = (i) => 'abcdefgh'[i % 8] + (8 - Math.floor(i / 8));

let ctx = null;

export async function mount({ root, code, intent, name }) {
  const data = await getJSON(`/api/games/${GAME_ID}/config`);
  if (!data) {
    toast('Could not load the game.', 'is-warn');
    return go('/');
  }

  const socket = connectGame(GAME_ID);
  ctx = {
    root, code, socket, config: data.config,
    state: null, memberId: null, isSpectator: false,
    screen: null, nodes: {}, chat: null,
    squares: [], selected: null, pendingPromotion: null,
  };

  wireSocket();

  const session = loadSession();
  let response;
  if (session && session.code === code && session.memberId) {
    response = await send(socket, 'chess:rejoin', { code, memberId: session.memberId });
  }
  if (!response?.ok && intent !== 'created') {
    response = await send(socket, 'chess:join', {
      code, name: name || session?.name || lastName() || 'Player',
    });
  }
  if (!response?.ok && intent === 'created') response = { ok: true };

  if (!response?.ok) {
    clearSession();
    toast(response?.message ?? 'Could not join that room.', 'is-warn');
    return go('/join?code=' + code);
  }

  if (response.memberId) {
    ctx.memberId = response.memberId;
    ctx.isSpectator = Boolean(response.spectator);
    saveSession({ gameId: GAME_ID, code, memberId: response.memberId, name: name || session?.name });
  }
  if (response.message) toast(response.message, '', 4000);

  setLeaveGuard(async () => {
    if (ctx?.state?.state !== 'playing') return true;
    return confirmDialog({
      title: 'Leave the game?',
      body: 'A game is still in progress. Leaving forfeits it.',
      confirmLabel: 'Leave game',
      cancelLabel: 'Stay',
    });
  });
}

function wireSocket() {
  const { socket } = ctx;
  for (const e of ['chess:welcome', 'chess:state', 'chess:played', 'chess:gameOver',
    'chess:chat', 'chess:reaction']) socket.off(e);

  socket.on('chess:welcome', (payload) => {
    ctx.memberId = payload.memberId;
    ctx.isSpectator = payload.isSpectator;
    ctx.pendingChat = payload.chat ?? [];
  });
  socket.on('chess:state', applyState);

  socket.on('chess:played', (move) => {
    // A capture sounds different from a quiet move.
    if (move.captured) sound.snake();
    else sound.hop();
    if (move.san.endsWith('#')) sound.win();
    else if (move.san.endsWith('+')) sound.nope();
  });

  socket.on('chess:gameOver', ({ result, reason, standings }) => {
    if (result !== 'draw') confetti.celebrate();
    showVictory(result, reason, standings);
  });

  socket.on('chess:chat', (m) => ctx.chat?.addMessage(m, ctx.memberId));
  socket.on('chess:reaction', ({ emoji, name }) => floatReaction(emoji, name));

  socket.on('connect', async () => {
    updateConnection(true);
    const session = loadSession();
    if (session?.code === ctx.code && session.memberId) {
      await send(ctx.socket, 'chess:rejoin', { code: ctx.code, memberId: session.memberId });
    }
  });
  socket.on('disconnect', () => updateConnection(false));
}

function applyState(state) {
  if (!ctx) return;
  ctx.state = state;

  // A rematch must clear the victory overlay for *everyone*, not just whoever
  // pressed the button — otherwise it lingers and swallows their clicks.
  if (state.state !== 'ended' && ctx.victoryOverlay) {
    ctx.victoryOverlay.remove();
    ctx.victoryOverlay = null;
  }
  const want = state.state === 'lobby' ? 'lobby' : 'game';
  if (ctx.screen !== want) {
    ctx.screen = want;
    ctx.selected = null;
    if (want === 'lobby') buildLobby();
    else buildGame();
  }
  if (want === 'lobby') updateLobby();
  else updateGame();
}

/* ── lobby ───────────────────────────────────────────────────────────────── */

function buildLobby() {
  const players = el('div');
  const settings = el('div');
  const waiting = el('p', { class: 'lobby-waiting' });
  const startButton = el('button', {
    class: 'btn btn-go btn-lg', text: 'Start game', disabled: true,
    onClick: async () => {
      const r = await send(ctx.socket, 'chess:start');
      if (!r.ok) toast(r.message, 'is-warn');
    },
  });

  ctx.chat = ctx.chat ?? chatPanel({
    reactions: ctx.config.reactions,
    onSend: (text) => send(ctx.socket, 'chess:chat', { text }),
    onReact: reactWithCooldown,
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  ctx.nodes = { players, settings, waiting, startButton };

  render(ctx.root,
    el('section', { class: 'screen' },
      el('div', { class: 'wrap' },
        el('div', { class: 'setup-head' }, backButton(),
          el('div', { class: 'setup-title' },
            el('span', { class: 'setup-icon', text: '♟️' }), el('h1', { text: 'Lobby' }))),
        el('section', { class: 'panel code-panel' },
          el('p', { class: 'eyebrow', text: 'Share this code' }),
          el('button', {
            class: 'room-code', title: 'Click to copy',
            onClick: async () => {
              const ok = await copyText(ctx.code);
              toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.code}`, ok ? 'is-good' : '');
            },
          }, el('span', { text: ctx.code }), el('span', { class: 'copy-hint', text: '📋' }))),
        el('section', { class: 'panel' },
          el('div', { class: 'panel-head' }, el('h2', { text: 'Players' })),
          players, waiting),
        settings,
        el('div', { class: 'lobby-actions' }, startButton),
        ctx.chat.node)));
}

function updateLobby() {
  const { state, nodes } = ctx;
  const isHost = state.hostId === ctx.memberId;

  // The first seat plays white — show that before the game starts.
  render(nodes.players,
    el('div', { class: 'player-grid' },
      state.players.map((player, index) =>
        el('div', {
          class: `player-card${player.id === ctx.memberId ? ' is-you' : ''}${player.connected ? '' : ' is-offline'}`,
        },
          tokenFace(player, { offline: !player.connected }),
          el('div', { style: { minWidth: 0 } },
            el('div', { class: 'player-card-name' }, player.name,
              player.isHost ? el('span', { class: 'crown', text: ' 👑' }) : null),
            el('div', { class: 'player-card-sub', text: index === 0 ? '♔ White' : '♚ Black' }))))));

  render(nodes.settings, isHost
    ? el('section', { class: 'panel' },
        el('div', { class: 'panel-head' }, el('h2', { text: 'Game setup' })),
        el('div', { class: 'setting-inline' },
          el('span', { class: 'eyebrow', text: 'Clock' }),
          el('div', { class: 'segmented' },
            ctx.config.timing.clockMinutesOptions.map((m) => el('button', {
              type: 'button', text: m === 0 ? 'None' : `${m} min`,
              class: state.rules.clockMinutes === m ? 'is-active' : '',
              onClick: () => send(ctx.socket, 'chess:configure', { clockMinutes: m }),
            })))),
        state.players.length === 2
          ? el('div', { class: 'setting-inline' },
              el('span', { class: 'eyebrow', text: 'Colours' }),
              el('button', {
                class: 'btn btn-ghost btn-sm', text: 'Swap sides',
                onClick: () => send(ctx.socket, 'chess:swap'),
              }))
          : null)
    : null);

  const ready = state.players.filter((p) => p.connected).length;
  nodes.startButton.hidden = !isHost;
  nodes.startButton.disabled = ready < 2;
  nodes.waiting.textContent = ready < 2
    ? 'Waiting for an opponent — share the code above.'
    : isHost ? 'Both here. Start whenever you like.'
      : `Waiting for ${state.players.find((p) => p.isHost)?.name ?? 'the host'} to start…`;
}

/* ── game ────────────────────────────────────────────────────────────────── */

/** My colour, or null when spectating. */
function mySide() {
  return ctx.state?.colorOfPlayer?.[ctx.memberId] ?? null;
}

/** Black sees the board from their own side. */
function isFlipped() {
  return mySide() === 'b';
}

function buildGame() {
  const boardGrid = el('div', { class: 'chess-grid' });
  ctx.squares = [];

  for (let index = 0; index < 64; index++) {
    const cell = el('button', {
      class: 'chess-square',
      type: 'button',
      dataset: { index: String(index) },
      'aria-label': squareName(index),
      onClick: () => onSquare(index),
    });
    ctx.squares.push(cell);
  }

  const board = el('div', { class: 'chess-board' }, boardGrid);
  const moveList = el('ol', { class: 'move-list' });
  const status = el('p', { class: 'caller-status' });
  const takenTop = el('div', { class: 'taken' });
  const takenBottom = el('div', { class: 'taken' });
  const clockTop = el('div', { class: 'chess-clock' });
  const clockBottom = el('div', { class: 'chess-clock' });
  const nameTop = el('div', { class: 'chess-seat' });
  const nameBottom = el('div', { class: 'chess-seat' });
  const drawNote = el('div', { class: 'draw-offer', hidden: true });

  const connChip = el('span', { class: 'chip chip-status' },
    el('span', { class: 'status-dot' }), el('span', { class: 'conn-text', text: 'connected' }));

  ctx.chat = ctx.chat ?? chatPanel({
    reactions: ctx.config.reactions,
    onSend: (text) => send(ctx.socket, 'chess:chat', { text }),
    onReact: reactWithCooldown,
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  ctx.nodes = { boardGrid, board, moveList, status, takenTop, takenBottom,
    clockTop, clockBottom, nameTop, nameBottom, drawNote, connChip };

  render(ctx.root,
    el('section', { class: 'screen game-screen' },
      el('div', { class: 'wrap wrap-wide' },
        el('div', { class: 'topbar' },
          el('div', { class: 'topbar-left' }, backButton(),
            el('button', {
              class: 'chip chip-code',
              onClick: async () => {
                const ok = await copyText(ctx.code);
                toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.code}`, ok ? 'is-good' : '');
              },
            }, el('span', { class: 'chip-label', text: 'Room' }), el('span', { text: ctx.code })),
            connChip),
          el('div', { class: 'topbar-right' },
            el('button', {
              class: 'icon-btn', title: 'Mute sounds', text: sound.muted ? '🔇' : '🔊',
              onClick: (e) => { e.currentTarget.textContent = sound.toggleMute() ? '🔇' : '🔊'; },
            }))),

        el('div', { class: 'game-shell' },
          el('main', { class: 'game-main' },
            el('div', { class: 'chess-side-bar' }, nameTop, takenTop, clockTop),
            board,
            el('div', { class: 'chess-side-bar' }, nameBottom, takenBottom, clockBottom)),

          el('div', { class: 'game-drawer' },
            el('button', {
              class: 'drawer-handle', type: 'button',
              onClick: (e) => {
                const open = e.currentTarget.closest('.game-shell').classList.toggle('drawer-open');
                e.currentTarget.textContent = open ? '▼  Hide moves & chat' : '▲  Moves & chat';
              },
            }, '▲  Moves & chat'),
            el('aside', { class: 'game-side' },
              el('section', { class: 'panel' }, status, drawNote,
                el('div', { class: 'chess-actions' },
                  el('button', {
                    class: 'btn btn-ghost btn-sm', text: 'Offer draw',
                    onClick: async () => {
                      const r = await send(ctx.socket, 'chess:offerDraw');
                      if (!r.ok) toast(r.message, 'is-warn');
                      else if (!r.agreed) toast('Draw offered.', '', 2200);
                    },
                  }),
                  el('button', {
                    class: 'btn btn-ghost btn-sm', text: 'Resign',
                    onClick: async () => {
                      const sure = await confirmDialog({
                        title: 'Resign the game?',
                        body: 'Your opponent will be awarded the win.',
                        confirmLabel: 'Resign', cancelLabel: 'Keep playing',
                      });
                      if (!sure) return;
                      const r = await send(ctx.socket, 'chess:resign');
                      if (!r.ok) toast(r.message, 'is-warn');
                    },
                  }))),
              el('section', { class: 'panel move-panel' },
                el('div', { class: 'panel-head' }, el('h2', { text: 'Moves' })),
                moveList),
              ctx.chat.node))))));

  render(boardGrid, ctx.squares);
}

function updateGame() {
  const { state, nodes } = ctx;
  const flipped = isFlipped();
  const side = mySide();

  // Draw the 64 squares in board order, flipped for Black.
  nodes.boardGrid.classList.toggle('is-flipped', flipped);

  const legal = state.yourMoves ?? [];
  const fromSelected = ctx.selected === null
    ? [] : legal.filter((m) => m.from === ctx.selected);
  const targets = new Map(fromSelected.map((m) => [m.to, m]));
  const movable = new Set(legal.map((m) => m.from));

  ctx.squares.forEach((cell, index) => {
    const piece = state.board[index];
    const file = index % 8;
    const rank = Math.floor(index / 8);

    cell.className = 'chess-square';
    cell.classList.add((file + rank) % 2 === 0 ? 'is-light' : 'is-dark');

    render(cell, piece
      ? el('span', {
          class: `chess-piece is-${piece[0]}`,
          text: GLYPHS[piece],
          'aria-label': piece,
        })
      : null);

    if (ctx.selected === index) cell.classList.add('is-selected');
    if (targets.has(index)) {
      cell.classList.add(piece || targets.get(index).castle ? 'is-capture' : 'is-target');
    }
    if (state.lastMove && (state.lastMove.from === index || state.lastMove.to === index)) {
      cell.classList.add('is-last');
    }
    // The king in check is flagged so it can't be missed.
    if (state.check && piece === state.turn + 'K') cell.classList.add('is-check');

    const canGrab = movable.has(index) && state.state === 'playing';
    cell.classList.toggle('is-grabbable', canGrab);
    cell.disabled = !(canGrab || targets.has(index));
  });

  // Seat plates, captured pieces and clocks — opponent on top, you below.
  const white = state.players.find((p) => state.colorOfPlayer[p.id] === 'w');
  const black = state.players.find((p) => state.colorOfPlayer[p.id] === 'b');
  const topPlayer = flipped ? white : black;
  const bottomPlayer = flipped ? black : white;
  const topColor = flipped ? 'w' : 'b';
  const bottomColor = flipped ? 'b' : 'w';

  renderSeat(nodes.nameTop, topPlayer, topColor, state);
  renderSeat(nodes.nameBottom, bottomPlayer, bottomColor, state);
  renderTaken(nodes.takenTop, state.captured[topColor]);
  renderTaken(nodes.takenBottom, state.captured[bottomColor]);
  renderClock(nodes.clockTop, state, topColor);
  renderClock(nodes.clockBottom, state, bottomColor);

  // Move list, in numbered pairs.
  const pairs = [];
  for (let i = 0; i < state.moves.length; i += 2) {
    pairs.push({ number: i / 2 + 1, white: state.moves[i], black: state.moves[i + 1] });
  }
  render(nodes.moveList, pairs.map((pair) =>
    el('li', { class: 'move-row' },
      el('span', { class: 'move-number', text: `${pair.number}.` }),
      el('span', { class: 'move-san', text: pair.white ?? '' }),
      el('span', { class: 'move-san', text: pair.black ?? '' }))));
  nodes.moveList.scrollTop = nodes.moveList.scrollHeight;

  // Status line.
  const turnPlayer = state.players.find((p) => state.colorOfPlayer[p.id] === state.turn);
  if (state.state === 'ended') {
    nodes.status.textContent = state.result === 'draw'
      ? `Draw — ${state.reason}.`
      : `${state.result === 'w' ? 'White' : 'Black'} wins by ${state.reason}.`;
  } else if (ctx.isSpectator) {
    nodes.status.textContent = `${turnPlayer ? turnPlayer.name : '…'} to move${state.check ? ' — check!' : ''}`;
  } else if (state.turn === side) {
    nodes.status.textContent = state.check ? 'You are in check!' : 'Your move.';
  } else {
    nodes.status.textContent = `${turnPlayer ? turnPlayer.name : 'Opponent'} is thinking…`;
  }
  nodes.status.classList.toggle('is-your-turn', state.turn === side && state.state === 'playing');

  // A pending draw offer from the opponent.
  const offeredByOther = state.drawOfferedBy && state.drawOfferedBy !== ctx.memberId;
  nodes.drawNote.hidden = !offeredByOther;
  if (offeredByOther) {
    const who = state.players.find((p) => p.id === state.drawOfferedBy);
    render(nodes.drawNote,
      el('span', { text: `${who ? who.name : 'Your opponent'} offers a draw.` }),
      el('div', { class: 'draw-actions' },
        el('button', {
          class: 'btn btn-go btn-sm', text: 'Accept',
          onClick: () => send(ctx.socket, 'chess:offerDraw'),
        }),
        el('button', {
          class: 'btn btn-ghost btn-sm', text: 'Decline',
          onClick: () => send(ctx.socket, 'chess:declineDraw'),
        })));
  }
}

function renderSeat(node, player, color, state) {
  if (!player) {
    render(node, el('span', { class: 'muted', text: '—' }));
    return;
  }
  const toMove = state.colorOfPlayer[player.id] === state.turn && state.state === 'playing';
  node.classList.toggle('is-to-move', toMove);
  render(node,
    el('span', { class: 'chess-seat-glyph', text: color === 'w' ? '♔' : '♚' }),
    el('span', { class: 'chess-seat-name', text: player.name }),
    player.id === ctx.memberId ? el('span', { class: 'pill', text: 'you' }) : null);
}

/** Captured pieces, biggest first. */
function renderTaken(node, pieces) {
  const order = { Q: 0, R: 1, B: 2, N: 3, P: 4 };
  const sorted = [...(pieces ?? [])].sort((a, b) => order[a[1]] - order[b[1]]);
  render(node, sorted.map((piece) =>
    el('span', { class: 'taken-piece', text: GLYPHS[piece], title: piece })));
}

function renderClock(node, state, color) {
  if (!state.clock) {
    node.hidden = true;
    return;
  }
  node.hidden = false;
  const ms = state.clock[color] ?? 0;
  const total = Math.max(0, Math.round(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = String(total % 60).padStart(2, '0');
  node.textContent = `${minutes}:${seconds}`;
  node.classList.toggle('is-low', ms < 30_000);
  node.classList.toggle('is-running', state.turn === color && state.state === 'playing');
}

/* ── moving ──────────────────────────────────────────────────────────────── */

async function onSquare(index) {
  const { state } = ctx;
  if (!state || state.state !== 'playing' || ctx.isSpectator) return;

  const legal = state.yourMoves ?? [];

  // Second click: is this a legal destination for the selected piece?
  if (ctx.selected !== null) {
    const options = legal.filter((m) => m.from === ctx.selected && m.to === index);
    if (options.length) {
      // More than one option means a promotion — ask which piece.
      const promotion = options.length > 1 ? await askPromotion() : options[0].promotion;
      if (options.length > 1 && !promotion) return; // cancelled

      const from = ctx.selected;
      ctx.selected = null;
      const r = await send(ctx.socket, 'chess:move', { from, to: index, promotion });
      if (!r.ok) {
        toast(r.message ?? 'That move is not legal.', 'is-warn');
        sound.nope();
      }
      updateGame();
      return;
    }
  }

  // Otherwise, select (or deselect) a piece of your own that can move.
  const canMove = legal.some((m) => m.from === index);
  ctx.selected = canMove && ctx.selected !== index ? index : null;
  updateGame();
}

/** Modal picker for the promotion piece. */
function askPromotion() {
  return new Promise((resolve) => {
    const side = mySide() ?? 'w';
    const pick = (piece) => {
      overlay.remove();
      resolve(piece);
    };

    const overlay = el('div', {
      class: 'overlay',
      onClick: (event) => {
        if (event.target === overlay) pick(null);
      },
    },
      el('div', { class: 'overlay-card promotion-card' },
        el('h2', { text: 'Promote to…' }),
        el('div', { class: 'promotion-choices' },
          ['Q', 'R', 'B', 'N'].map((piece) =>
            el('button', {
              class: 'promotion-choice',
              type: 'button',
              title: { Q: 'Queen', R: 'Rook', B: 'Bishop', N: 'Knight' }[piece],
              text: GLYPHS[side + piece],
              onClick: () => pick(piece),
            }))),
        el('button', { class: 'btn btn-ghost btn-sm', text: 'Cancel', onClick: () => pick(null) })));

    document.body.appendChild(overlay);
  });
}

/* ── victory ─────────────────────────────────────────────────────────────── */

function showVictory(result, reason, standings) {
  const side = mySide();
  const youWon = result !== 'draw' && result === side;

  ctx.victoryOverlay = gameOverModal({
    emoji: result === 'draw' ? '🤝' : youWon ? '🏆' : '♟️',
    title: result === 'draw' ? 'Draw' : `${result === 'w' ? 'White' : 'Black'} wins`,
    subtitle: `by ${reason}`,
    content: [
      el('ol', { class: 'standings' },
        (standings ?? []).map((entry) =>
          el('li', { class: 'standings-row' },
            tokenFace(entry, { small: true }),
            el('span', { class: 'leader-name', text: `${entry.name} (${entry.side})` }),
            el('span', { class: 'leader-pos', text: entry.isWinner ? '🏆' : '' })))),
    ],
    primary: {
      label: 'Rematch (swap sides)',
      onClick: async () => {
        const r = await send(ctx.socket, 'chess:rematch');
        if (!r.ok) toast(r.message, 'is-warn');
        return !r.ok;
      },
    },
    onBack: () => { clearLeaveGuard(); confetti.stop(); },
  }).node;
}

function backButton() {
  return el('button', {
    class: 'btn btn-ghost btn-sm', text: '← Games',
    onClick: async () => {
      const left = await go('/');
      if (left) {
        await send(ctx.socket, 'chess:leave');
        clearSession();
        teardown();
      }
    },
  });
}

async function reactWithCooldown(emoji) {
  const r = await send(ctx.socket, 'chess:react', { emoji });
  if (r.ok) ctx.chat?.coolDown(2000);
}

function updateConnection(online) {
  const chip = ctx?.nodes?.connChip;
  if (!chip) return;
  chip.classList.toggle('is-offline', !online);
  chip.querySelector('.conn-text').textContent = online ? 'connected' : 'reconnecting…';
}

function teardown() {
  if (!ctx) return;
  ctx.victoryOverlay?.remove();
  ctx = null;
}
