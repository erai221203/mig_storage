/**
 * Snake & Ladder client.
 *
 * Renders from the server's snapshot and nothing else — the client never
 * decides a dice roll, a move or whose turn it is. Its jobs are to show the
 * board, animate what the server says happened, and send two kinds of message:
 * "I want to roll" and "here's a chat line".
 *
 * The screen is built once and updated in place. Rebuilding on every snapshot
 * would restart animations and, with 15 tokens, look broken.
 */

import { connectGame, send, saveSession, loadSession, clearSession, getJSON, lastName }
  from '../../shared/net.js';
import { $, el, render, toast, confirmDialog, tokenFace, playerGrid, chatPanel, copyText, gameOverModal }
  from '../../shared/ui.js';
import { confetti, floatReaction, sound } from '../../shared/effects.js';
import { go, setLeaveGuard, clearLeaveGuard } from '../../shared/router.js';
import { createBoard, stepPath, wait } from './board.js';

const GAME_ID = 'snake-and-ladder';

/** Everything the mounted screen needs, kept in one place for teardown. */
let ctx = null;

export async function mount({ root, code, intent, name }) {
  const configData = await getJSON(`/api/games/${GAME_ID}/config`);
  if (!configData) {
    toast('Could not load the game.', 'is-warn');
    return go('/');
  }

  const socket = connectGame(GAME_ID);

  ctx = {
    root,
    code,
    socket,
    config: configData.config,
    game: configData.game,
    state: null,
    memberId: null,
    isSpectator: false,
    screen: null, // 'lobby' | 'game'
    board: null,
    chat: null,
    nodes: {},
    animating: false,
    timerHandle: null,
    lastRound: 0,
  };

  wireSocket();

  // Get into the room: resume a session if we have one, otherwise join fresh.
  const session = loadSession();
  const resumable = session && session.code === code && session.memberId;

  let response;
  if (resumable) {
    response = await send(socket, 'snl:rejoin', { code, memberId: session.memberId });
  }
  if (!response?.ok && intent !== 'created') {
    const displayName = name || session?.name || lastName() || 'Player';
    response = await send(socket, 'snl:join', { code, name: displayName });
  }
  if (!response?.ok && intent === 'created') {
    // The create call already seated us; the welcome event will arrive.
    response = { ok: true };
  }

  if (!response?.ok) {
    clearSession();
    toast(response?.message ?? 'Could not join that room.', 'is-warn');
    return go('/join?code=' + code);
  }

  if (response.memberId) {
    ctx.memberId = response.memberId;
    ctx.isSpectator = Boolean(response.spectator);
    saveSession({ gameId: GAME_ID, code, memberId: response.memberId, name: name || session?.name });
  }
  if (response.message) toast(response.message, '', 4000);

  // Leaving mid-game should ask first.
  setLeaveGuard(async () => {
    if (ctx?.state?.state !== 'playing') return true;
    return confirmDialog({
      title: 'Leave the game?',
      body: 'A game is still in progress. Your token will drop out of the race.',
      confirmLabel: 'Leave game',
      cancelLabel: 'Stay',
    });
  });
}

/* ── socket wiring ───────────────────────────────────────────────────────── */

function wireSocket() {
  const { socket } = ctx;

  // Re-binding on every mount would stack handlers, so clear ours first.
  socket.off('snl:welcome');
  socket.off('snl:state');
  socket.off('snl:results');
  socket.off('snl:rolled');
  socket.off('snl:chat');
  socket.off('snl:reaction');
  socket.off('snl:gameOver');
  socket.off('snl:kicked');

  socket.on('snl:welcome', (payload) => {
    ctx.memberId = payload.memberId;
    ctx.isSpectator = payload.isSpectator;
    ctx.pendingChat = payload.chat ?? [];
    applyState(payload.state);
  });

  socket.on('snl:state', applyState);

  socket.on('snl:results', (payload) => {
    playResults(payload).catch((error) => console.error('[snl] animation failed', error));
  });

  socket.on('snl:rolled', ({ tokenId }) => {
    // Tick the player off in the roster without waiting for a full snapshot.
    markRolled(tokenId);
  });

  socket.on('snl:chat', (message) => ctx.chat?.addMessage(message, ctx.memberId));
  socket.on('snl:reaction', ({ emoji, name }) => floatReaction(emoji, name));

  socket.on('snl:gameOver', ({ standings }) => {
    confetti.celebrate();
    sound.win();
    showVictory(standings);
  });

  socket.on('snl:kicked', ({ playerId, name }) => {
    if (playerId === ctx.memberId) {
      clearSession();
      clearLeaveGuard();
      toast('The host removed you from the room.', 'is-warn');
      go('/', { force: true });
    } else {
      ctx.chat?.addSystem(`${name} was removed by the host.`);
    }
  });

  socket.on('disconnect', () => updateConnection(false));
  socket.on('connect', async () => {
    updateConnection(true);
    const session = loadSession();
    if (session?.code === ctx.code && session.memberId) {
      await send(ctx.socket, 'snl:rejoin', { code: ctx.code, memberId: session.memberId });
    }
  });
}

/** A new snapshot: swap screens if needed, then update in place. */
function applyState(state) {
  if (!ctx) return;
  const previous = ctx.state;
  ctx.state = state;

  const wantScreen = state.state === 'lobby' ? 'lobby' : 'game';
  if (ctx.screen !== wantScreen) {
    ctx.screen = wantScreen;
    if (wantScreen === 'lobby') buildLobby();
    else buildGame();
  }

  if (wantScreen === 'lobby') updateLobby();
  else updateGame(previous);
}

/* ── lobby ───────────────────────────────────────────────────────────────── */

function buildLobby() {
  const { config } = ctx;

  const players = el('div');
  const settings = el('div');
  const teamBox = el('div');
  const startButton = el('button', {
    class: 'btn btn-go btn-lg',
    text: 'Start game',
    disabled: true,
    onClick: async () => {
      const response = await send(ctx.socket, 'snl:start');
      if (!response.ok) toast(response.message, 'is-warn');
    },
  });
  const waiting = el('p', { class: 'lobby-waiting' });
  const countPill = el('span', { class: 'pill' });

  const codeButton = el(
    'button',
    {
      class: 'room-code',
      title: 'Click to copy',
      onClick: async () => {
        const ok = await copyText(ctx.state.code);
        toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.state.code}`, ok ? 'is-good' : '');
      },
    },
    el('span', { text: ctx.code }),
    el('span', { class: 'copy-hint', text: '📋' }),
  );

  ctx.chat = chatPanel({
    reactions: config.reactions,
    maxLength: 140,
    onSend: (text) => send(ctx.socket, 'snl:chat', { text }),
    onReact: (emoji) => reactWithCooldown(emoji),
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  ctx.nodes = { players, settings, teamBox, startButton, waiting, countPill };

  render(
    ctx.root,
    el(
      'section',
      { class: 'screen' },
      el(
        'div',
        { class: 'wrap' },
        el(
          'div',
          { class: 'setup-head' },
          backButton(),
          el(
            'div',
            { class: 'setup-title' },
            el('span', { class: 'setup-icon', text: '🐍' }),
            el('h1', { text: 'Lobby' }),
          ),
        ),

        el(
          'section',
          { class: 'panel code-panel' },
          el('p', { class: 'eyebrow', text: 'Share this code' }),
          codeButton,
          el('p', { class: 'muted', text: 'Anyone with the code can join from the hub.' }),
        ),

        el(
          'section',
          { class: 'panel' },
          el('div', { class: 'panel-head' }, el('h2', { text: 'Players' }), countPill),
          players,
          teamBox,
          waiting,
        ),

        settings,
        el('div', { class: 'lobby-actions' }, startButton),
        ctx.chat.node,
      ),
    ),
  );
}

function updateLobby() {
  const { state, nodes } = ctx;
  const isHost = state.hostId === ctx.memberId;

  nodes.countPill.textContent = `${state.players.length} of ${state.maxPlayers} joined`;
  render(nodes.players, playerGrid(state.players, ctx.memberId));

  // Team picker
  if (state.mode === 'team' && state.teams.length) {
    render(
      nodes.teamBox,
      el('p', { class: 'eyebrow team-heading', text: 'Teams — tap to switch' }),
      el(
        'div',
        { class: 'team-grid' },
        state.teams.map((team) => {
          const members = team.memberIds
            .map((id) => state.players.find((p) => p.id === id))
            .filter(Boolean);
          const mine = team.memberIds.includes(ctx.memberId);

          return el(
            'button',
            {
              class: `team-card${mine ? ' is-mine' : ''}`,
              type: 'button',
              style: { '--team-color': team.color },
              onClick: async () => {
                const response = await send(ctx.socket, 'snl:switchTeam', { teamId: team.id });
                if (!response.ok) toast(response.message, 'is-warn');
              },
            },
            el(
              'div',
              { class: 'team-head' },
              el('span', { class: 'team-emoji', text: team.emoji }),
              el('strong', { text: team.name }),
              el('span', { class: 'pill', text: `${members.length}` }),
            ),
            el(
              'div',
              { class: 'team-members' },
              members.map((m) => tokenFace(m, { small: true })),
            ),
          );
        }),
      ),
    );
  } else {
    render(nodes.teamBox);
  }

  render(nodes.settings, isHost ? hostSettings(state) : guestSummary(state));

  const ready = state.players.filter((p) => p.connected).length;
  const canStart = ready >= 2;
  nodes.startButton.hidden = !isHost;
  nodes.startButton.disabled = !canStart;

  if (!canStart) {
    nodes.waiting.textContent = 'Waiting for one more player — share the code above.';
  } else if (isHost) {
    nodes.waiting.textContent = 'Everyone in? Start whenever you like.';
  } else {
    const host = state.players.find((p) => p.isHost);
    nodes.waiting.textContent = `Waiting for ${host ? host.name : 'the host'} to start…`;
  }
}

function hostSettings(state) {
  const { config } = ctx;
  const patch = (body) => send(ctx.socket, 'snl:configure', body).then((r) => {
    if (!r.ok) toast(r.message, 'is-warn');
  });

  const modeRow = el(
    'div',
    { class: 'segmented' },
    config.modes.map((mode) =>
      el('button', {
        type: 'button',
        text: mode.name,
        class: state.mode === mode.id ? 'is-active' : '',
        onClick: () => patch({ mode: mode.id }),
      }),
    ),
  );

  const toggles = [
    ['extraTurnOnSix', 'Extra turn on a 6', 'Classic mode only — it would desync rounds.'],
    ['exactFinish', 'Exact roll to finish', 'Overshooting 100 keeps you where you are.'],
    ['needSixToStart', 'Need a 6 to start', 'Off by default so games start fast.'],
  ].map(([key, label, hint]) =>
    el(
      'div',
      { class: 'toggle-row' },
      el(
        'div',
        { class: 'toggle-label' },
        el('strong', { text: label }),
        el('span', { text: hint }),
      ),
      el('button', {
        class: `switch${state.rules[key] ? ' is-on' : ''}`,
        type: 'button',
        role: 'switch',
        'aria-checked': String(Boolean(state.rules[key])),
        'aria-label': label,
        onClick: () => patch({ [key]: !state.rules[key] }),
      }),
    ),
  );

  return el(
    'section',
    { class: 'panel' },
    el('div', { class: 'panel-head' }, el('h2', { text: 'Game setup' })),

    el('p', { class: 'eyebrow', text: 'Mode' }),
    modeRow,

    state.mode === 'team'
      ? el(
          'div',
          { class: 'setting-inline' },
          el('span', { class: 'eyebrow', text: 'Teams' }),
          el(
            'div',
            { class: 'segmented' },
            [2, 3, 4].map((n) =>
              el('button', {
                type: 'button',
                text: String(n),
                class: state.teams.length === n ? 'is-active' : '',
                onClick: () => patch({ teamCount: n }),
              }),
            ),
          ),
        )
      : null,

    state.mode === 'classic'
      ? el(
          'div',
          { class: 'setting-inline' },
          el('span', { class: 'eyebrow', text: 'Turn timer' }),
          el(
            'div',
            { class: 'segmented' },
            config.timing.turnSecondsOptions.map((seconds) =>
              el('button', {
                type: 'button',
                text: `${seconds}s`,
                class: state.rules.turnSeconds === seconds ? 'is-active' : '',
                onClick: () => patch({ turnSeconds: seconds }),
              }),
            ),
          ),
        )
      : null,

    el(
      'div',
      { class: 'setting-inline' },
      el('span', { class: 'eyebrow', text: 'Play until' }),
      el(
        'div',
        { class: 'segmented' },
        [
          ['first', 'First home'],
          ['podium', 'Top 3'],
          ['all', 'Everyone'],
        ].map(([value, label]) =>
          el('button', {
            type: 'button',
            text: label,
            class: state.rules.finishMode === value ? 'is-active' : '',
            onClick: () => patch({ finishMode: value }),
          }),
        ),
      ),
    ),

    el('div', { class: 'toggles' }, toggles),
  );
}

function guestSummary(state) {
  const mode = ctx.config.modes.find((m) => m.id === state.mode);
  const bits = [
    mode ? `${mode.name} mode` : null,
    state.rules.exactFinish ? 'exact finish' : 'overshoot allowed',
    state.mode === 'classic' && state.rules.extraTurnOnSix ? 'extra turn on a 6' : null,
    state.rules.needSixToStart ? 'need a 6 to start' : null,
  ].filter(Boolean);

  return el(
    'section',
    { class: 'panel guest-summary' },
    el('p', { text: bits.join(' · ') }),
  );
}

/* ── game screen ─────────────────────────────────────────────────────────── */

function buildGame() {
  const { config } = ctx;

  ctx.board = createBoard(config);

  const leaderboard = el('ol', { class: 'leaderboard' });
  const rollButton = el('button', {
    class: 'btn btn-roll',
    text: 'ROLL!',
    onClick: doRoll,
  });
  const dieFace = el('div', { class: 'die', 'aria-live': 'polite' });
  const turnLabel = el('p', { class: 'turn-label' });
  const timerBar = el('div', { class: 'timer-bar' }, el('div', { class: 'timer-fill' }));
  const ticker = el('div', { class: 'ticker' });
  const roundPill = el('span', { class: 'pill' });
  const banner = el('div', { class: 'stage-banner', hidden: true });

  if (!ctx.chat) {
    ctx.chat = chatPanel({
      reactions: config.reactions,
      maxLength: 140,
      onSend: (text) => send(ctx.socket, 'snl:chat', { text }),
      onReact: (emoji) => reactWithCooldown(emoji),
    });
    if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);
  }

  const connChip = el(
    'span',
    { class: 'chip chip-status' },
    el('span', { class: 'status-dot' }),
    el('span', { class: 'conn-text', text: 'connected' }),
  );

  // Host-only: stop here and rank everyone by how far they got. The spec calls
  // for the host to be able to wrap up rather than wait for every token home.
  const endButton = el('button', {
    class: 'btn btn-ghost btn-sm end-button',
    text: 'End game now',
    hidden: true,
    onClick: async () => {
      const sure = await confirmDialog({
        title: 'End the game here?',
        body: 'Everyone still on the board will be ranked by how far they got.',
        confirmLabel: 'End game',
        cancelLabel: 'Keep playing',
      });
      if (!sure) return;
      const response = await send(ctx.socket, 'snl:endGame');
      if (!response.ok) toast(response.message, 'is-warn');
    },
  });

  const sidebar = el(
    'aside',
    { class: 'game-side' },
    el(
      'section',
      { class: 'panel play-panel' },
      turnLabel,
      dieFace,
      timerBar,
      rollButton,
      ticker,
      endButton,
    ),
    el(
      'section',
      { class: 'panel board-side' },
      el('div', { class: 'panel-head' }, el('h2', { text: 'Leaderboard' }), roundPill),
      leaderboard,
    ),
    ctx.chat.node,
  );

  // On phones the sidebar becomes a swipe-up drawer so the board stays big.
  const drawerHandle = el(
    'button',
    {
      class: 'drawer-handle',
      type: 'button',
      onClick: () => {
        const open = ctx.nodes.shell.classList.toggle('drawer-open');
        drawerHandle.textContent = open ? '▼  Hide players & chat' : '▲  Players & chat';
      },
    },
    '▲  Players & chat',
  );

  const shell = el(
    'div',
    { class: 'game-shell' },
    el('main', { class: 'game-main' }, banner, ctx.board.node),
    el('div', { class: 'game-drawer' }, drawerHandle, sidebar),
  );

  ctx.nodes = {
    leaderboard,
    rollButton,
    dieFace,
    turnLabel,
    timerBar,
    ticker,
    roundPill,
    banner,
    connChip,
    shell,
    endButton,
  };

  render(
    ctx.root,
    el(
      'section',
      { class: 'screen game-screen' },
      el(
        'div',
        { class: 'wrap wrap-wide' },
        el(
          'div',
          { class: 'topbar' },
          el(
            'div',
            { class: 'topbar-left' },
            backButton(),
            el(
              'button',
              {
                class: 'chip chip-code',
                onClick: async () => {
                  const ok = await copyText(ctx.state.code);
                  toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.state.code}`, ok ? 'is-good' : '');
                },
              },
              el('span', { class: 'chip-label', text: 'Room' }),
              el('span', { text: ctx.code }),
            ),
            connChip,
          ),
          el(
            'div',
            { class: 'topbar-right' },
            el('button', {
              class: 'icon-btn',
              title: 'Mute sounds',
              text: sound.muted ? '🔇' : '🔊',
              onClick: (event) => {
                const muted = sound.toggleMute();
                event.currentTarget.textContent = muted ? '🔇' : '🔊';
              },
            }),
          ),
        ),
        shell,
      ),
    ),
  );

  ctx.board.setTokens(ctx.state.tokens);
  startTimerLoop();
}

function updateGame(previous) {
  const { state, nodes, board } = ctx;

  nodes.roundPill.textContent =
    state.mode === 'classic' ? `Round ${Math.max(1, state.round || 1)}` : `Round ${state.round}`;

  // Tokens only need a full reset when the set changes (new game, someone left).
  const ids = state.tokens.map((t) => t.id).join();
  if (ids !== ctx.lastTokenIds) {
    board.setTokens(state.tokens);
    ctx.lastTokenIds = ids;
  } else if (!ctx.animating) {
    board.syncPositions(state.tokens);
  }

  renderLeaderboard();
  renderPlayPanel();

  // "FINAL STRETCH!" the first time anyone passes 85.
  if (state.finalStretch && !ctx.finalStretchShown) {
    ctx.finalStretchShown = true;
    showBanner('FINAL STRETCH!', 'stretch');
  }
  if (previous && previous.round !== state.round) ctx.rolledThisRound = new Set();
}

/** The leaderboard, reordered with a FLIP animation so movement is readable. */
function renderLeaderboard() {
  const { state, nodes, board } = ctx;
  const list = nodes.leaderboard;

  // FIRST: where is every row now?
  const before = new Map();
  for (const row of list.children) {
    before.set(row.dataset.token, row.getBoundingClientRect().top);
  }

  const ordered = [...state.tokens].sort((a, b) => {
    if (a.rank && b.rank) return a.rank - b.rank;
    if (a.rank) return -1;
    if (b.rank) return 1;
    return b.position - a.position;
  });

  render(
    list,
    ordered.map((token, index) => {
      const mine =
        token.id === ctx.memberId || (token.memberIds ?? []).includes(ctx.memberId);
      return el(
        'li',
        {
          class: `leader-row${mine ? ' is-you' : ''}${token.finished ? ' is-finished' : ''}`,
          dataset: { token: token.id },
          title: 'Tap to find this token on the board',
          onClick: () => board.pulse(token.id),
        },
        el('span', { class: 'leader-place', text: token.rank ? `#${token.rank}` : `${index + 1}` }),
        tokenFace(token, { small: true }),
        el('span', { class: 'leader-name', text: token.name }),
        el('span', {
          class: 'leader-pos',
          text: token.finished ? '🏁' : String(token.position),
        }),
      );
    }),
  );

  // LAST + INVERT + PLAY: slide each row from where it used to be.
  for (const row of list.children) {
    const previousTop = before.get(row.dataset.token);
    if (previousTop === undefined) continue;
    const delta = previousTop - row.getBoundingClientRect().top;
    if (!delta) continue;
    row.animate(
      [{ transform: `translateY(${delta}px)` }, { transform: 'translateY(0)' }],
      { duration: 380, easing: 'cubic-bezier(0.22, 1, 0.36, 1)' },
    );
  }
}

/** The dice, roll button, timer and whose-turn text. */
function renderPlayPanel() {
  const { state, nodes } = ctx;
  const myToken = state.tokens.find(
    (t) => t.id === ctx.memberId || (t.memberIds ?? []).includes(ctx.memberId),
  );

  if (ctx.isSpectator) {
    nodes.turnLabel.textContent = 'You are watching 👀';
    nodes.rollButton.hidden = true;
    nodes.endButton.hidden = true;
    return;
  }

  const classic = state.mode === 'classic';
  let canRoll = false;
  let label = '';

  if (state.phase === 'countdown') {
    label = 'Get ready…';
  } else if (state.phase === 'resolving') {
    label = 'Tokens are moving…';
  } else if (classic) {
    const holder = state.players.find((p) => p.id === state.turnTokenId);
    const mine = state.turnTokenId === ctx.memberId;
    canRoll = mine && state.phase === 'turn';
    label = mine ? 'Your turn — roll!' : `${holder ? holder.name : 'Someone'} is rolling…`;
  } else if (state.phase === 'rolling') {
    const alreadyRolled = state.rolled.includes(myToken?.id);
    if (state.mode === 'team') {
      const team = state.teams.find((t) => t.memberIds.includes(ctx.memberId));
      const isRoller = team?.rollerId === ctx.memberId;
      canRoll = isRoller && !alreadyRolled && !myToken?.finished;
      const roller = state.players.find((p) => p.id === team?.rollerId);
      label = isRoller
        ? alreadyRolled
          ? 'Rolled! Waiting for the others…'
          : 'Your roll — for the team!'
        : `${roller ? roller.name : 'A teammate'} is rolling for you`;
    } else {
      canRoll = !alreadyRolled && !myToken?.finished;
      label = alreadyRolled ? 'Rolled! Waiting for the others…' : 'Everyone rolls — go!';
    }
  } else {
    label = 'Waiting…';
  }

  if (myToken?.finished) label = `You finished #${myToken.rank}! 🏁`;

  // Only the host can wrap the game up early.
  nodes.endButton.hidden = !(state.hostId === ctx.memberId && state.state === 'playing');

  nodes.turnLabel.textContent = label;
  nodes.turnLabel.classList.toggle('is-yours', canRoll);
  nodes.rollButton.hidden = false;
  nodes.rollButton.disabled = !canRoll || ctx.animating;
  nodes.rollButton.classList.toggle('is-ready', canRoll && !ctx.animating);

  // How many are still to roll, so a big room can see what it's waiting on.
  if (!classic && state.phase === 'rolling') {
    const active = state.tokens.filter((t) => !t.finished).length;
    nodes.ticker.textContent = `${state.rolled.length} of ${active} rolled`;
    nodes.ticker.classList.remove('is-results');
  }
}

async function doRoll() {
  if (!ctx || ctx.animating) return;
  ctx.nodes.rollButton.disabled = true;
  sound.dice();
  startDiceSpin();

  const response = await send(ctx.socket, 'snl:roll');
  if (!response.ok) {
    cancelDice();
    toast(response.message ?? 'Cannot roll right now.', 'is-warn');
    sound.nope();
    renderPlayPanel();
  }
}

/* ── The dice ────────────────────────────────────────────────────────────────
   The rule this enforces: a token never moves until the die has stopped on its
   real number. The server sends the roll; the client spins, lands on exactly
   that value, holds it long enough to read, and only then walks the token —
   by exactly that many squares.                                              */

const DICE = {
  /** A roll should still look like a roll when the server answers instantly. */
  MIN_SPIN_MS: 650,
  /** How long the landed number is held before anything moves. */
  SETTLE_MS: 550,
  SPIN_TICK_MS: 70,
};

let diceSpin = null;
let diceSpinStartedAt = 0;

function startDiceSpin() {
  cancelDice();
  const face = ctx.nodes.dieFace;
  face.classList.add('is-rolling');
  face.classList.remove('is-settled');
  diceSpinStartedAt = Date.now();

  diceSpin = setInterval(() => {
    // Once it has tumbled long enough, stop showing numbers entirely rather
    // than sitting on a random face — the next thing shown must be the truth.
    if (Date.now() - diceSpinStartedAt >= DICE.MIN_SPIN_MS) {
      clearInterval(diceSpin);
      diceSpin = null;
      face.classList.remove('is-rolling');
      face.classList.add('is-waiting');
      setDieFace(null);
      return;
    }
    setDieFace(1 + Math.floor(Math.random() * 6));
  }, DICE.SPIN_TICK_MS);
}

function cancelDice() {
  if (diceSpin) clearInterval(diceSpin);
  diceSpin = null;
  const face = ctx.nodes?.dieFace;
  face?.classList.remove('is-rolling', 'is-waiting', 'is-settled');
}

/**
 * Land the die on the server's number and hold it.
 * Resolves only once the die has visibly stopped — callers must await this
 * before moving anything.
 */
async function landDice(value) {
  const face = ctx.nodes.dieFace;

  // Guarantee the minimum tumble even if the server replied in a millisecond.
  const spun = Date.now() - diceSpinStartedAt;
  if (diceSpin && spun < DICE.MIN_SPIN_MS) await wait(DICE.MIN_SPIN_MS - spun);

  if (diceSpin) clearInterval(diceSpin);
  diceSpin = null;

  face.classList.remove('is-rolling', 'is-waiting');
  setDieFace(value);
  // Restart the land animation even if the die already carried this class.
  face.classList.remove('is-settled');
  void face.offsetWidth;
  face.classList.add('is-settled');

  await wait(DICE.SETTLE_MS);
}

/** Pips, laid out the way a real die is. */
const PIPS = {
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
};

function setDieFace(value) {
  const face = ctx.nodes.dieFace;

  // `null` means "rolled, waiting for the server" — deliberately shows no
  // number, because the only number this die should ever show is the real one.
  if (value === null) {
    render(face, el('span', { class: 'die-waiting', text: '?' }));
    delete face.dataset.value;
    return;
  }

  const on = new Set(PIPS[value] ?? []);
  render(
    face,
    Array.from({ length: 9 }, (_, i) =>
      el('span', { class: `pip${on.has(i) ? ' is-on' : ''}` }),
    ),
  );
  face.dataset.value = String(value);
}

/** Show a roll landed without waiting for the next snapshot. */
function markRolled(tokenId) {
  if (!ctx?.state || ctx.state.mode === 'classic') return;
  ctx.rolledThisRound = ctx.rolledThisRound ?? new Set();
  ctx.rolledThisRound.add(tokenId);

  const active = ctx.state.tokens.filter((t) => !t.finished).length;
  ctx.nodes.ticker.textContent = `${ctx.rolledThisRound.size} of ${active} rolled`;
}

/* ── animating a round ───────────────────────────────────────────────────── */

/**
 * Play back everything the server said happened.
 * All tokens move at once and the step time is scaled so even fifteen moves
 * land inside the animation budget the server allows.
 */
async function playResults({ results, mode }) {
  if (!ctx?.board) return;
  ctx.animating = true;
  ctx.nodes.rollButton.disabled = true;

  const mine = results.find(
    (r) => r.tokenId === ctx.memberId || tokenIncludesMe(r.tokenId),
  );

  // Which die is this player watching? Their own in Race and Team; in Classic
  // there is one shared die and everyone watches whoever just rolled — which
  // is why non-rollers need it too.
  const shown = mine ?? (mode === 'classic' ? results[0] : null);

  showTicker(results);

  if (shown) {
    // Players who didn't press the button have no spin running yet.
    if (!diceSpin && !ctx.nodes.dieFace.classList.contains('is-waiting')) startDiceSpin();
    // Nothing moves until the die has stopped on the real number.
    await landDice(shown.die);
  } else {
    cancelDice();
  }

  // Movement gets its own budget, separate from the dice reveal above.
  const budget = ctx.config.timing.moveMs ?? 3000;
  const longest = Math.max(1, ...results.map((r) => stepPath(r).length));
  // Leave room for the ladder/snake transition at the end.
  const stepMs = Math.max(45, Math.min(140, (budget - 700) / longest));

  await Promise.all(results.map((result) => animateOne(result, stepMs, Boolean(mine && mine.tokenId === result.tokenId))));

  // Dramatic beats, after the movement so they don't cover it.
  const bite = results.find((r) => r.bigBite);
  if (bite) showBanner(`NOOO! ${bite.name} hit the big snake!`, 'snake');
  else {
    const close = results.find((r) => r.soClose);
    if (close) showBanner(`So close, ${close.name}! ✨`, 'close');
  }

  ctx.animating = false;
  if (ctx.state) {
    ctx.board.syncPositions(ctx.state.tokens);
    renderLeaderboard();
    renderPlayPanel();
  }
}

function tokenIncludesMe(tokenId) {
  const token = ctx.state?.tokens.find((t) => t.id === tokenId);
  return Boolean(token && (token.memberIds ?? []).includes(ctx.memberId));
}

async function animateOne(result, stepMs, isMine) {
  const { board } = ctx;
  if (!board.hasToken(result.tokenId)) return;

  if (result.stuck || result.blocked) {
    board.pulse(result.tokenId);
    return;
  }

  const path = stepPath(result);
  await board.moveToken(result.tokenId, path, {
    stepMs,
    // Only my own token clicks, or fifteen tokens would be a racket.
    onStep: isMine ? () => sound.hop() : null,
  });

  if (result.via === 'ladder') {
    board.flashSquare(result.landed, 'ladder');
    if (isMine || result.bigBite) sound.ladder();
    await board.moveToken(result.tokenId, [result.to], { stepMs: 0 });
    await wait(420);
  } else if (result.via === 'snake') {
    board.flashSquare(result.landed, 'snake');
    if (isMine || result.bigBite) sound.snake();
    await board.moveToken(result.tokenId, [result.to], { stepMs: 0 });
    await wait(420);
  }
}

/** The rapid-fire "Arun rolled 6!" strip. */
function showTicker(results) {
  const { ticker } = ctx.nodes;
  ticker.classList.add('is-results');
  render(
    ticker,
    results.slice(0, 16).map((result, index) =>
      el(
        'span',
        {
          class: 'ticker-item',
          style: { animationDelay: `${index * 60}ms`, '--tick-color': result.color },
        },
        `${result.name} rolled ${result.die}`,
        result.via === 'ladder' ? ' 🪜' : result.via === 'snake' ? ' 🐍' : '',
      ),
    ),
  );
}

/** Full-width dramatic flash: the big snake, a near miss, the final stretch. */
function showBanner(text, kind) {
  const { banner } = ctx.nodes;
  banner.textContent = text;
  banner.className = `stage-banner is-${kind}`;
  banner.hidden = false;
  clearTimeout(ctx.bannerTimer);
  ctx.bannerTimer = setTimeout(() => {
    banner.hidden = true;
  }, kind === 'snake' ? 2200 : 1600);
}

/* ── timers ──────────────────────────────────────────────────────────────── */

/** Drive the countdown bar from the server's deadline. */
function startTimerLoop() {
  cancelAnimationFrame(ctx.timerHandle);

  const tick = () => {
    if (!ctx?.state) return;
    const fill = ctx.nodes.timerBar?.querySelector('.timer-fill');
    if (fill) {
      const deadline =
        ctx.state.mode === 'classic' ? ctx.state.turnDeadline : ctx.state.roundDeadline;
      const total =
        ctx.state.mode === 'classic'
          ? ctx.state.rules.turnSeconds * 1000
          : ctx.config.timing.roundWindowMs;

      if (deadline && total) {
        const left = Math.max(0, deadline - Date.now());
        fill.style.width = `${(left / total) * 100}%`;
        fill.classList.toggle('is-urgent', left < 3000);
        ctx.nodes.timerBar.hidden = false;
      } else {
        ctx.nodes.timerBar.hidden = true;
      }
    }
    ctx.timerHandle = requestAnimationFrame(tick);
  };
  ctx.timerHandle = requestAnimationFrame(tick);
}

/* ── victory ─────────────────────────────────────────────────────────────── */

function showVictory(standings) {
  const isHost = ctx.state?.hostId === ctx.memberId;
  const podium = standings.slice(0, 3);
  const rest = standings.slice(3);

  ctx.victoryOverlay = gameOverModal({
    emoji: '🏆',
    title: standings[0] ? `${standings[0].name} wins!` : 'Game over',
    content: [
      el('div', { class: 'podium' },
        podium.map((entry, index) =>
          el('div', { class: `podium-slot podium-${index + 1}` },
            el('span', { class: 'podium-medal', text: ['🥇', '🥈', '🥉'][index] }),
            tokenFace(entry, {}),
            el('span', { class: 'podium-name', text: entry.name })))),

      // Everyone else, so a full room of 15 still sees where it finished.
      rest.length
        ? el('ol', { class: 'standings' },
            rest.map((entry) =>
              el('li', { class: 'standings-row' },
                el('span', { class: 'leader-place', text: `#${entry.place}` }),
                tokenFace(entry, { small: true }),
                el('span', { class: 'leader-name', text: entry.name }),
                el('span', {
                  class: 'leader-pos',
                  text: entry.finished ? '🏁' : String(entry.position),
                }))))
        : null,
    ].filter(Boolean),

    // Only the host can deal again here, so everyone else gets a note instead.
    primary: isHost
      ? {
          label: 'Rematch',
          onClick: async () => {
            const response = await send(ctx.socket, 'snl:rematch');
            if (!response.ok) toast(response.message, 'is-warn');
            return !response.ok;
          },
        }
      : null,
    note: isHost ? null : 'Waiting for the host to start a rematch…',
    onBack: () => { clearLeaveGuard(); confetti.stop(); },
  }).node;
}

/* ── odds and ends ───────────────────────────────────────────────────────── */

function backButton() {
  return el('button', {
    class: 'btn btn-ghost btn-sm',
    text: '← Games',
    onClick: async () => {
      const left = await go('/');
      if (left) {
        await send(ctx.socket, 'snl:leave');
        clearSession();
        teardown();
      }
    },
  });
}

async function reactWithCooldown(emoji) {
  const response = await send(ctx.socket, 'snl:react', { emoji });
  // The server enforces the 2s limit; mirror it so the buttons look honest.
  if (response.ok) ctx.chat?.coolDown(ctx.config ? 2000 : 2000);
}

function updateConnection(online) {
  const chip = ctx?.nodes?.connChip;
  if (!chip) return;
  chip.classList.toggle('is-offline', !online);
  chip.querySelector('.conn-text').textContent = online ? 'connected' : 'reconnecting…';
}

function teardown() {
  if (!ctx) return;
  cancelAnimationFrame(ctx.timerHandle);
  clearTimeout(ctx.bannerTimer);
  ctx.victoryOverlay?.remove();
  ctx = null;
}
