/**
 * The board: squares, cartoon snakes and ladders, and the tokens on top.
 *
 * Layout is a 10×10 CSS grid; the snakes and ladders are one SVG overlay drawn
 * in percentage units so everything scales together at any board size. Tokens
 * are absolutely positioned over the grid and animated by moving them between
 * square centres.
 *
 * Crowding: with 15 players a square can get busy, so tokens on the same square
 * are laid out in a compact cluster, and past three they collapse into two
 * plus a "+n" badge that expands on tap or hover.
 */

import { el } from '../../shared/ui.js';

const SIZE = 10;

/** Where a square sits: row 0 is the bottom, columns run left to right. */
export function squareToCoords(square) {
  const index = square - 1;
  const row = Math.floor(index / SIZE);
  const offset = index % SIZE;
  const col = row % 2 === 0 ? offset : SIZE - 1 - offset;
  return { row, col };
}

/** Centre of a square as a percentage of the board, for SVG and positioning. */
export function squareCentre(square) {
  if (square < 1) {
    // The "start" pocket, just off the bottom-left corner.
    return { x: 5, y: 105 };
  }
  const { row, col } = squareToCoords(square);
  return { x: (col + 0.5) * 10, y: (SIZE - 1 - row + 0.5) * 10 };
}

/* ── Static board ────────────────────────────────────────────────────────── */

/**
 * Draw the 100 squares. Alternating tints keep the grid readable, and squares
 * that start a snake or ladder get a marker so the board is legible even
 * before the artwork loads.
 */
function buildSquares(config) {
  const grid = el('div', { class: 'board-grid' });

  // Rendered top row first (100 … 91), matching how a board is printed.
  for (let row = SIZE - 1; row >= 0; row--) {
    for (let col = 0; col < SIZE; col++) {
      const offset = row % 2 === 0 ? col : SIZE - 1 - col;
      const square = row * SIZE + offset + 1;

      const ladderTo = config.ladders[square];
      const snakeTo = config.snakes[square];
      const classes = ['square'];
      if ((row + col) % 2 === 0) classes.push('is-alt');
      if (ladderTo) classes.push('is-ladder-foot');
      if (snakeTo) classes.push('is-snake-head');
      if (square === 100) classes.push('is-home');

      grid.appendChild(
        el(
          'div',
          { class: classes.join(' '), dataset: { square: String(square) } },
          el('span', { class: 'square-number', text: String(square) }),
          square === 100 ? el('span', { class: 'square-flag', text: '🏁' }) : null,
          ladderTo ? el('span', { class: 'square-hint', text: `↑${ladderTo}` }) : null,
          snakeTo ? el('span', { class: 'square-hint', text: `↓${snakeTo}` }) : null,
        ),
      );
    }
  }
  return grid;
}

const SVG_NS = 'http://www.w3.org/2000/svg';

/**
 * Build an SVG element.
 * SVG nodes must be created in the SVG namespace — `document.createElement`
 * would produce an HTML element that happens to be called <g> or <path>, and
 * the browser silently refuses to draw it.
 */
function svgEl(tag, attrs = {}, ...children) {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null) continue;
    if (key === 'style') {
      for (const [property, v] of Object.entries(value)) {
        if (property.startsWith('--')) node.style.setProperty(property, v);
        else node.style[property] = v;
      }
    } else {
      node.setAttribute(key, value);
    }
  }
  node.append(...children.filter(Boolean));
  return node;
}

/** A ladder: two rails and a set of rungs, drawn between two square centres. */
function drawLadder(from, to) {
  const a = squareCentre(from);
  const b = squareCentre(to);

  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const length = Math.hypot(dx, dy);
  // Perpendicular offset gives the two rails their separation.
  const nx = (-dy / length) * 1.6;
  const ny = (dx / length) * 1.6;

  const group = svgEl('g', { class: 'ladder' });

  for (const sign of [1, -1]) {
    group.appendChild(
      svgEl('line', {
        x1: a.x + nx * sign,
        y1: a.y + ny * sign,
        x2: b.x + nx * sign,
        y2: b.y + ny * sign,
        class: 'ladder-rail',
      }),
    );
  }

  const rungs = Math.max(3, Math.round(length / 6));
  for (let i = 1; i < rungs; i++) {
    const t = i / rungs;
    const px = a.x + dx * t;
    const py = a.y + dy * t;
    group.appendChild(
      svgEl('line', {
        x1: px + nx,
        y1: py + ny,
        x2: px - nx,
        y2: py - ny,
        class: 'ladder-rung',
      }),
    );
  }
  return group;
}

/**
 * A snake: a wavy body from head to tail, with a friendly face.
 * Deliberately cartoonish — big eyes, a smile and a little forked tongue.
 */
function drawSnake(head, tail, index) {
  const a = squareCentre(head);
  const b = squareCentre(tail);

  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const length = Math.hypot(dx, dy);
  // Alternate the curve direction so neighbouring snakes don't overlap.
  const bend = (index % 2 === 0 ? 1 : -1) * Math.min(14, length * 0.32);
  const nx = (-dy / length) * bend;
  const ny = (dx / length) * bend;

  const c1x = a.x + dx * 0.3 + nx;
  const c1y = a.y + dy * 0.3 + ny;
  const c2x = a.x + dx * 0.7 - nx;
  const c2y = a.y + dy * 0.7 - ny;

  const hue = (index * 47) % 360;
  const group = svgEl('g', { class: 'snake', style: { '--snake-hue': String(hue) } });

  const path = `M ${a.x} ${a.y} C ${c1x} ${c1y}, ${c2x} ${c2y}, ${b.x} ${b.y}`;
  group.appendChild(svgEl('path', { d: path, class: 'snake-body' }));
  group.appendChild(svgEl('path', { d: path, class: 'snake-belly' }));

  // Tail tip, so the thin end reads as a tail rather than a cut-off line.
  group.appendChild(svgEl('circle', { cx: b.x, cy: b.y, r: '0.8', class: 'snake-tail' }));

  // Head: aim the face along the first part of the curve.
  const angle = (Math.atan2(c1y - a.y, c1x - a.x) * 180) / Math.PI;
  const head_g = svgEl('g', { transform: `translate(${a.x} ${a.y}) rotate(${angle})` });
  head_g.appendChild(svgEl('ellipse', { cx: 0, cy: 0, rx: '3.4', ry: '2.8', class: 'snake-head' }));
  head_g.appendChild(svgEl('circle', { cx: '1.1', cy: '-1', r: '0.95', class: 'snake-eye' }));
  head_g.appendChild(svgEl('circle', { cx: '1.1', cy: '1', r: '0.95', class: 'snake-eye' }));
  head_g.appendChild(svgEl('circle', { cx: '1.45', cy: '-1', r: '0.42', class: 'snake-pupil' }));
  head_g.appendChild(svgEl('circle', { cx: '1.45', cy: '1', r: '0.42', class: 'snake-pupil' }));
  head_g.appendChild(
    svgEl('path', { d: 'M 3.2 0 L 5.2 -0.8 M 3.2 0 L 5.2 0.8', class: 'snake-tongue' }),
  );
  group.appendChild(head_g);

  return group;
}

/** The SVG layer holding every snake and ladder. */
function buildArt(config) {
  const svg = svgEl('svg', {
    class: 'board-art',
    viewBox: '0 0 100 100',
    preserveAspectRatio: 'none',
    'aria-hidden': 'true',
  });

  // Ladders first so snakes sit on top where they cross.
  Object.entries(config.ladders).forEach(([from, to]) => {
    svg.appendChild(drawLadder(Number(from), Number(to)));
  });
  Object.entries(config.snakes).forEach(([from, to], index) => {
    svg.appendChild(drawSnake(Number(from), Number(to), index));
  });

  return svg;
}

/* ── The board component ─────────────────────────────────────────────────── */

export function createBoard(config) {
  const tokenLayer = el('div', { class: 'token-layer' });
  const popover = el('div', { class: 'square-popover', hidden: true });

  const node = el(
    'div',
    { class: 'board' },
    buildSquares(config),
    buildArt(config),
    tokenLayer,
    popover,
  );

  /** id → { node, position } so we can animate without re-rendering. */
  const tokens = new Map();
  let expandedSquare = null;

  /* ── token layout ──────────────────────────────────────────────────────── */

  /**
   * Arrange every token, clustering those sharing a square.
   * Up to three sit side by side; beyond that two show plus a "+n" badge.
   */
  function layout() {
    const bySquare = new Map();
    for (const [id, token] of tokens) {
      const list = bySquare.get(token.position) ?? [];
      list.push(id);
      bySquare.set(token.position, list);
    }

    // Any leftover badges from the previous layout.
    for (const badge of node.querySelectorAll('.cluster-badge')) badge.remove();

    for (const [square, ids] of bySquare) {
      const centre = squareCentre(square);
      const expanded = expandedSquare === square;
      const visible = expanded ? ids.length : Math.min(ids.length, ids.length > 3 ? 2 : 3);

      ids.forEach((id, index) => {
        const token = tokens.get(id);
        if (!token) return;

        if (index >= visible) {
          // Hidden behind the badge — park it under the first token.
          token.node.style.opacity = '0';
          token.node.style.pointerEvents = 'none';
          place(token.node, centre.x, centre.y);
          return;
        }

        token.node.style.opacity = '';
        token.node.style.pointerEvents = '';

        // Fan the cluster out around the square's centre.
        const count = visible;
        const spread = expanded ? 2.6 : 2.1;
        const columns = Math.min(count, 3);
        const rows = Math.ceil(count / columns);
        const cx = index % columns;
        const cy = Math.floor(index / columns);
        const ox = (cx - (columns - 1) / 2) * spread;
        const oy = (cy - (rows - 1) / 2) * spread;

        place(token.node, centre.x + ox, centre.y + oy);
        token.node.style.zIndex = String(10 + index);
      });

      if (ids.length > 3 && !expanded) {
        const badge = el('button', {
          class: 'cluster-badge',
          type: 'button',
          text: `+${ids.length - 2}`,
          title: `${ids.length} tokens here — tap to expand`,
          style: { left: `${centre.x + 2.6}%`, top: `${centre.y + 2.2}%` },
          onClick: (event) => {
            event.stopPropagation();
            expandedSquare = expandedSquare === square ? null : square;
            layout();
          },
        });
        node.appendChild(badge);
      }
    }
  }

  function place(element, xPercent, yPercent) {
    element.style.left = `${xPercent}%`;
    element.style.top = `${yPercent}%`;
  }

  /** Collapse an expanded cluster when tapping elsewhere. */
  node.addEventListener('click', () => {
    if (expandedSquare !== null) {
      expandedSquare = null;
      layout();
    }
  });

  /* ── public API ────────────────────────────────────────────────────────── */

  return {
    node,

    /** Rebuild the token set (on game start, or when players come and go). */
    setTokens(list) {
      const seen = new Set();

      for (const token of list) {
        seen.add(token.id);
        let entry = tokens.get(token.id);

        if (!entry) {
          const face = el('div', {
            class: 'board-token',
            style: { '--token-color': token.color },
            title: token.name,
            dataset: { token: token.id },
          });
          face.appendChild(el('span', { class: 'board-token-label', text: token.initials }));
          tokenLayer.appendChild(face);
          entry = { node: face, position: token.position };
          tokens.set(token.id, entry);
        }

        entry.node.style.setProperty('--token-color', token.color);
        entry.node.querySelector('.board-token-label').textContent = token.initials;
        entry.node.classList.toggle('is-finished', Boolean(token.finished));
        entry.position = token.position;
      }

      for (const [id, entry] of tokens) {
        if (!seen.has(id)) {
          entry.node.remove();
          tokens.delete(id);
        }
      }

      layout();
    },

    /** Snap every token to the given positions with no animation. */
    syncPositions(list) {
      for (const token of list) {
        const entry = tokens.get(token.id);
        if (entry) entry.position = token.position;
      }
      layout();
    },

    /**
     * Animate one token along a path of squares.
     * Returns a promise that settles when the move is finished, so a whole
     * round can be awaited.
     */
    async moveToken(tokenId, path, { stepMs = 120, onStep = null } = {}) {
      const entry = tokens.get(tokenId);
      if (!entry || path.length === 0) return;

      entry.node.classList.add('is-moving');
      for (const square of path) {
        entry.position = square;
        layout();
        onStep?.(square);
        await wait(stepMs);
      }
      entry.node.classList.remove('is-moving');
    },

    /** Make a token unmistakable — used when tapping a name in the leaderboard. */
    pulse(tokenId) {
      const entry = tokens.get(tokenId);
      if (!entry) return;
      entry.node.classList.remove('is-pulsing');
      void entry.node.offsetWidth;
      entry.node.classList.add('is-pulsing');
      setTimeout(() => entry.node.classList.remove('is-pulsing'), 2000);
    },

    /** Briefly flag a square, e.g. the ladder or snake just triggered. */
    flashSquare(square, kind) {
      const cell = node.querySelector(`[data-square="${square}"]`);
      if (!cell) return;
      cell.classList.add(`flash-${kind}`);
      setTimeout(() => cell.classList.remove(`flash-${kind}`), 1200);
    },

    hasToken(tokenId) {
      return tokens.has(tokenId);
    },
  };
}

export const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * The squares a token visits on its way, so the walk can be animated hop by
 * hop before any ladder or snake takes effect.
 */
export function stepPath(move) {
  const steps = [];
  if (move.stuck || move.blocked) return steps;

  const direction = move.landed >= move.from ? 1 : -1;
  for (let square = move.from + direction; ; square += direction) {
    steps.push(square);
    if (square === move.landed) break;
    if (steps.length > 12) break; // safety net; a die can only move you six
  }
  return steps;
}
