/**
 * Bingo client.
 *
 * One tap does one of two things, decided entirely by whether the number has
 * been called yet:
 *   • already called → mark it on your card
 *   • not yet called → call it for everyone (only on your turn)
 *
 * Renders from the server's snapshot; the server owns the turn and validates
 * every mark and claim.
 */

import { connectGame, send, saveSession, loadSession, clearSession, getJSON, lastName }
  from '../../shared/net.js';
import { el, render, toast, confirmDialog, tokenFace, playerGrid, chatPanel, copyText, gameOverModal }
  from '../../shared/ui.js';
import { confetti, floatReaction, sound } from '../../shared/effects.js';
import { go, setLeaveGuard, clearLeaveGuard } from '../../shared/router.js';

const GAME_ID = 'bingo';
const LETTERS = ['B', 'I', 'N', 'G', 'O'];

/** The 12 ways to complete a line, mirrored from the server's rules. */
const LINES = (() => {
  const lines = [];
  for (let r = 0; r < 5; r++) lines.push([0, 1, 2, 3, 4].map((c) => r * 5 + c));
  for (let c = 0; c < 5; c++) lines.push([0, 1, 2, 3, 4].map((r) => r * 5 + c));
  lines.push([0, 6, 12, 18, 24]);
  lines.push([4, 8, 12, 16, 20]);
  return lines;
})();

const colorFor = (n) => `var(--col-${LETTERS[(n - 1) % 5].toLowerCase()})`;

let ctx = null;

export async function mount({ root, code, intent, name }) {
  const data = await getJSON(`/api/games/${GAME_ID}/config`);
  if (!data) {
    toast('Could not load the game.', 'is-warn');
    return go('/');
  }

  const socket = connectGame(GAME_ID);
  ctx = {
    root, code, socket,
    config: data.config,
    state: null,
    memberId: null,
    isSpectator: false,
    screen: null,
    nodes: {},
    chat: null,
    cardSignature: null,
    cells: [],
    previousMarked: new Set(),
  };

  wireSocket();

  const session = loadSession();
  const resumable = session && session.code === code && session.memberId;

  let response;
  if (resumable) response = await send(socket, 'bingo:rejoin', { code, memberId: session.memberId });
  if (!response?.ok && intent !== 'created') {
    response = await send(socket, 'bingo:join', {
      code,
      name: name || session?.name || lastName() || 'Player',
    });
  }
  if (!response?.ok && intent === 'created') response = { ok: true };

  if (!response?.ok) {
    clearSession();
    toast(response?.message ?? 'Could not join that room.', 'is-warn');
    return go('/join?code=' + code);
  }

  if (response.memberId) {
    ctx.memberId = response.memberId;
    ctx.isSpectator = Boolean(response.spectator);
    saveSession({ gameId: GAME_ID, code, memberId: response.memberId, name: name || session?.name });
  }
  if (response.message) toast(response.message, '', 4000);

  setLeaveGuard(async () => {
    if (ctx?.state?.state !== 'playing') return true;
    return confirmDialog({
      title: 'Leave the game?',
      body: 'A round is still in progress. Your card will drop out.',
      confirmLabel: 'Leave game',
      cancelLabel: 'Stay',
    });
  });
}

/* ── socket ──────────────────────────────────────────────────────────────── */

function wireSocket() {
  const { socket } = ctx;
  for (const event of ['bingo:welcome', 'bingo:state', 'bingo:called', 'bingo:chat',
    'bingo:reaction', 'bingo:gameOver']) socket.off(event);

  socket.on('bingo:welcome', (payload) => {
    ctx.memberId = payload.memberId;
    ctx.isSpectator = payload.isSpectator;
    ctx.pendingChat = payload.chat ?? [];
  });

  socket.on('bingo:state', applyState);

  socket.on('bingo:called', ({ number, by }) => {
    sound.dice();
    flashCalled(number);
    if (by && by.id !== ctx.memberId) ctx.chat?.addSystem(`${by.name} called ${number}`);
  });

  socket.on('bingo:chat', (message) => ctx.chat?.addMessage(message, ctx.memberId));
  socket.on('bingo:reaction', ({ emoji, name }) => floatReaction(emoji, name));

  socket.on('bingo:gameOver', ({ standings, winner }) => {
    if (winner) {
      confetti.celebrate();
      sound.win();
    }
    showVictory(standings, winner);
  });

  socket.on('connect', async () => {
    updateConnection(true);
    const session = loadSession();
    if (session?.code === ctx.code && session.memberId) {
      await send(ctx.socket, 'bingo:rejoin', { code: ctx.code, memberId: session.memberId });
    }
  });
  socket.on('disconnect', () => updateConnection(false));
}

function applyState(state) {
  if (!ctx) return;
  const previous = ctx.state;
  ctx.state = state;

  // A rematch must clear the victory overlay for *everyone*, not just whoever
  // pressed the button — otherwise it lingers and swallows their clicks.
  if (state.state !== 'ended' && ctx.victoryOverlay) {
    ctx.victoryOverlay.remove();
    ctx.victoryOverlay = null;
  }

  const want = state.state === 'lobby' ? 'lobby' : 'game';
  if (ctx.screen !== want) {
    ctx.screen = want;
    if (want === 'lobby') buildLobby();
    else buildGame();
  }

  if (want === 'lobby') updateLobby();
  else updateGame(previous);
}

/* ── lobby ───────────────────────────────────────────────────────────────── */

function buildLobby() {
  const players = el('div');
  const settings = el('div');
  const waiting = el('p', { class: 'lobby-waiting' });
  const countPill = el('span', { class: 'pill' });
  const startButton = el('button', {
    class: 'btn btn-go btn-lg',
    text: 'Start game',
    disabled: true,
    onClick: async () => {
      const response = await send(ctx.socket, 'bingo:start');
      if (!response.ok) toast(response.message, 'is-warn');
    },
  });

  ctx.chat = ctx.chat ?? chatPanel({
    reactions: ctx.config.reactions,
    onSend: (text) => send(ctx.socket, 'bingo:chat', { text }),
    onReact: reactWithCooldown,
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  ctx.nodes = { players, settings, waiting, countPill, startButton };

  render(
    ctx.root,
    el('section', { class: 'screen' },
      el('div', { class: 'wrap' },
        el('div', { class: 'setup-head' },
          backButton(),
          el('div', { class: 'setup-title' },
            el('span', { class: 'setup-icon', text: '🎱' }),
            el('h1', { text: 'Lobby' })),
        ),
        el('section', { class: 'panel code-panel' },
          el('p', { class: 'eyebrow', text: 'Share this code' }),
          el('button', {
            class: 'room-code',
            title: 'Click to copy',
            onClick: async () => {
              const ok = await copyText(ctx.code);
              toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.code}`, ok ? 'is-good' : '');
            },
          }, el('span', { text: ctx.code }), el('span', { class: 'copy-hint', text: '📋' })),
        ),
        el('section', { class: 'panel' },
          el('div', { class: 'panel-head' }, el('h2', { text: 'Players' }), countPill),
          players, waiting),
        el('section', { class: 'panel' },
          el('div', { class: 'panel-head' }, el('h2', { text: 'How it works' })),
          el('ol', { class: 'rules' },
            el('li', {}, 'Everyone gets the numbers ', el('strong', { text: '1–25' }), ' in a different order.'),
            el('li', { text: 'Players take turns calling a number — tap it on your own card.' }),
            el('li', { text: 'Everyone else marks that number wherever it sits.' }),
            el('li', {}, 'Each full row, column or diagonal earns a letter of ',
              el('strong', { text: 'B-I-N-G-O' }), '.'),
            el('li', { text: 'Spell all five, then hit the BINGO! button to win.' }),
          )),
        settings,
        el('div', { class: 'lobby-actions' }, startButton),
        ctx.chat.node,
      )),
  );
}

function updateLobby() {
  const { state, nodes } = ctx;
  const isHost = state.hostId === ctx.memberId;

  nodes.countPill.textContent = `${state.players.length} of ${state.maxPlayers} joined`;
  render(nodes.players, playerGrid(state.players, ctx.memberId));

  render(nodes.settings, isHost
    ? el('section', { class: 'panel' },
        el('div', { class: 'panel-head' }, el('h2', { text: 'Game setup' })),
        el('div', { class: 'setting-inline' },
          el('span', { class: 'eyebrow', text: 'Turn timer' }),
          el('div', { class: 'segmented' },
            ctx.config.timing.turnSecondsOptions.map((seconds) =>
              el('button', {
                type: 'button',
                text: seconds === 0 ? 'Off' : `${seconds}s`,
                class: state.rules.turnSeconds === seconds ? 'is-active' : '',
                onClick: async () => {
                  const r = await send(ctx.socket, 'bingo:configure', { turnSeconds: seconds });
                  if (!r.ok) toast(r.message, 'is-warn');
                },
              }))))
      )
    : null);

  const ready = state.players.filter((p) => p.connected).length;
  nodes.startButton.hidden = !isHost;
  nodes.startButton.disabled = ready < 2;
  nodes.waiting.textContent = ready < 2
    ? 'Waiting for one more player — share the code above.'
    : isHost ? 'Everyone in? Start whenever you like.'
      : `Waiting for ${state.players.find((p) => p.isHost)?.name ?? 'the host'} to start…`;
}

/* ── game ────────────────────────────────────────────────────────────────── */

function buildGame() {
  const grid = el('div', { class: 'bingo-card', role: 'grid', 'aria-label': 'Your card' });
  const progress = el('div', { class: 'progress' },
    LETTERS.map((letter, i) =>
      el('span', { class: 'progress-letter', dataset: { letter: String(i) }, text: letter })));
  const ballNumber = el('span', { class: 'ball-number', text: '—' });
  const ball = el('div', { class: 'ball', 'aria-live': 'polite' }, ballNumber);
  const calledBy = el('p', { class: 'called-by' });
  const turnLabel = el('p', { class: 'caller-status' });
  const history = el('div', { class: 'history-strip' });
  const scores = el('ol', { class: 'leaderboard' });
  const hint = el('p', { class: 'card-hint' });
  const timerBar = el('div', { class: 'timer-bar' }, el('div', { class: 'timer-fill' }));

  const claimButton = el('button', {
    class: 'btn btn-bingo',
    text: 'BINGO!',
    onClick: async () => {
      const response = await send(ctx.socket, 'bingo:claim');
      if (!response.ok) {
        toast(response.message ?? 'Not yet! Keep playing 😄', 'is-warn');
        sound.nope();
      }
    },
  });

  const connChip = el('span', { class: 'chip chip-status' },
    el('span', { class: 'status-dot' }), el('span', { class: 'conn-text', text: 'connected' }));

  grid.addEventListener('click', onCellTap);

  ctx.chat = ctx.chat ?? chatPanel({
    reactions: ctx.config.reactions,
    onSend: (text) => send(ctx.socket, 'bingo:chat', { text }),
    onReact: reactWithCooldown,
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  ctx.nodes = { grid, progress, ball, ballNumber, calledBy, turnLabel, history, scores, hint,
    claimButton, connChip, timerBar };

  render(
    ctx.root,
    el('section', { class: 'screen game-screen' },
      el('div', { class: 'wrap wrap-wide' },
        el('div', { class: 'topbar' },
          el('div', { class: 'topbar-left' },
            backButton(),
            el('button', {
              class: 'chip chip-code',
              onClick: async () => {
                const ok = await copyText(ctx.code);
                toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.code}`, ok ? 'is-good' : '');
              },
            }, el('span', { class: 'chip-label', text: 'Room' }), el('span', { text: ctx.code })),
            connChip),
          el('div', { class: 'topbar-right' },
            el('button', {
              class: 'icon-btn',
              title: 'Mute sounds',
              text: sound.muted ? '🔇' : '🔊',
              onClick: (e) => { e.currentTarget.textContent = sound.toggleMute() ? '🔇' : '🔊'; },
            }))),

        el('div', { class: 'game-shell' },
          el('main', { class: 'game-main' },
            el('section', { class: 'panel caller' },
              el('div', { class: 'caller-ball' }, ball),
              el('div', { class: 'caller-info' },
                calledBy, turnLabel, timerBar,
                el('div', { class: 'history' },
                  el('span', { class: 'history-label', text: 'Recent' }), history))),
            el('section', { class: 'panel card-panel' },
              el('div', { class: 'progress-wrap' },
                el('span', { class: 'progress-caption', text: 'Your lines' }), progress),
              grid, claimButton, hint)),

          el('div', { class: 'game-drawer' },
            el('button', {
              class: 'drawer-handle',
              type: 'button',
              onClick: (e) => {
                const open = e.currentTarget.closest('.game-shell').classList.toggle('drawer-open');
                e.currentTarget.textContent = open ? '▼  Hide players & chat' : '▲  Players & chat';
              },
            }, '▲  Players & chat'),
            el('aside', { class: 'game-side' },
              el('section', { class: 'panel board-side' },
                el('div', { class: 'panel-head' }, el('h2', { text: 'Players' })), scores),
              ctx.chat.node))),
      )),
  );

  startTimerLoop();
}

function updateGame() {
  const { state, nodes } = ctx;
  const you = state.you;

  // Ball + who called it.
  const number = state.lastCalled;
  if (number == null) {
    nodes.ball.classList.remove('has-number');
    nodes.ballNumber.textContent = '—';
  } else {
    nodes.ball.classList.add('has-number');
    nodes.ball.style.setProperty('--ball-color', colorFor(number));
    nodes.ballNumber.textContent = String(number);
  }

  const caller = state.players.find((p) => p.id === state.lastCallerId);
  nodes.calledBy.textContent = caller && number != null
    ? (caller.id === ctx.memberId ? 'You called' : `${caller.name} called`) : '';
  if (caller) nodes.calledBy.style.color = caller.color;

  const holder = state.players.find((p) => p.id === state.turnPlayerId);
  const yourTurn = state.turnPlayerId === ctx.memberId;
  nodes.turnLabel.textContent = ctx.isSpectator
    ? 'You are watching 👀'
    : state.state === 'ended' ? 'Round over 🎉'
      : state.phase === 'countdown' ? 'Get ready…'
        : yourTurn ? 'Your turn — tap any number to call it'
          : `Waiting for ${holder ? holder.name : 'a player'} to call…`;
  nodes.turnLabel.classList.toggle('is-your-turn', yourTurn && state.state === 'playing');

  // Recent calls, newest first.
  render(nodes.history, state.called.length
    ? state.called.slice(-5).reverse().map((v) =>
        el('span', { class: 'history-ball', style: { '--hb-color': colorFor(v) }, text: String(v) }))
    : el('span', { class: 'history-empty', text: 'Nothing called yet' }));

  renderCard();
  renderScores();

  nodes.hint.textContent = ctx.isSpectator ? 'Spectating — you have no card this round.'
    : state.state !== 'playing' ? 'Round over — here’s how your card finished.'
      : yourTurn ? 'Your turn: tap any unmarked number to call it for everyone.'
        : 'Tap a number once it has been called.';
  nodes.hint.classList.remove('is-warning');

  nodes.claimButton.hidden = ctx.isSpectator;
  nodes.claimButton.disabled = state.state !== 'playing' || !you;
  const lines = you ? countLines(new Set(you.marked)) : 0;
  nodes.claimButton.classList.toggle('is-ready', state.state === 'playing' && lines >= state.linesToWin);
}

function countLines(marked) {
  return LINES.filter((line) => line.every((i) => marked.has(i))).length;
}

function renderCard() {
  const { state, nodes } = ctx;
  const you = state.you;

  if (!you?.card) {
    render(nodes.grid);
    ctx.cardSignature = null;
    ctx.cells = [];
    return;
  }

  const signature = `${state.roundNumber}:${you.card.join(',')}`;
  if (signature !== ctx.cardSignature) {
    ctx.cells = you.card.map((value, index) =>
      el('button', {
        class: 'bingo-cell',
        type: 'button',
        dataset: { index: String(index) },
        style: { '--cell-color': colorFor(value) },
        'aria-label': String(value),
      }, el('span', { class: 'cell-num', text: String(value) })));
    render(nodes.grid, ctx.cells);
    ctx.cardSignature = signature;
    ctx.previousMarked = new Set(you.marked);
  }

  const marked = new Set(you.marked);
  const called = new Set(state.called);
  const playing = state.state === 'playing';
  const yourTurn = playing && state.turnPlayerId === ctx.memberId;

  ctx.cells.forEach((cell, index) => {
    const value = you.card[index];
    const isMarked = marked.has(index);

    if (isMarked && !ctx.previousMarked.has(index)) {
      cell.classList.add('stamping');
      cell.addEventListener('animationend', () => cell.classList.remove('stamping'), { once: true });
    }
    cell.classList.toggle('is-marked', isMarked);
    cell.classList.toggle('is-markable', playing && !isMarked && called.has(value));
    cell.disabled = !playing;
  });

  nodes.grid.classList.toggle('can-call', yourTurn);
  ctx.previousMarked = marked;

  const lines = countLines(marked);
  for (const [i, node] of [...nodes.progress.children].entries()) {
    node.classList.toggle('is-earned', i < lines);
  }
}

function renderScores() {
  const { state, nodes } = ctx;
  const byId = Object.fromEntries((state.scores ?? []).map((s) => [s.id, s]));

  render(nodes.scores, state.players.map((player) => {
    const score = byId[player.id] ?? { lineCount: 0 };
    const isTurn = state.turnPlayerId === player.id && state.state === 'playing';
    return el('li', {
      class: `leader-row${player.id === ctx.memberId ? ' is-you' : ''}${isTurn ? ' is-turn' : ''}`,
    },
      tokenFace(player, { small: true, offline: !player.connected }),
      el('span', { class: 'leader-name', text: player.name }),
      el('span', { class: 'score' },
        LETTERS.map((letter, i) =>
          el('span', { class: `pip${i < score.lineCount ? ' is-earned' : ''}`, text: letter }))));
  }));
}

/** The one gesture: call an uncalled number, or mark a called one. */
async function onCellTap(event) {
  const cell = event.target.closest('.bingo-cell');
  const { state } = ctx;
  if (!cell || !state?.you?.card || state.state !== 'playing') return;

  const index = Number(cell.dataset.index);
  const number = state.you.card[index];
  const isMarked = state.you.marked.includes(index);
  const isCalled = state.called.includes(number);

  if (isMarked) {
    optimistic(index, false);
    const r = await send(ctx.socket, 'bingo:unmark', { index });
    if (!r.ok) optimistic(index, true);
    return;
  }

  if (isCalled) {
    optimistic(index, true);
    const r = await send(ctx.socket, 'bingo:mark', { index });
    if (!r.ok) optimistic(index, false);
    return;
  }

  if (state.turnPlayerId !== ctx.memberId) {
    const holder = state.players.find((p) => p.id === state.turnPlayerId);
    cell.classList.remove('shake');
    void cell.offsetWidth;
    cell.classList.add('shake');
    ctx.nodes.hint.textContent = holder ? `Hold on — it's ${holder.name}'s turn to call.` : 'Not your turn yet.';
    ctx.nodes.hint.classList.add('is-warning');
    sound.nope();
    return;
  }

  optimistic(index, true);
  const r = await send(ctx.socket, 'bingo:call', { number });
  if (!r.ok) {
    optimistic(index, false);
    toast(r.message, 'is-warn');
  }
}

function optimistic(index, on) {
  const cell = ctx.cells[index];
  if (!cell) return;
  cell.classList.toggle('is-marked', on);
  if (on) {
    cell.classList.remove('is-markable');
    cell.classList.add('stamping');
    cell.addEventListener('animationend', () => cell.classList.remove('stamping'), { once: true });
    ctx.previousMarked.add(index);
  } else {
    ctx.previousMarked.delete(index);
  }
}

function flashCalled(number) {
  const card = ctx.state?.you?.card;
  if (!card) return;
  const index = card.indexOf(number);
  const cell = ctx.cells[index];
  if (!cell) return;
  cell.classList.add('just-called');
  setTimeout(() => cell.classList.remove('just-called'), 2200);
}

function startTimerLoop() {
  cancelAnimationFrame(ctx.timerHandle);
  const tick = () => {
    if (!ctx?.state) return;
    const fill = ctx.nodes.timerBar?.querySelector('.timer-fill');
    const total = (ctx.state.rules?.turnSeconds ?? 0) * 1000;
    if (fill && ctx.state.turnDeadline && total) {
      const left = Math.max(0, ctx.state.turnDeadline - Date.now());
      fill.style.width = `${(left / total) * 100}%`;
      fill.classList.toggle('is-urgent', left < 5000);
      ctx.nodes.timerBar.hidden = false;
    } else if (ctx.nodes.timerBar) {
      ctx.nodes.timerBar.hidden = true;
    }
    ctx.timerHandle = requestAnimationFrame(tick);
  };
  ctx.timerHandle = requestAnimationFrame(tick);
}

/* ── victory ─────────────────────────────────────────────────────────────── */

function showVictory(standings, winner) {
  ctx.victoryOverlay = gameOverModal({
    emoji: winner ? '🏆' : '🫖',
    title: winner
      ? (winner.id === ctx.memberId ? 'BINGO! You won!' : `${winner.name} wins!`)
      : 'Out of numbers!',
    subtitle: winner ? 'Five lines — B-I-N-G-O.' : 'Nobody spelled it this time.',
    content: [
      el('ol', { class: 'standings' },
        standings.map((entry) =>
          el('li', { class: 'standings-row' },
            el('span', { class: 'leader-place', text: `#${entry.place}` }),
            tokenFace(entry, { small: true }),
            el('span', { class: 'leader-name', text: entry.name }),
            el('span', {
              class: 'leader-pos',
              text: `${entry.lineCount} line${entry.lineCount === 1 ? '' : 's'}`,
            })))),
    ],
    primary: {
      label: 'Play again',
      onClick: async () => {
        const r = await send(ctx.socket, 'bingo:rematch');
        if (!r.ok) toast(r.message, 'is-warn');
        return !r.ok;
      },
    },
    dismissLabel: 'See the card',
    onBack: () => { clearLeaveGuard(); confetti.stop(); },
  }).node;
}

function backButton() {
  return el('button', {
    class: 'btn btn-ghost btn-sm',
    text: '← Games',
    onClick: async () => {
      const left = await go('/');
      if (left) {
        await send(ctx.socket, 'bingo:leave');
        clearSession();
        teardown();
      }
    },
  });
}

async function reactWithCooldown(emoji) {
  const r = await send(ctx.socket, 'bingo:react', { emoji });
  if (r.ok) ctx.chat?.coolDown(2000);
}

function updateConnection(online) {
  const chip = ctx?.nodes?.connChip;
  if (!chip) return;
  chip.classList.toggle('is-offline', !online);
  chip.querySelector('.conn-text').textContent = online ? 'connected' : 'reconnecting…';
}

function teardown() {
  if (!ctx) return;
  cancelAnimationFrame(ctx.timerHandle);
  ctx.victoryOverlay?.remove();
  ctx = null;
}
