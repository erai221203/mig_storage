/**
 * Tic Tac Toe client — a best-of-five match for two, with spectators welcome.
 * Renders from the server's snapshot; the server owns the turn and the board.
 */

import { connectGame, send, saveSession, loadSession, clearSession, getJSON, lastName }
  from '../../shared/net.js';
import { el, render, toast, confirmDialog, tokenFace, playerGrid, chatPanel, copyText, gameOverModal }
  from '../../shared/ui.js';
import { confetti, floatReaction, sound } from '../../shared/effects.js';
import { go, setLeaveGuard, clearLeaveGuard } from '../../shared/router.js';

const GAME_ID = 'tic-tac-toe';
let ctx = null;

export async function mount({ root, code, intent, name }) {
  const data = await getJSON(`/api/games/${GAME_ID}/config`);
  if (!data) {
    toast('Could not load the game.', 'is-warn');
    return go('/');
  }

  const socket = connectGame(GAME_ID);
  ctx = { root, code, socket, config: data.config, state: null, memberId: null,
    isSpectator: false, screen: null, nodes: {}, chat: null, cells: [] };

  wireSocket();

  const session = loadSession();
  let response;
  if (session && session.code === code && session.memberId) {
    response = await send(socket, 'ttt:rejoin', { code, memberId: session.memberId });
  }
  if (!response?.ok && intent !== 'created') {
    response = await send(socket, 'ttt:join', {
      code, name: name || session?.name || lastName() || 'Player',
    });
  }
  if (!response?.ok && intent === 'created') response = { ok: true };

  if (!response?.ok) {
    clearSession();
    toast(response?.message ?? 'Could not join that room.', 'is-warn');
    return go('/join?code=' + code);
  }

  if (response.memberId) {
    ctx.memberId = response.memberId;
    ctx.isSpectator = Boolean(response.spectator);
    saveSession({ gameId: GAME_ID, code, memberId: response.memberId, name: name || session?.name });
  }
  if (response.message) toast(response.message, '', 4000);

  setLeaveGuard(async () => {
    if (ctx?.state?.state !== 'playing') return true;
    return confirmDialog({
      title: 'Leave the match?',
      body: 'A match is still in progress. Your opponent will win by default.',
      confirmLabel: 'Leave match',
      cancelLabel: 'Stay',
    });
  });
}

function wireSocket() {
  const { socket } = ctx;
  for (const e of ['ttt:welcome', 'ttt:state', 'ttt:played', 'ttt:gameEnded',
    'ttt:matchOver', 'ttt:chat', 'ttt:reaction']) socket.off(e);

  socket.on('ttt:welcome', (payload) => {
    ctx.memberId = payload.memberId;
    ctx.isSpectator = payload.isSpectator;
    ctx.pendingChat = payload.chat ?? [];
    applyState(payload.state);
  });
  socket.on('ttt:state', applyState);
  socket.on('ttt:played', () => sound.hop());
  socket.on('ttt:gameEnded', ({ win }) => {
    if (win) sound.ladder();
    else {
      sound.nope();
      ctx.chat?.addSystem('A draw — nobody blinked.');
    }
  });
  socket.on('ttt:matchOver', ({ standings }) => {
    confetti.celebrate();
    sound.win();
    showVictory(standings);
  });
  socket.on('ttt:chat', (m) => ctx.chat?.addMessage(m, ctx.memberId));
  socket.on('ttt:reaction', ({ emoji, name }) => floatReaction(emoji, name));
  socket.on('connect', async () => {
    updateConnection(true);
    const session = loadSession();
    if (session?.code === ctx.code && session.memberId) {
      await send(ctx.socket, 'ttt:rejoin', { code: ctx.code, memberId: session.memberId });
    }
  });
  socket.on('disconnect', () => updateConnection(false));
}

function applyState(state) {
  if (!ctx) return;
  ctx.state = state;

  // A rematch must clear the victory overlay for *everyone*, not just whoever
  // pressed the button — otherwise it lingers and swallows their clicks.
  if (state.state !== 'ended' && ctx.victoryOverlay) {
    ctx.victoryOverlay.remove();
    ctx.victoryOverlay = null;
  }
  const want = state.state === 'lobby' ? 'lobby' : 'game';
  if (ctx.screen !== want) {
    ctx.screen = want;
    if (want === 'lobby') buildLobby();
    else buildGame();
  }
  if (want === 'lobby') updateLobby();
  else updateGame();
}

/* ── lobby ───────────────────────────────────────────────────────────────── */

function buildLobby() {
  const players = el('div');
  const settings = el('div');
  const waiting = el('p', { class: 'lobby-waiting' });
  const startButton = el('button', {
    class: 'btn btn-go btn-lg', text: 'Start match', disabled: true,
    onClick: async () => {
      const r = await send(ctx.socket, 'ttt:start');
      if (!r.ok) toast(r.message, 'is-warn');
    },
  });

  ctx.chat = ctx.chat ?? chatPanel({
    reactions: ctx.config.reactions,
    onSend: (text) => send(ctx.socket, 'ttt:chat', { text }),
    onReact: reactWithCooldown,
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  ctx.nodes = { players, settings, waiting, startButton };

  render(ctx.root,
    el('section', { class: 'screen' },
      el('div', { class: 'wrap' },
        el('div', { class: 'setup-head' }, backButton(),
          el('div', { class: 'setup-title' },
            el('span', { class: 'setup-icon', text: '⭕' }), el('h1', { text: 'Lobby' }))),
        el('section', { class: 'panel code-panel' },
          el('p', { class: 'eyebrow', text: 'Share this code' }),
          el('button', {
            class: 'room-code', title: 'Click to copy',
            onClick: async () => {
              const ok = await copyText(ctx.code);
              toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.code}`, ok ? 'is-good' : '');
            },
          }, el('span', { text: ctx.code }), el('span', { class: 'copy-hint', text: '📋' }))),
        el('section', { class: 'panel' },
          el('div', { class: 'panel-head' }, el('h2', { text: 'Players' })),
          players, waiting),
        settings,
        el('div', { class: 'lobby-actions' }, startButton),
        ctx.chat.node)));
}

function updateLobby() {
  const { state, nodes } = ctx;
  const isHost = state.hostId === ctx.memberId;
  render(nodes.players, playerGrid(state.players, ctx.memberId));

  render(nodes.settings, isHost
    ? el('section', { class: 'panel' },
        el('div', { class: 'panel-head' }, el('h2', { text: 'Match setup' })),
        el('div', { class: 'setting-inline' },
          el('span', { class: 'eyebrow', text: 'Play to' }),
          el('div', { class: 'segmented' },
            [1, 2, 3, 4].map((n) => el('button', {
              type: 'button', text: n === 1 ? '1 win' : `${n} wins`,
              class: state.rules.winsNeeded === n ? 'is-active' : '',
              onClick: () => send(ctx.socket, 'ttt:configure', { winsNeeded: n }),
            })))),
        el('div', { class: 'setting-inline' },
          el('span', { class: 'eyebrow', text: 'Move timer' }),
          el('div', { class: 'segmented' },
            ctx.config.timing.turnSecondsOptions.map((s) => el('button', {
              type: 'button', text: s === 0 ? 'Off' : `${s}s`,
              class: state.rules.turnSeconds === s ? 'is-active' : '',
              onClick: () => send(ctx.socket, 'ttt:configure', { turnSeconds: s }),
            })))))
    : null);

  const ready = state.players.filter((p) => p.connected).length;
  nodes.startButton.hidden = !isHost;
  nodes.startButton.disabled = ready < 2;
  nodes.waiting.textContent = ready < 2
    ? 'Waiting for an opponent — share the code above.'
    : isHost ? 'Both here. Start whenever you like.'
      : `Waiting for ${state.players.find((p) => p.isHost)?.name ?? 'the host'} to start…`;
}

/* ── game ────────────────────────────────────────────────────────────────── */

function buildGame() {
  const grid = el('div', { class: 'ttt-board', role: 'grid', 'aria-label': 'Board' });
  ctx.cells = Array.from({ length: 9 }, (_, index) =>
    el('button', {
      class: 'ttt-cell', type: 'button', dataset: { index: String(index) },
      'aria-label': `Square ${index + 1}`,
      onClick: () => playCell(index),
    }));
  render(grid, ctx.cells);

  const turnLabel = el('p', { class: 'caller-status' });
  const scoreRow = el('div', { class: 'ttt-score' });
  const gamePill = el('span', { class: 'pill' });
  const timerBar = el('div', { class: 'timer-bar' }, el('div', { class: 'timer-fill' }));
  const connChip = el('span', { class: 'chip chip-status' },
    el('span', { class: 'status-dot' }), el('span', { class: 'conn-text', text: 'connected' }));

  ctx.chat = ctx.chat ?? chatPanel({
    reactions: ctx.config.reactions,
    onSend: (text) => send(ctx.socket, 'ttt:chat', { text }),
    onReact: reactWithCooldown,
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  ctx.nodes = { grid, turnLabel, scoreRow, gamePill, timerBar, connChip };

  render(ctx.root,
    el('section', { class: 'screen game-screen' },
      el('div', { class: 'wrap' },
        el('div', { class: 'topbar' },
          el('div', { class: 'topbar-left' }, backButton(),
            el('button', {
              class: 'chip chip-code',
              onClick: async () => {
                const ok = await copyText(ctx.code);
                toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.code}`, ok ? 'is-good' : '');
              },
            }, el('span', { class: 'chip-label', text: 'Room' }), el('span', { text: ctx.code })),
            connChip),
          el('div', { class: 'topbar-right' }, gamePill,
            el('button', {
              class: 'icon-btn', title: 'Mute sounds', text: sound.muted ? '🔇' : '🔊',
              onClick: (e) => { e.currentTarget.textContent = sound.toggleMute() ? '🔇' : '🔊'; },
            }))),
        el('section', { class: 'panel ttt-panel' }, scoreRow, turnLabel, timerBar, grid),
        ctx.chat.node)));

  startTimerLoop();
}

function updateGame() {
  const { state, nodes } = ctx;

  nodes.gamePill.textContent = `Game ${state.gameNumber} · first to ${state.rules.winsNeeded}`;

  // Scoreboard: both players with their mark and win count.
  render(nodes.scoreRow, state.players.slice(0, 2).map((player) => {
    const isTurn = state.turnPlayerId === player.id;
    return el('div', {
      class: `ttt-score-card${player.id === ctx.memberId ? ' is-you' : ''}${isTurn ? ' is-turn' : ''}`,
    },
      tokenFace(player, { small: true, offline: !player.connected }),
      el('div', { class: 'ttt-score-meta' },
        el('span', { class: 'ttt-score-name', text: player.name }),
        el('span', { class: 'ttt-score-mark', text: state.marks[player.id] ?? '' })),
      el('span', { class: 'ttt-score-wins', text: String(state.wins[player.id] ?? 0) }));
  }));

  const holder = state.players.find((p) => p.id === state.turnPlayerId);
  const yourTurn = state.turnPlayerId === ctx.memberId;

  if (ctx.isSpectator) {
    nodes.turnLabel.textContent = holder ? `${holder.name} to play 👀` : 'Watching…';
  } else if (state.phase === 'gameOver') {
    const winner = state.lastWin && state.players.find((p) => p.id === state.lastWin.playerId);
    nodes.turnLabel.textContent = winner
      ? (winner.id === ctx.memberId ? 'You take that one! 🎉' : `${winner.name} takes that one.`)
      : 'A draw — nobody blinked.';
  } else if (state.state === 'ended') {
    nodes.turnLabel.textContent = 'Match over.';
  } else {
    nodes.turnLabel.textContent = yourTurn
      ? `Your turn — you're ${state.marks[ctx.memberId]}`
      : `${holder ? holder.name : 'Someone'} is thinking…`;
  }
  nodes.turnLabel.classList.toggle('is-your-turn', yourTurn && state.phase === 'turn');

  const winningCells = new Set(state.lastWin?.line ?? []);
  ctx.cells.forEach((cell, index) => {
    const mark = state.board[index];
    cell.textContent = mark ?? '';
    cell.classList.toggle('is-x', mark === 'X');
    cell.classList.toggle('is-o', mark === 'O');
    cell.classList.toggle('is-winning', winningCells.has(index));
    cell.disabled = !(yourTurn && state.phase === 'turn' && mark === null);
  });
  nodes.grid.classList.toggle('is-yours', yourTurn && state.phase === 'turn');
}

async function playCell(index) {
  const r = await send(ctx.socket, 'ttt:play', { index });
  if (!r.ok) {
    toast(r.message ?? 'Cannot play there.', 'is-warn');
    sound.nope();
  }
}

function startTimerLoop() {
  cancelAnimationFrame(ctx.timerHandle);
  const tick = () => {
    if (!ctx?.state) return;
    const fill = ctx.nodes.timerBar?.querySelector('.timer-fill');
    const total = (ctx.state.rules?.turnSeconds ?? 0) * 1000;
    if (fill && ctx.state.turnDeadline && total) {
      const left = Math.max(0, ctx.state.turnDeadline - Date.now());
      fill.style.width = `${(left / total) * 100}%`;
      fill.classList.toggle('is-urgent', left < 4000);
      ctx.nodes.timerBar.hidden = false;
    } else if (ctx.nodes.timerBar) {
      ctx.nodes.timerBar.hidden = true;
    }
    ctx.timerHandle = requestAnimationFrame(tick);
  };
  ctx.timerHandle = requestAnimationFrame(tick);
}

function showVictory(standings) {
  const winner = standings.find((s) => s.isWinner) ?? standings[0];
  ctx.victoryOverlay = gameOverModal({
    emoji: '🏆',
    title: winner?.id === ctx.memberId ? 'You win the match!' : `${winner?.name} wins!`,
    content: [
      el('ol', { class: 'standings' },
        standings.map((entry) =>
          el('li', { class: 'standings-row' },
            el('span', { class: 'leader-place', text: `#${entry.place}` }),
            tokenFace(entry, { small: true }),
            el('span', { class: 'leader-name', text: `${entry.name} (${entry.mark ?? '–'})` }),
            el('span', { class: 'leader-pos', text: `${entry.wins}` })))),
    ],
    primary: {
      label: 'Play again',
      onClick: async () => {
        const r = await send(ctx.socket, 'ttt:rematch');
        if (!r.ok) toast(r.message, 'is-warn');
        return !r.ok; // keep the card open if it failed
      },
    },
    dismissLabel: 'See the board',
    onBack: () => { clearLeaveGuard(); confetti.stop(); },
  }).node;
}

function backButton() {
  return el('button', {
    class: 'btn btn-ghost btn-sm', text: '← Games',
    onClick: async () => {
      const left = await go('/');
      if (left) {
        await send(ctx.socket, 'ttt:leave');
        clearSession();
        teardown();
      }
    },
  });
}

async function reactWithCooldown(emoji) {
  const r = await send(ctx.socket, 'ttt:react', { emoji });
  if (r.ok) ctx.chat?.coolDown(2000);
}

function updateConnection(online) {
  const chip = ctx?.nodes?.connChip;
  if (!chip) return;
  chip.classList.toggle('is-offline', !online);
  chip.querySelector('.conn-text').textContent = online ? 'connected' : 'reconnecting…';
}

function teardown() {
  if (!ctx) return;
  cancelAnimationFrame(ctx.timerHandle);
  ctx.victoryOverlay?.remove();
  ctx = null;
}
