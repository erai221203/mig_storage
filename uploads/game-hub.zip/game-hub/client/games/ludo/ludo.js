/**
 * Ludo client.
 *
 * A turn is two beats: roll, then pick a token. The server decides both the
 * die and which tokens may legally move — the client only ever offers the list
 * it was given, and (as in Snake & Ladder) a token never moves until the die
 * has stopped on its real number.
 */

import { connectGame, send, saveSession, loadSession, clearSession, getJSON, lastName }
  from '../../shared/net.js';
import { el, render, toast, confirmDialog, tokenFace, playerGrid, chatPanel, copyText, gameOverModal }
  from '../../shared/ui.js';
import { confetti, floatReaction, sound } from '../../shared/effects.js';
import { go, setLeaveGuard, clearLeaveGuard } from '../../shared/router.js';

const GAME_ID = 'ludo';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

let ctx = null;

export async function mount({ root, code, intent, name }) {
  const data = await getJSON(`/api/games/${GAME_ID}/config`);
  if (!data) {
    toast('Could not load the game.', 'is-warn');
    return go('/');
  }

  const socket = connectGame(GAME_ID);
  ctx = {
    root, code, socket,
    config: data.config,
    seats: Object.fromEntries(data.config.seats.map((s) => [s.id, s])),
    state: null, memberId: null, isSpectator: false,
    screen: null, nodes: {}, chat: null,
    tokenNodes: new Map(), // `${seatId}:${index}` → element
    animating: false,
  };

  wireSocket();

  const session = loadSession();
  let response;
  if (session && session.code === code && session.memberId) {
    response = await send(socket, 'ludo:rejoin', { code, memberId: session.memberId });
  }
  if (!response?.ok && intent !== 'created') {
    response = await send(socket, 'ludo:join', {
      code, name: name || session?.name || lastName() || 'Player',
    });
  }
  if (!response?.ok && intent === 'created') response = { ok: true };

  if (!response?.ok) {
    clearSession();
    toast(response?.message ?? 'Could not join that room.', 'is-warn');
    return go('/join?code=' + code);
  }

  if (response.memberId) {
    ctx.memberId = response.memberId;
    ctx.isSpectator = Boolean(response.spectator);
    saveSession({ gameId: GAME_ID, code, memberId: response.memberId, name: name || session?.name });
  }
  if (response.message) toast(response.message, '', 4000);

  setLeaveGuard(async () => {
    if (ctx?.state?.state !== 'playing') return true;
    return confirmDialog({
      title: 'Leave the game?',
      body: 'A game is still in progress. Your tokens will drop out.',
      confirmLabel: 'Leave game',
      cancelLabel: 'Stay',
    });
  });
}

/* ── socket ──────────────────────────────────────────────────────────────── */

function wireSocket() {
  const { socket } = ctx;
  for (const e of ['ludo:welcome', 'ludo:state', 'ludo:rolled', 'ludo:moved', 'ludo:forfeit',
    'ludo:playerHome', 'ludo:gameOver', 'ludo:chat', 'ludo:reaction']) socket.off(e);

  socket.on('ludo:welcome', (payload) => {
    ctx.memberId = payload.memberId;
    ctx.isSpectator = payload.isSpectator;
    ctx.pendingChat = payload.chat ?? [];
    applyState(payload.state);
  });
  socket.on('ludo:state', applyState);

  socket.on('ludo:rolled', ({ die, playerId }) => {
    revealDie(die, playerId === ctx.memberId).catch(() => {});
  });

  socket.on('ludo:moved', (move) => {
    animateMove(move).catch((error) => console.error('[ludo] animation failed', error));
  });

  socket.on('ludo:forfeit', ({ playerId }) => {
    const who = ctx.state?.players.find((p) => p.id === playerId);
    ctx.chat?.addSystem(`${who ? who.name : 'Someone'} rolled three sixes — turn forfeited!`);
    sound.nope();
  });

  socket.on('ludo:playerHome', ({ playerId, place }) => {
    const who = ctx.state?.players.find((p) => p.id === playerId);
    ctx.chat?.addSystem(`${who ? who.name : 'Someone'} is home — #${place}! 🏁`);
    if (playerId === ctx.memberId) confetti.celebrate();
  });

  socket.on('ludo:gameOver', ({ standings }) => {
    confetti.celebrate();
    sound.win();
    showVictory(standings);
  });

  socket.on('ludo:chat', (m) => ctx.chat?.addMessage(m, ctx.memberId));
  socket.on('ludo:reaction', ({ emoji, name }) => floatReaction(emoji, name));

  socket.on('connect', async () => {
    updateConnection(true);
    const session = loadSession();
    if (session?.code === ctx.code && session.memberId) {
      await send(ctx.socket, 'ludo:rejoin', { code: ctx.code, memberId: session.memberId });
    }
  });
  socket.on('disconnect', () => updateConnection(false));
}

function applyState(state) {
  if (!ctx) return;
  ctx.state = state;

  // A rematch must clear the victory overlay for *everyone*, not just whoever
  // pressed the button — otherwise it lingers and swallows their clicks.
  if (state.state !== 'ended' && ctx.victoryOverlay) {
    ctx.victoryOverlay.remove();
    ctx.victoryOverlay = null;
  }
  const want = state.state === 'lobby' ? 'lobby' : 'game';
  if (ctx.screen !== want) {
    ctx.screen = want;
    if (want === 'lobby') buildLobby();
    else buildGame();
  }
  if (want === 'lobby') updateLobby();
  else updateGame();
}

/* ── lobby ───────────────────────────────────────────────────────────────── */

function buildLobby() {
  const players = el('div');
  const settings = el('div');
  const waiting = el('p', { class: 'lobby-waiting' });
  const countPill = el('span', { class: 'pill' });
  const startButton = el('button', {
    class: 'btn btn-go btn-lg', text: 'Start game', disabled: true,
    onClick: async () => {
      const r = await send(ctx.socket, 'ludo:start');
      if (!r.ok) toast(r.message, 'is-warn');
    },
  });

  ctx.chat = ctx.chat ?? chatPanel({
    reactions: ctx.config.reactions,
    onSend: (text) => send(ctx.socket, 'ludo:chat', { text }),
    onReact: reactWithCooldown,
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  ctx.nodes = { players, settings, waiting, countPill, startButton };

  render(ctx.root,
    el('section', { class: 'screen' },
      el('div', { class: 'wrap' },
        el('div', { class: 'setup-head' }, backButton(),
          el('div', { class: 'setup-title' },
            el('span', { class: 'setup-icon', text: '🎲' }), el('h1', { text: 'Lobby' }))),
        el('section', { class: 'panel code-panel' },
          el('p', { class: 'eyebrow', text: 'Share this code' }),
          el('button', {
            class: 'room-code', title: 'Click to copy',
            onClick: async () => {
              const ok = await copyText(ctx.code);
              toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.code}`, ok ? 'is-good' : '');
            },
          }, el('span', { text: ctx.code }), el('span', { class: 'copy-hint', text: '📋' }))),
        el('section', { class: 'panel' },
          el('div', { class: 'panel-head' }, el('h2', { text: 'Players' }), countPill),
          players, waiting),
        el('section', { class: 'panel' },
          el('div', { class: 'panel-head' }, el('h2', { text: 'How it works' })),
          el('ol', { class: 'rules' },
            el('li', {}, 'Everyone gets ', el('strong', { text: 'four tokens' }), ' in their yard.'),
            el('li', {}, 'Roll a ', el('strong', { text: '6' }), ' to bring a token onto the board.'),
            el('li', { text: 'Land on an opponent and they go back to their yard — unless the square is a star.' }),
            el('li', { text: 'A 6, a capture or getting a token home all earn another roll.' }),
            el('li', {}, 'Get ', el('strong', { text: 'all four tokens home' }), ' — with an exact roll — to win.'))),
        settings,
        el('div', { class: 'lobby-actions' }, startButton),
        ctx.chat.node)));
}

function updateLobby() {
  const { state, nodes } = ctx;
  const isHost = state.hostId === ctx.memberId;
  const seats = ctx.config.seats;

  nodes.countPill.textContent = `${state.players.length} of ${state.maxPlayers} joined`;

  // Show which colour everyone will get — seats are handed out in join order.
  render(nodes.players,
    el('div', { class: 'player-grid' },
      state.players.map((player, index) => {
        const seat = seats[index];
        return el('div', {
          class: `player-card${player.id === ctx.memberId ? ' is-you' : ''}${player.connected ? '' : ' is-offline'}`,
        },
          el('div', {
            class: 'token-face',
            style: { '--token-color': seat?.color ?? player.color },
            text: player.initials,
            title: player.name,
          }),
          el('div', { style: { minWidth: 0 } },
            el('div', { class: 'player-card-name' }, player.name,
              player.isHost ? el('span', { class: 'crown', text: ' 👑' }) : null),
            el('div', { class: 'player-card-sub', text: seat ? seat.name : 'Watching' })));
      })));

  render(nodes.settings, isHost
    ? el('section', { class: 'panel' },
        el('div', { class: 'panel-head' }, el('h2', { text: 'Game setup' })),
        el('div', { class: 'setting-inline' },
          el('span', { class: 'eyebrow', text: 'Turn timer' }),
          el('div', { class: 'segmented' },
            ctx.config.timing.turnSecondsOptions.map((s) => el('button', {
              type: 'button', text: s === 0 ? 'Off' : `${s}s`,
              class: state.rules.turnSeconds === s ? 'is-active' : '',
              onClick: () => send(ctx.socket, 'ludo:configure', { turnSeconds: s }),
            })))))
    : null);

  const ready = state.players.filter((p) => p.connected).length;
  nodes.startButton.hidden = !isHost;
  nodes.startButton.disabled = ready < 2;
  nodes.waiting.textContent = ready < 2
    ? 'Waiting for one more player — share the code above.'
    : isHost ? 'Everyone in? Start whenever you like.'
      : `Waiting for ${state.players.find((p) => p.isHost)?.name ?? 'the host'} to start…`;
}

/* ── board ───────────────────────────────────────────────────────────────── */

/** Build the 15×15 grid once: yards, track, home columns and the centre. */
function buildBoard() {
  const { config } = ctx;
  const grid = el('div', { class: 'ludo-grid' });

  // Index every special square so the loop below can tint it.
  const trackAt = new Map();
  config.track.forEach(([row, col], index) => trackAt.set(`${row},${col}`, index));

  const homeAt = new Map();
  const yardAt = new Map();
  for (const seat of config.seats) {
    seat.homeColumn.forEach(([row, col]) => homeAt.set(`${row},${col}`, seat));
    seat.yard.forEach(([row, col]) => yardAt.set(`${row},${col}`, seat));
  }

  // Which quadrant a cell falls in, for the big yard blocks.
  const quadrantOf = (row, col) => {
    if (row < 6 && col < 6) return config.seats[0];
    if (row < 6 && col > 8) return config.seats[1];
    if (row > 8 && col > 8) return config.seats[2];
    if (row > 8 && col < 6) return config.seats[3];
    return null;
  };

  const safe = new Set(config.safeSquares);

  for (let row = 0; row < config.grid; row++) {
    for (let col = 0; col < config.grid; col++) {
      const key = `${row},${col}`;
      const classes = ['ludo-cell'];
      let color = null;
      let content = null;

      const trackIndex = trackAt.get(key);
      const homeSeat = homeAt.get(key);
      const yardSeat = yardAt.get(key);
      const quadrant = quadrantOf(row, col);

      if (row === 7 && col === 7) {
        classes.push('is-centre');
        content = el('span', { class: 'centre-star', text: '🏠' });
      } else if (homeSeat) {
        classes.push('is-home-column');
        color = homeSeat.color;
      } else if (trackIndex !== undefined) {
        classes.push('is-track');
        // A colour's own start square is tinted; stars get a marker.
        const startSeat = config.seats.find((s) => s.startIndex === trackIndex);
        if (startSeat) {
          classes.push('is-start');
          color = startSeat.color;
        } else if (safe.has(trackIndex)) {
          classes.push('is-safe');
          content = el('span', { class: 'safe-star', text: '★' });
        }
      } else if (yardSeat) {
        classes.push('is-yard-slot');
        color = yardSeat.color;
      } else if (quadrant) {
        classes.push('is-yard');
        color = quadrant.color;
      } else {
        classes.push('is-blank');
      }

      grid.appendChild(el('div', {
        class: classes.join(' '),
        style: color ? { '--cell-color': color } : null,
        dataset: { row: String(row), col: String(col) },
      }, content));
    }
  }

  return grid;
}

/** Where a token sits, as a percentage of the board. */
function cellCentre(row, col) {
  const size = ctx.config.grid;
  return { x: ((col + 0.5) / size) * 100, y: ((row + 0.5) / size) * 100 };
}

/** Mirror of the server's geometry: position → [row, col]. */
function cellFor(seat, position, tokenIndex) {
  const { config } = ctx;
  if (position < 0) return seat.yard[tokenIndex];
  if (position >= config.homePosition) return [7, 7];
  if (position >= config.trackLength) return seat.homeColumn[position - config.trackLength];
  return config.track[(seat.startIndex + position) % config.trackLength];
}

function placeToken(node, seat, position, tokenIndex, stackOffset = 0) {
  const [row, col] = cellFor(seat, position, tokenIndex);
  const { x, y } = cellCentre(row, col);
  node.style.left = `${x + stackOffset * 1.1}%`;
  node.style.top = `${y + stackOffset * 1.1}%`;
}

/** Lay every token out, fanning any that share a square. */
function layoutTokens() {
  const { state } = ctx;
  if (!state?.tokens) return;

  // Group by the board cell each token occupies.
  const byCell = new Map();
  for (const [seatId, positions] of Object.entries(state.tokens)) {
    const seat = ctx.seats[seatId];
    positions.forEach((position, index) => {
      const [row, col] = cellFor(seat, position, index);
      const key = `${row},${col}`;
      const list = byCell.get(key) ?? [];
      list.push({ seatId, index, position });
      byCell.set(key, list);
    });
  }

  for (const group of byCell.values()) {
    group.forEach((entry, order) => {
      const node = ctx.tokenNodes.get(`${entry.seatId}:${entry.index}`);
      if (!node) return;
      // Only fan out tokens that are actually sharing a square.
      const offset = group.length > 1 ? order - (group.length - 1) / 2 : 0;
      placeToken(node, ctx.seats[entry.seatId], entry.position, entry.index, offset);
      node.style.zIndex = String(10 + order);
    });
  }
}

/* ── game screen ─────────────────────────────────────────────────────────── */

function buildGame() {
  const boardGrid = buildBoard();
  const tokenLayer = el('div', { class: 'ludo-tokens' });
  const board = el('div', { class: 'ludo-board' }, boardGrid, tokenLayer);

  const dieFace = el('div', { class: 'die', 'aria-live': 'polite' });
  const turnLabel = el('p', { class: 'caller-status' });
  const hint = el('p', { class: 'card-hint' });
  const timerBar = el('div', { class: 'timer-bar' }, el('div', { class: 'timer-fill' }));
  const scores = el('ol', { class: 'leaderboard' });
  const roundPill = el('span', { class: 'pill' });

  const rollButton = el('button', { class: 'btn btn-roll', text: 'ROLL!', onClick: doRoll });

  const connChip = el('span', { class: 'chip chip-status' },
    el('span', { class: 'status-dot' }), el('span', { class: 'conn-text', text: 'connected' }));

  ctx.chat = ctx.chat ?? chatPanel({
    reactions: ctx.config.reactions,
    onSend: (text) => send(ctx.socket, 'ludo:chat', { text }),
    onReact: reactWithCooldown,
  });
  if (ctx.pendingChat) ctx.chat.setHistory(ctx.pendingChat, ctx.memberId);

  tokenLayer.addEventListener('click', onTokenTap);

  ctx.nodes = { board, tokenLayer, dieFace, turnLabel, hint, timerBar, scores,
    rollButton, roundPill, connChip };

  render(ctx.root,
    el('section', { class: 'screen game-screen' },
      el('div', { class: 'wrap wrap-wide' },
        el('div', { class: 'topbar' },
          el('div', { class: 'topbar-left' }, backButton(),
            el('button', {
              class: 'chip chip-code',
              onClick: async () => {
                const ok = await copyText(ctx.code);
                toast(ok ? 'Room code copied 📋' : `Room code: ${ctx.code}`, ok ? 'is-good' : '');
              },
            }, el('span', { class: 'chip-label', text: 'Room' }), el('span', { text: ctx.code })),
            connChip),
          el('div', { class: 'topbar-right' },
            el('button', {
              class: 'icon-btn', title: 'Mute sounds', text: sound.muted ? '🔇' : '🔊',
              onClick: (e) => { e.currentTarget.textContent = sound.toggleMute() ? '🔇' : '🔊'; },
            }))),

        el('div', { class: 'game-shell' },
          el('main', { class: 'game-main' }, board),
          el('div', { class: 'game-drawer' },
            el('button', {
              class: 'drawer-handle', type: 'button',
              onClick: (e) => {
                const open = e.currentTarget.closest('.game-shell').classList.toggle('drawer-open');
                e.currentTarget.textContent = open ? '▼  Hide players & chat' : '▲  Players & chat';
              },
            }, '▲  Players & chat'),
            el('aside', { class: 'game-side' },
              el('section', { class: 'panel play-panel' },
                turnLabel, dieFace, timerBar, rollButton, hint),
              el('section', { class: 'panel board-side' },
                el('div', { class: 'panel-head' }, el('h2', { text: 'Tokens home' }), roundPill),
                scores),
              ctx.chat.node))))));

  buildTokens();
  startTimerLoop();
}

/** Create one node per token, once. */
function buildTokens() {
  const { state, nodes } = ctx;
  ctx.tokenNodes.clear();
  nodes.tokenLayer.replaceChildren();

  for (const [seatId, positions] of Object.entries(state.tokens ?? {})) {
    const seat = ctx.seats[seatId];
    const owner = state.order.find((id) => state.seatOf[id] === seatId);
    const player = state.players.find((p) => p.id === owner);

    positions.forEach((_, index) => {
      const node = el('button', {
        class: 'ludo-token',
        type: 'button',
        style: { '--token-color': seat.color },
        dataset: { seat: seatId, index: String(index) },
        title: player ? `${player.name} — token ${index + 1}` : `Token ${index + 1}`,
      }, el('span', { class: 'ludo-token-label', text: player?.initials ?? seat.emoji }));
      nodes.tokenLayer.appendChild(node);
      ctx.tokenNodes.set(`${seatId}:${index}`, node);
    });
  }
  layoutTokens();
}

function updateGame() {
  const { state, nodes } = ctx;

  // Rebuild the token set only when the seating actually changes.
  const signature = Object.keys(state.tokens ?? {}).join();
  if (signature !== ctx.tokenSignature) {
    ctx.tokenSignature = signature;
    buildTokens();
  } else if (!ctx.animating) {
    layoutTokens();
  }

  nodes.roundPill.textContent = `Turn ${state.roundNumber}`;

  const holder = state.players.find((p) => p.id === state.turnPlayerId);
  const mine = state.turnPlayerId === ctx.memberId;
  const mySeat = ctx.seats[state.seatOf[ctx.memberId]];

  if (ctx.isSpectator) {
    nodes.turnLabel.textContent = holder ? `${holder.name} to play 👀` : 'Watching…';
  } else if (state.state === 'ended') {
    nodes.turnLabel.textContent = 'Game over.';
  } else if (state.phase === 'countdown') {
    nodes.turnLabel.textContent = mySeat ? `You are ${mySeat.name} ${mySeat.emoji}` : 'Get ready…';
  } else if (mine && state.phase === 'roll') {
    nodes.turnLabel.textContent = 'Your turn — roll!';
  } else if (mine && state.phase === 'choose') {
    nodes.turnLabel.textContent = `You rolled ${state.die} — pick a token`;
  } else if (state.phase === 'moving') {
    nodes.turnLabel.textContent = 'Moving…';
  } else {
    nodes.turnLabel.textContent = `${holder ? holder.name : 'Someone'} is playing…`;
  }
  nodes.turnLabel.classList.toggle('is-your-turn', mine && state.state === 'playing');

  nodes.rollButton.hidden = ctx.isSpectator;
  nodes.rollButton.disabled = !(mine && state.phase === 'roll') || ctx.animating;
  nodes.rollButton.classList.toggle('is-ready',
    mine && state.phase === 'roll' && !ctx.animating);

  // Mark the tokens the server says may move, so only those are tappable.
  const movable = new Set(
    mine && state.phase === 'choose' && !ctx.animating
      ? state.moves.map((m) => m.tokenIndex) : [],
  );
  const seatId = state.seatOf[ctx.memberId];
  for (const [key, node] of ctx.tokenNodes) {
    const [tokenSeat, indexText] = key.split(':');
    const can = tokenSeat === seatId && movable.has(Number(indexText));
    node.classList.toggle('is-movable', can);
    node.disabled = !can;
  }

  if (ctx.isSpectator) nodes.hint.textContent = 'Spectating — enjoy the chaos.';
  else if (state.phase === 'choose' && mine) {
    nodes.hint.textContent = state.moves.length
      ? 'Tap one of your glowing tokens.' : 'No legal moves this roll.';
  } else if (state.phase === 'roll' && mine) {
    nodes.hint.textContent = 'A 6 gets a token out of the yard — and earns another roll.';
  } else {
    nodes.hint.textContent = '';
  }

  renderScores();
}

function renderScores() {
  const { state, nodes } = ctx;
  const byId = Object.fromEntries((state.scores ?? []).map((s) => [s.id, s]));

  const ordered = [...state.order].sort((a, b) => {
    const finishedA = state.finished.indexOf(a);
    const finishedB = state.finished.indexOf(b);
    if (finishedA !== -1 && finishedB !== -1) return finishedA - finishedB;
    if (finishedA !== -1) return -1;
    if (finishedB !== -1) return 1;
    return (byId[b]?.progress ?? 0) - (byId[a]?.progress ?? 0);
  });

  render(nodes.scores, ordered.map((playerId) => {
    const player = state.players.find((p) => p.id === playerId);
    if (!player) return null;
    const seat = ctx.seats[state.seatOf[playerId]];
    const score = byId[playerId] ?? { home: 0 };
    const isTurn = state.turnPlayerId === playerId && state.state === 'playing';

    return el('li', {
      class: `leader-row${playerId === ctx.memberId ? ' is-you' : ''}${isTurn ? ' is-turn' : ''}`,
    },
      el('div', {
        class: 'token-face is-small',
        style: { '--token-color': seat?.color },
        text: player.initials,
      }),
      el('span', { class: 'leader-name', text: player.name }),
      el('span', { class: 'ludo-home-count' },
        Array.from({ length: ctx.config.tokensPerPlayer }, (_, i) =>
          el('span', { class: `home-pip${i < score.home ? ' is-home' : ''}` }))));
  }).filter(Boolean));
}

/* ── actions ─────────────────────────────────────────────────────────────── */

async function doRoll() {
  if (!ctx || ctx.animating) return;
  ctx.nodes.rollButton.disabled = true;
  sound.dice();
  startDiceSpin();

  const r = await send(ctx.socket, 'ludo:roll');
  if (!r.ok) {
    cancelDice();
    toast(r.message ?? 'Cannot roll right now.', 'is-warn');
    sound.nope();
    updateGame();
  }
}

async function onTokenTap(event) {
  const node = event.target.closest('.ludo-token');
  if (!node || !node.classList.contains('is-movable')) return;

  const r = await send(ctx.socket, 'ludo:move', { tokenIndex: Number(node.dataset.index) });
  if (!r.ok) {
    toast(r.message ?? 'Cannot move that token.', 'is-warn');
    sound.nope();
  }
}

/* ── the die ─────────────────────────────────────────────────────────────── */

/* Same contract as Snake & Ladder: the die spins, lands on the server's real
   number, and is held long enough to read — and no token moves before that. */

const DICE = { MIN_SPIN_MS: 600, SETTLE_MS: 500, SPIN_TICK_MS: 70 };
let diceSpin = null;
let diceSpinStartedAt = 0;

function startDiceSpin() {
  cancelDice();
  const face = ctx.nodes.dieFace;
  face.classList.add('is-rolling');
  face.classList.remove('is-settled');
  diceSpinStartedAt = Date.now();
  diceSpin = setInterval(() => {
    if (Date.now() - diceSpinStartedAt >= DICE.MIN_SPIN_MS) {
      clearInterval(diceSpin);
      diceSpin = null;
      face.classList.remove('is-rolling');
      face.classList.add('is-waiting');
      setDieFace(null);
      return;
    }
    setDieFace(1 + Math.floor(Math.random() * 6));
  }, DICE.SPIN_TICK_MS);
}

function cancelDice() {
  if (diceSpin) clearInterval(diceSpin);
  diceSpin = null;
  ctx.nodes?.dieFace?.classList.remove('is-rolling', 'is-waiting', 'is-settled');
}

/** Resolves only once the die has visibly stopped on `value`. */
async function revealDie(value, wasMine) {
  const face = ctx.nodes?.dieFace;
  if (!face) return;

  // Players who didn't press the button have no spin running yet.
  if (!wasMine && !diceSpin && !face.classList.contains('is-waiting')) startDiceSpin();

  const spun = Date.now() - diceSpinStartedAt;
  if (diceSpin && spun < DICE.MIN_SPIN_MS) await wait(DICE.MIN_SPIN_MS - spun);

  if (diceSpin) clearInterval(diceSpin);
  diceSpin = null;

  face.classList.remove('is-rolling', 'is-waiting');
  setDieFace(value);
  face.classList.remove('is-settled');
  void face.offsetWidth;
  face.classList.add('is-settled');
  await wait(DICE.SETTLE_MS);
}

const PIPS = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8] };

function setDieFace(value) {
  const face = ctx.nodes.dieFace;
  if (value === null) {
    render(face, el('span', { class: 'die-waiting', text: '?' }));
    delete face.dataset.value;
    return;
  }
  const on = new Set(PIPS[value] ?? []);
  render(face, Array.from({ length: 9 }, (_, i) =>
    el('span', { class: `pip${on.has(i) ? ' is-on' : ''}` })));
  face.dataset.value = String(value);
}

/* ── animating a move ────────────────────────────────────────────────────── */

/**
 * Walk the token square by square, then send any captured tokens home.
 * Waits for the die first — the reveal is already in flight from `ludo:rolled`.
 */
async function animateMove(move) {
  if (!ctx) return;
  ctx.animating = true;

  const node = ctx.tokenNodes.get(`${move.seatId}:${move.tokenIndex}`);
  const seat = ctx.seats[move.seatId];
  if (!node || !seat) {
    ctx.animating = false;
    return;
  }

  // Let the die finish landing before anything moves.
  while (diceSpin) await wait(40);
  await wait(120);

  const steps = [];
  for (let position = move.from + 1; position <= move.to; position++) steps.push(position);
  // Leaving the yard is a single hop onto the start square, not a walk.
  if (move.from < 0) steps.length = 0, steps.push(move.to);

  const budget = ctx.config.timing.moveMs ?? 2200;
  const stepMs = Math.max(60, Math.min(150, budget / Math.max(1, steps.length)));

  node.classList.add('is-moving');
  for (const position of steps) {
    placeToken(node, seat, position, move.tokenIndex);
    if (move.playerId === ctx.memberId) sound.hop();
    await wait(stepMs);
  }
  node.classList.remove('is-moving');

  if (move.reachedHome) {
    sound.ladder();
    node.classList.add('is-home');
  }

  // Captured tokens fly back to their yard.
  for (const capture of move.captures ?? []) {
    const victim = ctx.tokenNodes.get(`${capture.seatId}:${capture.tokenIndex}`);
    if (!victim) continue;
    victim.classList.add('is-captured');
    sound.snake();
    await wait(160);
    placeToken(victim, ctx.seats[capture.seatId], -1, capture.tokenIndex);
    setTimeout(() => victim.classList.remove('is-captured'), 500);
  }

  if ((move.captures ?? []).length) {
    const who = ctx.state?.players.find((p) => p.id === move.playerId);
    ctx.chat?.addSystem(`${who ? who.name : 'Someone'} sent a token home! 😱`);
  }

  ctx.animating = false;
  layoutTokens();
  updateGame();
}

/* ── timers, victory, odds & ends ────────────────────────────────────────── */

function startTimerLoop() {
  cancelAnimationFrame(ctx.timerHandle);
  const tick = () => {
    if (!ctx?.state) return;
    const fill = ctx.nodes.timerBar?.querySelector('.timer-fill');
    const total = (ctx.state.rules?.turnSeconds ?? 0) * 1000;
    if (fill && ctx.state.turnDeadline && total) {
      const left = Math.max(0, ctx.state.turnDeadline - Date.now());
      fill.style.width = `${(left / total) * 100}%`;
      fill.classList.toggle('is-urgent', left < 5000);
      ctx.nodes.timerBar.hidden = false;
    } else if (ctx.nodes.timerBar) {
      ctx.nodes.timerBar.hidden = true;
    }
    ctx.timerHandle = requestAnimationFrame(tick);
  };
  ctx.timerHandle = requestAnimationFrame(tick);
}

function showVictory(standings) {
  const winner = standings[0];
  ctx.victoryOverlay = gameOverModal({
    emoji: '🏆',
    title: winner?.id === ctx.memberId ? 'You win!' : `${winner?.name ?? 'Someone'} wins!`,
    content: [
      el('ol', { class: 'standings' },
        standings.map((entry) =>
          el('li', { class: 'standings-row' },
            el('span', { class: 'leader-place', text: `#${entry.place}` }),
            el('div', {
              class: 'token-face is-small',
              style: { '--token-color': entry.color },
              text: entry.initials,
            }),
            el('span', { class: 'leader-name', text: entry.name }),
            el('span', { class: 'leader-pos', text: `${entry.home}/4 home` })))),
    ],
    primary: {
      label: 'Play again',
      onClick: async () => {
        const r = await send(ctx.socket, 'ludo:rematch');
        if (!r.ok) toast(r.message, 'is-warn');
        return !r.ok;
      },
    },
    onBack: () => { clearLeaveGuard(); confetti.stop(); },
  }).node;
}

function backButton() {
  return el('button', {
    class: 'btn btn-ghost btn-sm', text: '← Games',
    onClick: async () => {
      const left = await go('/');
      if (left) {
        await send(ctx.socket, 'ludo:leave');
        clearSession();
        teardown();
      }
    },
  });
}

async function reactWithCooldown(emoji) {
  const r = await send(ctx.socket, 'ludo:react', { emoji });
  if (r.ok) ctx.chat?.coolDown(2000);
}

function updateConnection(online) {
  const chip = ctx?.nodes?.connChip;
  if (!chip) return;
  chip.classList.toggle('is-offline', !online);
  chip.querySelector('.conn-text').textContent = online ? 'connected' : 'reconnecting…';
}

function teardown() {
  if (!ctx) return;
  cancelAnimationFrame(ctx.timerHandle);
  cancelDice();
  ctx.victoryOverlay?.remove();
  ctx = null;
}
