/**
 * Fifteen-player load test.
 *
 * The spec asks specifically that a full room stays smooth: state broadcasts
 * must not blow up, and one Race round must complete in under 15 seconds.
 * This plays a whole 15-player game and reports the numbers.
 *
 *   npm run test:load
 */

import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { io as connect } from 'socket.io-client';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 4803;
const URL = `http://localhost:${PORT}`;
const NS = `${URL}/snake-and-ladder`;
const PLAYERS = 15;

let passed = 0;
let failed = 0;
const check = (label, ok, detail = '') => {
  if (ok) { passed++; console.log(`  ✓ ${label}`); }
  else { failed++; console.log(`  ✗ ${label}${detail ? ` — ${detail}` : ''}`); }
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitFor(predicate, { timeout = 20000, label = 'condition' } = {}) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (predicate()) return true;
    await sleep(20);
  }
  throw new Error(`Timed out waiting for ${label}`);
}

function makeClient(index) {
  const socket = connect(NS, { transports: ['websocket'], forceNew: true });
  const client = {
    index,
    socket,
    state: null,
    memberId: null,
    results: [],
    /** Every inbound message is counted, to see how chatty the server is. */
    counts: { state: 0, results: 0, rolled: 0, other: 0 },
    bytes: 0,
  };

  const track = (kind, payload) => {
    client.counts[kind] = (client.counts[kind] ?? 0) + 1;
    client.bytes += JSON.stringify(payload ?? {}).length;
  };

  socket.on('snl:welcome', (p) => {
    client.memberId = p.memberId;
    client.state = p.state;
    track('other', p);
  });
  socket.on('snl:state', (s) => {
    client.state = s;
    track('state', s);
  });
  socket.on('snl:results', (p) => {
    client.results.push(p);
    track('results', p);
  });
  socket.on('snl:rolled', (p) => track('rolled', p));
  socket.on('snl:gameOver', (p) => {
    client.over = p;
    track('other', p);
  });

  client.send = (event, payload = {}) =>
    new Promise((resolve) => socket.emit(event, payload, resolve));
  client.ready = new Promise((resolve) => socket.on('connect', resolve));
  return client;
}

async function main() {
  console.log(`\nStarting server…`);
  const server = spawn('node', [path.join(__dirname, '..', 'server', 'index.js')], {
    env: { ...process.env, PORT: String(PORT) },
    stdio: ['ignore', 'pipe', 'inherit'],
  });
  await new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('server start timeout')), 10000);
    server.stdout.on('data', (c) => {
      if (c.toString().includes('localhost')) { clearTimeout(t); resolve(); }
    });
  });

  const clients = Array.from({ length: PLAYERS }, (_, i) => makeClient(i));
  const host = clients[0];

  try {
    console.log(`\nSeating ${PLAYERS} players`);
    const connectStart = Date.now();
    await Promise.all(clients.map((c) => c.ready));
    check(`${PLAYERS} sockets connected`, true, `${Date.now() - connectStart}ms`);

    const room = await host.send('snl:create', {
      name: 'Player 1',
      maxPlayers: PLAYERS,
      mode: 'race',
    });
    await Promise.all(
      clients.slice(1).map((c, i) => c.send('snl:join', { code: room.code, name: `Player ${i + 2}` })),
    );
    await waitFor(() => host.state?.players.length === PLAYERS, { label: `${PLAYERS} players` });
    check(`room seats all ${PLAYERS} players`, host.state.players.length === PLAYERS);
    check('every player has a distinct colour',
      new Set(host.state.players.map((p) => p.color)).size === PLAYERS);
    check('every player has initials on their token',
      host.state.players.every((p) => p.initials && p.initials.length >= 1));

    // Everyone should be seeing the same room.
    await waitFor(() => clients.every((c) => c.state?.players.length === PLAYERS),
      { label: 'all clients in sync' });
    check('all 15 clients agree on the roster', true);

    // Baseline the message counts from here, so lobby chatter doesn't skew
    // the per-round numbers.
    const baseline = clients.map((c) => ({ ...c.counts }));

    console.log('\nPlaying a full 15-player race');
    await host.send('snl:configure', { finishMode: 'podium' });
    await host.send('snl:start');
    await waitFor(() => host.state.phase === 'rolling', { timeout: 8000, label: 'first round' });

    const roundTimes = [];
    let rounds = 0;

    while (host.state.state === 'playing' && rounds < 60) {
      const round = host.state.round;
      const started = Date.now();
      const before = host.results.length;

      // All fifteen tap ROLL at once — the worst case for the server.
      await Promise.all(
        clients.map((c) => c.send('snl:roll').catch(() => {})),
      );

      await waitFor(() => host.results.length > before, { timeout: 16000, label: `round ${round} results` });
      roundTimes.push(Date.now() - started);
      rounds++;

      if (host.state.state !== 'playing') break;
      // Wait for the next window (or the game to end while animating).
      await waitFor(
        () => host.state.round > round || host.state.state === 'ended',
        { timeout: 16000, label: `round ${round + 1} opening` },
      ).catch(() => {});
    }

    await waitFor(() => host.state.state === 'ended', { timeout: 20000, label: 'game over' });

    const slowest = Math.max(...roundTimes);
    const median = [...roundTimes].sort((a, b) => a - b)[Math.floor(roundTimes.length / 2)];

    console.log(`\n  rounds played: ${rounds}`);
    console.log(`  round time — median ${median}ms, slowest ${slowest}ms`);

    check('every round resolved in under 15s', slowest < 15000, `slowest ${slowest}ms`);
    check('rounds resolve promptly when everyone rolls', median < 5000, `median ${median}ms`);
    check('the game reached a finish', host.state.state === 'ended');
    check(`standings list all ${PLAYERS} players`, host.state.standings?.length === PLAYERS,
      String(host.state.standings?.length));
    check('places run 1..15 with no gaps',
      host.state.standings.map((s) => s.place).join() ===
        Array.from({ length: PLAYERS }, (_, i) => i + 1).join());
    check('a podium was reached', host.state.standings.filter((s) => s.finished).length >= 1);

    // ── broadcast efficiency ───────────────────────────────────────────────
    console.log('\nBroadcast efficiency');

    const perClient = clients.map((c, i) => ({
      state: c.counts.state - baseline[i].state,
      results: c.counts.results - baseline[i].results,
      rolled: c.counts.rolled - baseline[i].rolled,
    }));

    const statePerRound = perClient[0].state / rounds;
    const resultsPerRound = perClient[0].results / rounds;
    const rolledPerRound = perClient[0].rolled / rounds;

    console.log(`  per client, per round: ${statePerRound.toFixed(1)} state, ` +
      `${resultsPerRound.toFixed(1)} results, ${rolledPerRound.toFixed(1)} roll pings`);

    check('exactly one results broadcast per round', Math.abs(resultsPerRound - 1) < 0.15,
      resultsPerRound.toFixed(2));
    check('state broadcasts stay in single digits per round', statePerRound < 10,
      statePerRound.toFixed(2));
    check('roll pings scale with players, not players squared',
      rolledPerRound <= PLAYERS + 1, rolledPerRound.toFixed(2));

    // The real question: does the payload volume stay sane at 15 players?
    // Per round per player is the metric that actually has to stay flat — a
    // longer game should cost more in total, but not more per round.
    const totalBytes = clients.reduce((sum, c) => sum + c.bytes, 0);
    const perPlayerKb = totalBytes / PLAYERS / 1024;
    const perRoundKb = perPlayerKb / rounds;
    console.log(`  total traffic ${(totalBytes / 1024).toFixed(0)}KB across ${PLAYERS} clients ` +
      `(${perPlayerKb.toFixed(1)}KB each over ${rounds} rounds = ${perRoundKb.toFixed(1)}KB/round)`);
    check('per-round traffic per player stays small', perRoundKb < 25, `${perRoundKb.toFixed(1)}KB`);

    // All clients should have received the same number of results.
    const spread = new Set(perClient.map((p) => p.results)).size;
    check('every client received the same results stream', spread === 1, `${spread} distinct counts`);
  } catch (error) {
    failed++;
    console.log(`\n  ✗ Unexpected error: ${error.message}`);
    console.error(error);
  } finally {
    for (const c of clients) c.socket.disconnect();
    server.kill('SIGKILL');
  }

  console.log(`\n${failed === 0 ? '✅' : '❌'}  ${passed} passed, ${failed} failed\n`);
  process.exit(failed === 0 ? 0 : 1);
}

main();
