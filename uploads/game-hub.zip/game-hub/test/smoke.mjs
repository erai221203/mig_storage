/**
 * End-to-end smoke test for the hub and Snake & Ladder.
 *
 * Part 1 exercises the pure rules directly with fixed dice, so movement,
 * snakes, ladders and the exact-finish rule are checked deterministically
 * rather than by hoping the right numbers come up.
 *
 * Part 2 boots the real server and drives it with real Socket.IO clients
 * through all three modes.
 *
 *   npm test
 */

import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { io as connect } from 'socket.io-client';

import { resolveMove, squareToCoords, coordsToSquare } from '../server/games/snake-and-ladder/game.js';
import { stepPath } from '../client/games/snake-and-ladder/board.js';
import { LADDERS, SNAKES, validateBoard } from '../server/games/snake-and-ladder/config.js';
import { initialsFor, uniqueName } from '../server/shared/players.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 4802;
const URL = `http://localhost:${PORT}`;
const NS = `${URL}/snake-and-ladder`;

let passed = 0;
let failed = 0;

function check(label, condition, detail = '') {
  if (condition) {
    passed++;
    console.log(`  ✓ ${label}`);
  } else {
    failed++;
    console.log(`  ✗ ${label}${detail ? ` — ${detail}` : ''}`);
  }
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function waitFor(predicate, { timeout = 8000, label = 'condition' } = {}) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (predicate()) return true;
    await sleep(25);
  }
  throw new Error(`Timed out waiting for ${label}`);
}

/** A test client that tracks the latest state it received. */
function makeClient() {
  const socket = connect(NS, { transports: ['websocket'], forceNew: true });
  const client = { socket, state: null, memberId: null, results: [], chat: [], over: null, rolled: [] };

  socket.on('snl:welcome', (payload) => {
    client.memberId = payload.memberId;
    client.state = payload.state;
  });
  socket.on('snl:state', (state) => {
    client.state = state;
  });
  socket.on('snl:results', (payload) => client.results.push(payload));
  socket.on('snl:rolled', (payload) => client.rolled.push(payload));
  socket.on('snl:chat', (message) => client.chat.push(message));
  socket.on('snl:gameOver', (payload) => {
    client.over = payload;
  });

  client.send = (event, payload = {}) =>
    new Promise((resolve) => socket.emit(event, payload, resolve));
  client.ready = new Promise((resolve) => socket.on('connect', resolve));
  return client;
}

/* ── Part 1: pure rules ─────────────────────────────────────────────────── */

function testRules() {
  console.log('\nBoard geometry');
  check('square 1 is bottom-left', JSON.stringify(squareToCoords(1)) === JSON.stringify({ row: 0, col: 0 }));
  check('square 10 ends the bottom row on the right',
    JSON.stringify(squareToCoords(10)) === JSON.stringify({ row: 0, col: 9 }));
  check('square 11 sits directly above square 10 (zig-zag)',
    JSON.stringify(squareToCoords(11)) === JSON.stringify({ row: 1, col: 9 }));
  check('square 20 ends the second row on the left',
    JSON.stringify(squareToCoords(20)) === JSON.stringify({ row: 1, col: 0 }));
  check('square 100 is top-left', JSON.stringify(squareToCoords(100)) === JSON.stringify({ row: 9, col: 0 }));
  check('coords round-trip back to the same square',
    Array.from({ length: 100 }, (_, i) => i + 1).every((n) => {
      const { row, col } = squareToCoords(n);
      return coordsToSquare(row, col) === n;
    }));

  console.log('\nMovement rules');
  const plain = { exactFinish: true, needSixToStart: false };

  check('a normal roll just advances', resolveMove(30, 3, plain).to === 33);

  const ladder = resolveMove(0, 1, plain); // square 1 is a ladder foot → 38
  check('landing on a ladder foot climbs it', ladder.to === LADDERS[1] && ladder.via === 'ladder',
    `${ladder.landed}→${ladder.to}`);
  check('the ladder reports where it was entered', ladder.landed === 1);

  const snake = resolveMove(12, 4, plain); // 16 is a snake head → 6
  check('landing on a snake head slides down', snake.to === SNAKES[16] && snake.via === 'snake',
    `${snake.landed}→${snake.to}`);

  const overshoot = resolveMove(97, 5, plain);
  check('exact finish blocks an overshoot', overshoot.blocked && overshoot.to === 97);
  check('a blocked move is not a win', overshoot.finished === false);

  const exact = resolveMove(97, 3, plain);
  check('landing exactly on 100 wins', exact.finished && exact.to === 100);

  const loose = resolveMove(97, 5, { exactFinish: false, needSixToStart: false });
  check('with exact finish off, an overshoot still wins', loose.finished && loose.to === 100);

  const needSix = { exactFinish: true, needSixToStart: true };
  check('need-a-six keeps you at the start without one', resolveMove(0, 3, needSix).stuck === true);
  check('need-a-six lets you in on a six', resolveMove(0, 6, needSix).to === 6);

  const ladderToWin = resolveMove(76, 4, plain); // 80 → 100
  check('a ladder onto the last square wins', ladderToWin.finished && ladderToWin.to === 100);

  check('the shipped board passes validation', validateBoard() === true);

  // The token must walk exactly as many squares as the die shows, from every
  // square and for every possible roll — before any snake or ladder applies.
  let stepMismatch = null;
  for (let from = 0; from <= 99 && !stepMismatch; from++) {
    for (let die = 1; die <= 6; die++) {
      const move = resolveMove(from, die, plain);
      if (move.blocked || move.stuck) continue;
      if (move.landed - move.from !== die) {
        stepMismatch = `from ${from} rolling ${die} landed on ${move.landed}`;
        break;
      }
    }
  }
  check('a token lands exactly `die` squares along, from every square',
    stepMismatch === null, stepMismatch ?? '');

  // …and the animation walks that same number of hops.
  let hopMismatch = null;
  for (let from = 0; from <= 99 && !hopMismatch; from++) {
    for (let die = 1; die <= 6; die++) {
      const move = resolveMove(from, die, plain);
      if (move.blocked || move.stuck) continue;
      const hops = stepPath(move);
      if (hops.length !== die) {
        hopMismatch = `from ${from} rolling ${die} animated ${hops.length} hops`;
        break;
      }
      if (hops.at(-1) !== move.landed) {
        hopMismatch = `from ${from} rolling ${die} ended the walk on ${hops.at(-1)}`;
        break;
      }
    }
  }
  check('the animation hops exactly once per pip, ending where it landed',
    hopMismatch === null, hopMismatch ?? '');

  // A blocked or stuck move must not animate at all.
  check('an overshoot animates no hops',
    stepPath(resolveMove(97, 5, plain)).length === 0);
  check('a stuck token animates no hops',
    stepPath(resolveMove(0, 3, { exactFinish: true, needSixToStart: true })).length === 0);

  console.log('\nPlayer helpers');
  check('initials use two words', initialsFor('Priya Rao') === 'PR');
  check('initials fall back to one word', initialsFor('Sam') === 'SA');
  check('duplicate names get a number', uniqueName('Sam', ['Sam']) === 'Sam 2');
  check('duplicate names keep counting', uniqueName('Sam', ['Sam', 'Sam 2']) === 'Sam 3');
  check('unique names are left alone', uniqueName('Ana', ['Sam']) === 'Ana');
}

/* ── Part 2: over the wire ──────────────────────────────────────────────── */

async function main() {
  testRules();

  console.log('\nStarting server for integration tests…');
  const server = spawn('node', [path.join(__dirname, '..', 'server', 'index.js')], {
    env: { ...process.env, PORT: String(PORT) },
    stdio: ['ignore', 'pipe', 'inherit'],
  });
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Server did not start in time')), 10000);
    server.stdout.on('data', (chunk) => {
      if (chunk.toString().includes('localhost')) {
        clearTimeout(timer);
        resolve();
      }
    });
  });

  const clients = [];
  const spawnClient = () => {
    const client = makeClient();
    clients.push(client);
    return client;
  };

  try {
    // ── hub API ────────────────────────────────────────────────────────────
    console.log('\nHub API');
    const games = await (await fetch(`${URL}/api/games`)).json();
    check('the catalogue lists games', Array.isArray(games.games) && games.games.length >= 5);
    check('Snake & Ladder is live',
      games.games.find((g) => g.id === 'snake-and-ladder')?.status === 'live');

    // The catalogue drives the landing page, so the invariant that matters is
    // that it agrees with what the server can actually serve — not a fixed count.
    const live = games.games.filter((g) => g.status === 'live');
    const soon = games.games.filter((g) => g.status === 'coming-soon');
    check('every game has a known status',
      live.length + soon.length === games.games.length,
      `${live.length} live, ${soon.length} soon, ${games.games.length} total`);
    check('all five games are playable', live.length === 5, `${live.length} live`);
    check('every live game declares an event prefix',
      live.every((g) => typeof g.eventPrefix === 'string' && g.eventPrefix.length > 0));

    const liveConfigs = await Promise.all(
      live.map((g) => fetch(`${URL}/api/games/${g.id}/config`).then((r) => r.status)),
    );
    check('every live game serves a config', liveConfigs.every((s) => s === 200),
      liveConfigs.join(','));

    const soonConfigs = await Promise.all(
      soon.map((g) => fetch(`${URL}/api/games/${g.id}/config`).then((r) => r.status)),
    );
    check('placeholders serve no config', soonConfigs.every((s) => s === 404),
      soonConfigs.join(','));
    check('15 distinct token colours are published',
      new Set(games.tokenColors).size === 15, String(games.tokenColors?.length));

    const snlConfig = await (await fetch(`${URL}/api/games/snake-and-ladder/config`)).json();
    check('the game publishes its board', Object.keys(snlConfig.config.snakes).length === 10);
    check('the game publishes its ladders', Object.keys(snlConfig.config.ladders).length === 9);
    check('an unknown game 404s', (await fetch(`${URL}/api/games/nope/config`)).status === 404);

    // ── rooms & joining ────────────────────────────────────────────────────
    console.log('\nRooms & joining');
    const host = spawnClient();
    const guest = spawnClient();
    await Promise.all([host.ready, guest.ready]);

    const created = await host.send('snl:create', { name: 'Ana', maxPlayers: 3, mode: 'classic' });
    check('a room can be created', created.ok && created.code.length === 5, created.code);
    const code = created.code;

    const lookup = await (await fetch(`${URL}/api/rooms/${code}`)).json();
    check('a room code routes to its game', lookup.gameId === 'snake-and-ladder');
    check('an unknown code 404s', (await fetch(`${URL}/api/rooms/ZZZZZ`)).status === 404);

    const badJoin = await guest.send('snl:join', { code: 'ZZZZZ', name: 'Ben' });
    check('joining an unknown code fails kindly', !badJoin.ok && badJoin.code === 'NO_ROOM');

    await guest.send('snl:join', { code: code.toLowerCase(), name: 'Ben' });
    check('room codes are case-insensitive', true);

    const dupe = spawnClient();
    await dupe.ready;
    const dupeJoin = await dupe.send('snl:join', { code, name: 'Ana' });
    check('a duplicate name is auto-numbered', dupeJoin.ok && dupeJoin.name === 'Ana 2', dupeJoin.name);

    const overflow = spawnClient();
    await overflow.ready;
    const spectator = await overflow.send('snl:join', { code, name: 'Late' });
    check('a full room offers a spectator seat', spectator.ok && spectator.spectator === true);
    await waitFor(() => host.state?.spectators.length === 1, { label: 'spectator listed' });

    const spectatorRoll = await overflow.send('snl:roll');
    check('spectators cannot roll', !spectatorRoll.ok);

    await waitFor(() => host.state?.players.length === 3, { label: 'three players' });
    check('every player has a distinct token colour',
      new Set(host.state.players.map((p) => p.color)).size === 3);
    check('every player has initials', host.state.players.every((p) => p.initials.length >= 1));
    check('the creator is host', host.state.players.find((p) => p.isHost)?.name === 'Ana');

    const notHost = await guest.send('snl:start');
    check('only the host can start', !notHost.ok);

    // ── classic mode ───────────────────────────────────────────────────────
    console.log('\nClassic mode');
    await host.send('snl:configure', { turnSeconds: 10, finishMode: 'first' });
    await waitFor(() => host.state.rules.turnSeconds === 10, { label: 'settings' });
    check('the host can set the turn timer', host.state.rules.turnSeconds === 10);

    const badTimer = await host.send('snl:configure', { turnSeconds: 7 });
    check('an unsupported turn timer is rejected', !badTimer.ok);

    await host.send('snl:start');
    await waitFor(() => host.state.phase === 'turn', { timeout: 6000, label: 'first turn' });
    check('the game starts on a turn', host.state.phase === 'turn');
    check('every player got a token', host.state.tokens.length === 3);
    check('tokens start off the board', host.state.tokens.every((t) => t.position === 0));
    check('a turn deadline is published', host.state.turnDeadline > Date.now());

    const turnHolder = clients.find((c) => c.memberId === host.state.turnTokenId);
    const waiter = clients.find(
      (c) => c.memberId && c.memberId !== host.state.turnTokenId && c.state?.tokens?.length,
    );
    const outOfTurn = await waiter.send('snl:roll');
    check('a player cannot roll out of turn', !outOfTurn.ok);

    const rollResult = await turnHolder.send('snl:roll');
    check('the player on turn can roll', rollResult.ok);
    await waitFor(() => host.results.length > 0, { label: 'a result' });

    const move = host.results[0].results[0];
    check('the server generates the die', move.die >= 1 && move.die <= 6, String(move.die));
    check('the result describes the whole move',
      typeof move.from === 'number' && typeof move.to === 'number' && 'via' in move);

    // Nothing the client sends can influence the die.
    const cheat = await turnHolder.send('snl:roll', { die: 6, to: 99 });
    check('clients cannot supply their own die or destination',
      host.state.tokens.every((t) => t.position !== 99));

    await waitFor(() => host.state.phase === 'turn', { timeout: 6000, label: 'next turn' });
    check('play moves on to another turn', host.state.phase === 'turn');

    console.log('  … waiting out a turn timer to check auto-roll (10s)');
    const beforeAuto = host.results.length;
    await waitFor(() => host.results.length > beforeAuto, { timeout: 14000, label: 'auto-roll' });
    check('an expired turn auto-rolls', host.results.at(-1).results[0].auto === true);

    const ended = await host.send('snl:endGame');
    check('the host can end the game early', ended.ok);
    await waitFor(() => host.state.state === 'ended', { label: 'game over' });
    check('standings rank everyone', host.state.standings.length === 3);
    check('places are 1..n with no gaps',
      host.state.standings.map((s) => s.place).join() === '1,2,3');

    const rematch = await host.send('snl:rematch');
    check('the host can call a rematch', rematch.ok);
    await waitFor(() => host.state.state === 'lobby', { label: 'back to lobby' });
    check('a rematch returns everyone to the lobby', host.state.phase === 'lobby');

    for (const client of [host, guest, dupe, overflow]) client.socket.disconnect();

    // ── race mode ──────────────────────────────────────────────────────────
    console.log('\nRace mode');
    const racers = Array.from({ length: 5 }, () => spawnClient());
    await Promise.all(racers.map((r) => r.ready));

    const raceRoom = await racers[0].send('snl:create', { name: 'R1', maxPlayers: 5, mode: 'race' });
    for (let i = 1; i < racers.length; i++) {
      await racers[i].send('snl:join', { code: raceRoom.code, name: `R${i + 1}` });
    }
    await waitFor(() => racers[0].state.players.length === 5, { label: 'five racers' });

    await racers[0].send('snl:start');
    await waitFor(() => racers[0].state.phase === 'rolling', { timeout: 6000, label: 'roll window' });
    check('race mode opens a roll window', racers[0].state.phase === 'rolling');
    check('a round deadline is published', racers[0].state.roundDeadline > Date.now());
    check('the round counter starts at 1', racers[0].state.round === 1);

    // Everyone rolls at once — the window should close early rather than
    // burning the full ten seconds.
    const roundStart = Date.now();
    await Promise.all(racers.map((r) => r.send('snl:roll')));
    await waitFor(() => racers[0].results.length > 0, { timeout: 4000, label: 'round results' });
    const elapsed = Date.now() - roundStart;
    check('the window closes as soon as everyone has rolled', elapsed < 2000, `${elapsed}ms`);

    const raceResults = racers[0].results[0].results;
    check('every token moves in one batch', raceResults.length === 5, String(raceResults.length));
    check('results arrive as ONE broadcast, not one per player', racers[0].results.length === 1);
    check('nobody was auto-rolled', raceResults.every((r) => r.auto === false));

    const double = await racers[0].send('snl:roll');
    check('a player cannot roll twice in a round', !double.ok);

    await waitFor(() => racers[0].state.phase === 'rolling' && racers[0].state.round === 2,
      { timeout: 8000, label: 'round 2' });
    check('the next round opens automatically', racers[0].state.round === 2);

    // One player sits out; the server should roll for them at the deadline.
    console.log('  … letting one round time out to check auto-roll (10s)');
    const before2 = racers[0].results.length;
    await Promise.all(racers.slice(1).map((r) => r.send('snl:roll')));
    await waitFor(() => racers[0].results.length > before2, { timeout: 14000, label: 'auto-rolled round' });
    const autoRound = racers[0].results.at(-1).results;
    check('the silent player is auto-rolled', autoRound.some((r) => r.auto === true));
    check('everyone else keeps their own roll', autoRound.filter((r) => r.auto === false).length === 4);

    for (const r of racers) r.socket.disconnect();

    // ── team mode ──────────────────────────────────────────────────────────
    console.log('\nTeam mode');
    const team = Array.from({ length: 4 }, () => spawnClient());
    await Promise.all(team.map((t) => t.ready));

    const teamRoom = await team[0].send('snl:create', { name: 'T1', maxPlayers: 4, mode: 'team' });
    for (let i = 1; i < team.length; i++) {
      await team[i].send('snl:join', { code: teamRoom.code, name: `T${i + 1}` });
    }
    await waitFor(() => team[0].state.players.length === 4, { label: 'four players' });
    check('players are auto-balanced into teams',
      team[0].state.teams.length === 2 && team[0].state.teams.every((t) => t.memberIds.length === 2));

    const switched = await team[3].send('snl:switchTeam', { teamId: team[0].state.teams[0].id });
    check('a player can switch teams in the lobby', switched.ok);
    await waitFor(() => team[0].state.teams[0].memberIds.length === 3, { label: 'team switch' });
    await team[3].send('snl:switchTeam', { teamId: team[0].state.teams[1].id });

    await team[0].send('snl:start');
    await waitFor(() => team[0].state.phase === 'rolling', { timeout: 6000, label: 'team round' });
    check('teams share one token each', team[0].state.tokens.length === 2);
    check('each token is a team', team[0].state.tokens.every((t) => t.kind === 'team'));

    const rollers = team[0].state.teams.map((t) => t.rollerId);
    check('one member per team is nominated to roll', rollers.every(Boolean) && new Set(rollers).size === 2);

    const nonRoller = team.find((c) => c.memberId && !rollers.includes(c.memberId));
    const blocked = await nonRoller.send('snl:roll');
    check('a teammate who is not the roller cannot roll', !blocked.ok);
    check('the refusal names who is rolling', /rolling for your team/i.test(blocked.message ?? ''),
      blocked.message);

    const rollerClients = team.filter((c) => rollers.includes(c.memberId));
    await Promise.all(rollerClients.map((c) => c.send('snl:roll')));
    await waitFor(() => team[0].results.length > 0, { timeout: 4000, label: 'team round results' });
    check('both team tokens move', team[0].results[0].results.length === 2);

    await waitFor(() => team[0].state.round === 2 && team[0].state.phase === 'rolling',
      { timeout: 8000, label: 'team round 2' });
    const nextRollers = team[0].state.teams.map((t) => t.rollerId);
    check('the roller rotates to the next teammate',
      nextRollers.every((id, i) => id !== rollers[i]), `${rollers} → ${nextRollers}`);

    // ── chat, reactions, disconnects ───────────────────────────────────────
    console.log('\nChat, reactions & disconnects');
    await team[1].send('snl:chat', { text: 'go team!' });
    await waitFor(() => team[0].chat.length > 0, { label: 'chat' });
    check('chat reaches the room', team[0].chat[0].text === 'go team!');

    const badReaction = await team[1].send('snl:react', { emoji: '<script>' });
    check('unknown reactions are rejected', !badReaction.ok);
    const react1 = await team[1].send('snl:react', { emoji: '🎉' });
    const react2 = await team[1].send('snl:react', { emoji: '🎉' });
    check('a reaction is accepted', react1.ok);
    check('reactions are rate limited to 1 per 2s', !react2.ok && react2.code === 'RATE_LIMIT');

    const hostId = team[0].memberId;
    team[0].socket.disconnect();
    await waitFor(() => team[1].state.players.find((p) => p.id === hostId)?.connected === false,
      { label: 'host dropping' });
    check('a dropped player is shown as disconnected', true);
    check('host role transfers on disconnect',
      team[1].state.players.find((p) => p.isHost)?.id !== hostId);

    const returning = spawnClient();
    await returning.ready;
    const resumed = await returning.send('snl:rejoin', { code: teamRoom.code, memberId: hostId });
    check('a dropped player can reclaim their seat', resumed.ok && resumed.resumed === true);
    await waitFor(() => returning.state?.players.some((p) => p.id === hostId && p.connected),
      { label: 'seat restored' });
    check('the room is whole again', returning.state.players.filter((p) => p.connected).length === 4);

    for (const c of team) c.socket.disconnect();
    returning.socket.disconnect();
  } catch (error) {
    failed++;
    console.log(`\n  ✗ Unexpected error: ${error.message}`);
    console.error(error);
  } finally {
    for (const client of clients) client.socket.disconnect();
    server.kill('SIGKILL');
  }

  console.log(`\n${failed === 0 ? '✅' : '❌'}  ${passed} passed, ${failed} failed\n`);
  process.exit(failed === 0 ? 0 : 1);
}

main();
