/**
 * Perft: the standard correctness proof for a chess move generator.
 *
 * Counting the leaf nodes at each depth from a known position gives numbers
 * that are published and agreed on. If this file's counts match, the generator
 * handles castling, en passant, promotion, pins and check evasion exactly
 * right — not approximately right. A single wrong rule shows up as a wrong
 * total almost immediately.
 *
 *   node test/chess-perft.mjs
 */

import { fromFEN, initialPosition, perft, legalMoves, applyMove, toSAN, gameStatus }
  from '../server/games/chess/game.js';

let passed = 0;
let failed = 0;

const check = (label, ok, detail = '') => {
  if (ok) { passed++; console.log(`  ✓ ${label}`); }
  else { failed++; console.log(`  ✗ ${label}${detail ? ` — ${detail}` : ''}`); }
};

/** Positions and node counts from the standard perft results table. */
const SUITES = [
  {
    name: 'initial position',
    fen: undefined,
    expected: [20, 400, 8902, 197281],
  },
  {
    // "Kiwipete" — dense with castling, en passant and pins.
    name: 'Kiwipete',
    fen: 'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1',
    expected: [48, 2039, 97862],
  },
  {
    name: 'endgame with en passant',
    fen: '8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1',
    expected: [14, 191, 2812, 43238],
  },
  {
    name: 'promotion-heavy position',
    fen: 'r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1',
    expected: [6, 264, 9467],
  },
];

console.log('\nPerft — move generation against published node counts');

for (const suite of SUITES) {
  console.log(`\n  ${suite.name}`);
  const start = fromFEN(suite.fen);

  suite.expected.forEach((want, index) => {
    const depth = index + 1;
    const began = Date.now();
    const got = perft(start, depth);
    const ms = Date.now() - began;
    check(`depth ${depth}: ${want.toLocaleString()} nodes`, got === want,
      got === want ? '' : `got ${got.toLocaleString()}`);
    if (got === want && ms > 400) console.log(`      (${ms}ms)`);
  });
}

/* ── Specific rules, checked directly ──────────────────────────────────── */

console.log('\nIndividual rules');

// Castling both ways.
const castleReady = fromFEN('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1');
const whiteCastles = legalMoves(castleReady).filter((m) => m.castle);
check('white can castle both sides', whiteCastles.length === 2,
  whiteCastles.map((m) => m.castle).join());

// Castling through check is illegal.
const throughCheck = fromFEN('r3k2r/8/8/8/8/5q2/8/R3K2R w KQkq - 0 1');
check('cannot castle through an attacked square',
  !legalMoves(throughCheck).some((m) => m.castle === 'K'));

// Castling out of check is illegal.
const outOfCheck = fromFEN('r3k2r/8/8/8/8/4q3/8/R3K2R w KQkq - 0 1');
check('cannot castle out of check', !legalMoves(outOfCheck).some((m) => m.castle));

// En passant is available for exactly one move.
const epReady = fromFEN('8/8/8/3pP3/8/8/8/4K2k w - d6 0 1');
const epMove = legalMoves(epReady).find((m) => m.enPassant);
check('en passant capture is generated', Boolean(epMove));
if (epMove) {
  const after = applyMove(epReady, epMove);
  check('en passant removes the passed pawn', after.board.filter(Boolean).length === 3);
  check('the en passant square clears after the move', after.enPassant === null);
}

// Promotion offers all four pieces.
const promoting = fromFEN('8/P7/8/8/8/8/8/4K2k w - - 0 1');
const promotions = legalMoves(promoting).filter((m) => m.promotion);
check('promotion offers all four pieces', promotions.length === 4,
  promotions.map((m) => m.promotion).sort().join());

// A pinned piece cannot abandon its king.
const pinned = fromFEN('4k3/8/8/8/8/8/4R3/4K2r b - - 0 1');
check('a pinned piece is not offered illegal moves',
  legalMoves(fromFEN('4k3/8/8/8/4r3/8/4B3/4K3 w - - 0 1'))
    .every((m) => m.from !== 52 || m.to === 36 || m.to === 44));

// Checkmate and stalemate.
const foolsMate = fromFEN('rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3');
const mateStatus = gameStatus(foolsMate);
check('checkmate is detected', mateStatus.over && mateStatus.reason === 'checkmate');
check('checkmate names the winner', mateStatus.result === 'b', mateStatus.result);

const stalemate = fromFEN('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1');
const staleStatus = gameStatus(stalemate);
check('stalemate is detected', staleStatus.over && staleStatus.reason === 'stalemate');
check('stalemate is a draw', staleStatus.result === 'draw');

// Draws by material and by the fifty-move rule.
check('king versus king is a draw',
  gameStatus(fromFEN('4k3/8/8/8/8/8/8/4K3 w - - 0 1')).reason === 'insufficient material');
check('king and bishop versus king is a draw',
  gameStatus(fromFEN('4k3/8/8/8/8/8/8/3BK3 w - - 0 1')).reason === 'insufficient material');
check('king and two knights is not an automatic draw',
  gameStatus(fromFEN('4k3/8/8/8/8/8/8/2NNK3 w - - 0 1')).over === false);
check('the fifty-move rule ends the game',
  gameStatus(fromFEN('4k3/8/8/8/8/8/4P3/R3K3 w - - 100 60')).reason === 'fifty-move rule');

// Threefold repetition.
const repeated = initialPosition();
const key = (await import('../server/games/chess/game.js')).positionKey(repeated);
check('threefold repetition ends the game',
  gameStatus(repeated, [key, key, key]).reason === 'threefold repetition');

// Notation.
const opening = initialPosition();
const e4 = legalMoves(opening).find((m) => toSAN(opening, m) === 'e4');
check('pawn moves get plain notation', Boolean(e4));
const knight = legalMoves(opening).find((m) => toSAN(opening, m) === 'Nf3');
check('piece moves are named', Boolean(knight));

const twoKnights = fromFEN('4k3/8/8/8/8/2N1N3/8/4K3 w - - 0 1');
const sans = legalMoves(twoKnights).map((m) => toSAN(twoKnights, m));
check('ambiguous knight moves are disambiguated',
  sans.some((s) => /^N[ce]d5$/.test(s)), sans.filter((s) => s.includes('d5')).join());

// After 1.f3 e5 2.g4, Black to move — Qh4 is mate. (The queen is still on d8.)
const mateSoon = fromFEN('rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR b KQkq g3 0 2');
const mating = legalMoves(mateSoon).find((m) => toSAN(mateSoon, m).endsWith('#'));
check('mate is marked with #', Boolean(mating), mating ? toSAN(mateSoon, mating) : 'none');
check('the mating move is Qh4#', mating && toSAN(mateSoon, mating) === 'Qh4#',
  mating ? toSAN(mateSoon, mating) : 'none');

// And a plain check gets a +.
const checking = fromFEN('4k3/8/8/8/8/8/8/R3K3 w - - 0 1');
const checkMove = legalMoves(checking).find((m) => toSAN(checking, m) === 'Ra8+');
check('a check is marked with +', Boolean(checkMove));

console.log(`\n${failed === 0 ? '✅' : '❌'}  ${passed} passed, ${failed} failed\n`);
process.exit(failed === 0 ? 0 : 1);
