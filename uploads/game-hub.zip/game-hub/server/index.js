/**
 * Gaming Hub — one Express + Socket.IO server on one port, hosting every
 * game in the hub.
 *
 *   npm install && npm start   →   http://localhost:3000
 *
 * Each game registers its own Socket.IO namespace (see the index.js inside each
 * server/games folder) so their events can never collide. The HTTP side serves
 * the single-page client plus a small API that the landing page and setup
 * screens are built from.
 */

import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import express from 'express';
import { Server } from 'socket.io';

import { GAMES, findGame } from './games/registry.js';
import { lookupCode } from './shared/codes.js';
import { NAME_MAX_LENGTH, suggestNames, TOKEN_COLORS } from './shared/players.js';
import { ROOM_DEFAULTS } from './shared/room-manager.js';

// Every playable game is imported here and registered below.
import * as snakeAndLadder from './games/snake-and-ladder/index.js';
import { clientConfig as snlClientConfig } from './games/snake-and-ladder/config.js';
import * as bingo from './games/bingo/index.js';
import { clientConfig as bingoClientConfig } from './games/bingo/config.js';
import * as ticTacToe from './games/tic-tac-toe/index.js';
import { clientConfig as tttClientConfig } from './games/tic-tac-toe/config.js';
import * as ludo from './games/ludo/index.js';
import { clientConfig as ludoClientConfig } from './games/ludo/config.js';
import * as chess from './games/chess/index.js';
import { clientConfig as chessClientConfig } from './games/chess/config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CLIENT_DIR = path.join(__dirname, '..', 'client');
const PORT = Number(process.env.PORT) || 3000;

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  pingTimeout: 20000,
  pingInterval: 25000,
  // Permissive CORS keeps tunnels (ngrok, Cloudflare) working without fuss.
  cors: { origin: '*', methods: ['GET', 'POST'] },
});

/**
 * The games that are actually playable.
 * Adding one means importing it above and adding a line here — plus its entry
 * in games/registry.js. See the README's "How to add a new game".
 */
const PLAYABLE = [snakeAndLadder, bingo, ticTacToe, ludo, chess];
const GAME_CONFIGS = {
  'snake-and-ladder': snlClientConfig,
  bingo: bingoClientConfig,
  'tic-tac-toe': tttClientConfig,
  ludo: ludoClientConfig,
  chess: chessClientConfig,
};

for (const game of PLAYABLE) {
  game.register(io);
  console.log(`  ✓ registered game: ${game.gameId}  (namespace /${game.gameId})`);
}

/** Room stores, so the code lookup below can reach any game's rooms. */
const STORES = Object.fromEntries(PLAYABLE.map((game) => [game.gameId, game.rooms]));

// ── static client ──────────────────────────────────────────────────────────

app.use(express.static(CLIENT_DIR, { extensions: ['html'] }));

// ── API ────────────────────────────────────────────────────────────────────

/** The hub catalogue — the landing page renders straight from this. */
app.get('/api/games', (_req, res) => {
  res.json({
    games: GAMES,
    limits: { nameMaxLength: NAME_MAX_LENGTH, chatMaxLength: ROOM_DEFAULTS.CHAT_MAX_LENGTH },
    tokenColors: TOKEN_COLORS,
  });
});

/** A game's own rules, so the client draws exactly what the server enforces. */
app.get('/api/games/:gameId/config', (req, res) => {
  const game = findGame(req.params.gameId);
  if (!game) return res.status(404).json({ error: 'Unknown game.' });

  const config = GAME_CONFIGS[req.params.gameId];
  if (!config) return res.status(404).json({ error: 'That game is not playable yet.' });

  res.json({ game, config: config() });
});

/**
 * Which game does this room code belong to?
 * Codes are unique hub-wide, so typing a code is enough to be routed to the
 * right game — the player never has to know which one it was.
 */
app.get('/api/rooms/:code', (req, res) => {
  const entry = lookupCode(req.params.code);
  if (!entry) return res.status(404).json({ error: 'No room with that code.' });

  const store = STORES[entry.gameId];
  const room = store?.get(req.params.code);
  if (!room) return res.status(404).json({ error: 'That room has closed.' });

  res.json({
    gameId: entry.gameId,
    code: room.code,
    state: room.state,
    players: room.players.length,
    maxPlayers: room.maxPlayers,
    isFull: room.isFull,
    mode: room.mode ?? null,
  });
});

app.get('/api/names', (_req, res) => res.json({ suggestions: suggestNames(3) }));

app.get('/healthz', (_req, res) => res.json({ ok: true, uptime: process.uptime() }));

/** Anything else falls through to the SPA so client-side routes deep-link. */
app.use((_req, res) => res.sendFile(path.join(CLIENT_DIR, 'index.html')));

// ── listen ─────────────────────────────────────────────────────────────────

server.listen(PORT, () => {
  console.log('');
  console.log('  🎲  Gaming Hub is live');
  console.log(`      → http://localhost:${PORT}`);
  console.log('');
  console.log('      Playing with remote coworkers? Expose this port with a tunnel:');
  console.log(`      ngrok http ${PORT}`);
  console.log('');
});

/** Shut down cleanly so Ctrl-C doesn't leave the port bound. */
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    console.log('\n  Packing up the gaming hub. Bye! 👋');
    io.close();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  });
}
