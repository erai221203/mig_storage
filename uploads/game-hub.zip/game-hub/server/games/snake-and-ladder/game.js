/**
 * Pure Snake & Ladder rules — no networking, no state, no timers.
 *
 * Everything here is a function of its inputs, which makes the interesting
 * parts (movement, snakes, exact finishes) trivial to test and impossible to
 * get wrong by accident somewhere in the socket layer.
 *
 * Board geometry
 * --------------
 * Squares run 1–100 in a boustrophedon ("ox-turning") zig-zag from the
 * bottom-left, the way a real board is printed:
 *
 *    100 99 98 97 96 95 94 93 92 91     ← row 9, right-to-left
 *     81 82 83 84 85 86 87 88 89 90     ← row 8, left-to-right
 *     ...
 *     20 19 18 17 16 15 14 13 12 11     ← row 1, right-to-left
 *      1  2  3  4  5  6  7  8  9 10     ← row 0, left-to-right
 */

import { BOARD, LADDERS, SNAKES } from './config.js';

/**
 * Where a square sits on the grid.
 * `row` counts up from the bottom (0–9); `col` runs left to right (0–9).
 */
export function squareToCoords(square) {
  const index = square - 1;
  const row = Math.floor(index / BOARD.SIZE);
  const offset = index % BOARD.SIZE;
  // Odd rows are printed right-to-left.
  const col = row % 2 === 0 ? offset : BOARD.SIZE - 1 - offset;
  return { row, col };
}

/** The inverse of squareToCoords, handy for hit-testing a click on the board. */
export function coordsToSquare(row, col) {
  const offset = row % 2 === 0 ? col : BOARD.SIZE - 1 - col;
  return row * BOARD.SIZE + offset + 1;
}

/** Server-side dice. Clients never generate a roll — they only render one. */
export function rollDie() {
  return 1 + Math.floor(Math.random() * 6);
}

/**
 * Work out the full consequence of one roll.
 *
 * Returns a self-contained description of the move, which is exactly what the
 * client needs to animate it:
 *
 *   {
 *     die,                       what was rolled
 *     from, to,                  start and final square
 *     landed,                    square reached before any snake/ladder
 *     via: null|'ladder'|'snake',
 *     blocked,                   true if an overshoot kept the token still
 *     stuck,                     true if a 6 was needed to start and didn't come
 *     finished,                  true if this move reached the last square
 *   }
 */
export function resolveMove(from, die, rules) {
  const last = BOARD.SQUARES;
  const base = {
    die,
    from,
    to: from,
    landed: from,
    via: null,
    blocked: false,
    stuck: false,
    finished: false,
  };

  // Optional house rule: your token only enters the board on a 6.
  if (rules.needSixToStart && from === 0 && die !== 6) {
    return { ...base, stuck: true };
  }

  const target = from + die;

  // Exact finish: overshooting the last square leaves you where you are.
  if (target > last) {
    if (rules.exactFinish) return { ...base, blocked: true };
    return { ...base, to: last, landed: last, finished: true };
  }

  if (target === last) {
    return { ...base, to: last, landed: last, finished: true };
  }

  // A ladder foot or snake head takes effect immediately on landing.
  if (LADDERS[target] !== undefined) {
    const top = LADDERS[target];
    return { ...base, landed: target, to: top, via: 'ladder', finished: top === last };
  }
  if (SNAKES[target] !== undefined) {
    return { ...base, landed: target, to: SNAKES[target], via: 'snake' };
  }

  return { ...base, to: target, landed: target };
}

/** How far a snake drops you — used to pick the "biggest bite" for the drama. */
export function snakeLength(head) {
  const tail = SNAKES[head];
  return tail === undefined ? 0 : head - tail;
}

/** The longest snake on the board, so the UI knows what counts as a disaster. */
export const LONGEST_SNAKE_DROP = Math.max(0, ...Object.keys(SNAKES).map((h) => snakeLength(Number(h))));

/**
 * Rank tokens for the leaderboard: finishers first in the order they finished,
 * then everyone else by how far along they are.
 */
export function rankTokens(tokens) {
  return [...tokens].sort((a, b) => {
    if (a.rank && b.rank) return a.rank - b.rank;
    if (a.rank) return -1;
    if (b.rank) return 1;
    if (b.position !== a.position) return b.position - a.position;
    return a.order - b.order; // stable for equal positions
  });
}

/** Is anyone close enough to the end for the UI to get excited? */
export function inFinalStretch(tokens, threshold = 85) {
  return tokens.some((token) => token.position > threshold);
}
