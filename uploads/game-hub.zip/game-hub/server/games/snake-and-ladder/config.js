/**
 * Snake & Ladder configuration — every tunable rule in one place.
 *
 * Change the board here and both the server and the client follow: the client
 * fetches this via `/api/games/snake-and-ladder/config`, so the drawn snakes,
 * ladders and rule toggles can never disagree with the ones being enforced.
 */

export const GAME_ID = 'snake-and-ladder';

export const BOARD = {
  SIZE: 10, // 10 × 10
  SQUARES: 100,
};

/**
 * Classic placements: 9 ladders up, 10 snakes down.
 * Keys are the square you land on, values are where you end up.
 * Edit freely — the board redraws itself from these, and the server validates
 * them on boot (see `validateBoard`).
 */
export const LADDERS = {
  1: 38,
  4: 14,
  9: 31,
  21: 42,
  28: 84,
  36: 44,
  51: 67,
  71: 91,
  80: 100,
};

export const SNAKES = {
  16: 6,
  47: 26,
  49: 11,
  56: 53,
  62: 19,
  64: 60,
  87: 24,
  93: 73,
  95: 75,
  98: 78,
};

export const MODES = {
  CLASSIC: 'classic',
  RACE: 'race',
  TEAM: 'team',
};

export const MODE_INFO = [
  {
    id: MODES.CLASSIC,
    name: 'Classic',
    blurb: 'One player rolls at a time, the way you remember it.',
    best: 'Best for 2–4 players',
    idealMax: 4,
  },
  {
    id: MODES.RACE,
    name: 'Race',
    blurb: 'Everyone rolls at once each round. Fast, loud, chaotic.',
    best: 'Best for 5–15 players',
    idealMin: 5,
  },
  {
    id: MODES.TEAM,
    name: 'Team',
    blurb: 'Split into teams sharing one token. Take turns rolling for the crew.',
    best: 'Great for big groups',
    idealMin: 6,
  },
];

export const PLAYER_LIMITS = {
  MIN: 2,
  MAX: 15,
  DEFAULT: 4,
  /** "Start game" unlocks at this many. */
  MIN_TO_START: 2,
};

export const RULES = {
  /** Rolling a 6 grants another turn. Classic mode only — it would desync rounds. */
  EXTRA_TURN_ON_SIX: true,
  /** An exact roll is needed to land on 100; overshooting stays put. */
  EXACT_FINISH: true,
  /** Must roll a 6 before your token enters the board. Off so games start fast. */
  NEED_SIX_TO_START: false,
  /**
   * How long the round continues once someone wins:
   *   'first'  — ends immediately
   *   'podium' — carries on until three have finished (default)
   *   'all'    — everybody finishes
   */
  FINISH_MODE: 'podium',
};

export const TIMING = {
  /** Classic mode turn timer options, in seconds. */
  TURN_SECONDS_OPTIONS: [10, 20, 30],
  TURN_SECONDS_DEFAULT: 20,
  /** Race/Team mode: how long the roll window stays open. */
  ROUND_WINDOW_MS: 10_000,
  /**
   * Time the client spends revealing the dice before anything moves: the die
   * spins, lands on the real number, and holds long enough to read. Tokens
   * must not move until this has elapsed — a token that moves while the die
   * is still spinning looks like it moved by the wrong number.
   */
  DICE_REVEAL_MS: 1_250,
  /** Time allowed for the tokens themselves to move (the spec's "~3 seconds"). */
  MOVE_MS: 3_000,
  /**
   * Total animation budget the server waits before opening the next round.
   * Dice reveal happens first, then movement, so it is the sum of the two.
   */
  ANIMATION_MS: 4_250,
  /** A brief beat between a round's results and the next window opening. */
  ROUND_GAP_MS: 700,
  /** Countdown before the very first round, so people can find their token. */
  START_DELAY_MS: 2_000,
};

export const TEAMS = {
  MIN: 2,
  MAX: 4,
  DEFAULT: 2,
  /** Names and colours are handed out in order. */
  PRESETS: [
    { name: 'Red Rockets', color: '#e17f7f', emoji: '🚀' },
    { name: 'Blue Bolts', color: '#7fb2e5', emoji: '⚡' },
    { name: 'Green Geckos', color: '#7fc9a0', emoji: '🦎' },
    { name: 'Yellow Yaks', color: '#dfc06a', emoji: '🐃' },
  ],
};

/** Allowed emoji reactions — a fixed set, so this can't relay arbitrary text. */
export const REACTIONS = ['😂', '🐍', '🪜', '😭', '🎉'];

/**
 * Fail fast on a badly edited board rather than halfway through a game.
 * Called once when the game registers.
 */
export function validateBoard() {
  const problems = [];
  const inRange = (n) => Number.isInteger(n) && n >= 1 && n <= BOARD.SQUARES;

  for (const [from, to] of Object.entries(LADDERS)) {
    const start = Number(from);
    if (!inRange(start) || !inRange(to)) problems.push(`ladder ${from}→${to} is off the board`);
    else if (to <= start) problems.push(`ladder ${from}→${to} does not go up`);
  }

  for (const [from, to] of Object.entries(SNAKES)) {
    const start = Number(from);
    if (!inRange(start) || !inRange(to)) problems.push(`snake ${from}→${to} is off the board`);
    else if (to >= start) problems.push(`snake ${from}→${to} does not go down`);
  }

  // A square can't be both a snake head and a ladder foot, and chaining one
  // into another would make moves ambiguous.
  for (const from of Object.keys(LADDERS)) {
    if (SNAKES[from]) problems.push(`square ${from} is both a ladder foot and a snake head`);
  }
  for (const to of Object.values(LADDERS)) {
    if (SNAKES[to] || LADDERS[to]) problems.push(`ladder top ${to} lands on another snake/ladder`);
  }
  for (const to of Object.values(SNAKES)) {
    if (SNAKES[to] || LADDERS[to]) problems.push(`snake tail ${to} lands on another snake/ladder`);
  }
  if (SNAKES[BOARD.SQUARES]) problems.push('the final square cannot be a snake head');

  if (problems.length) {
    throw new Error(`Invalid Snake & Ladder board:\n  - ${problems.join('\n  - ')}`);
  }
  return true;
}

/** Everything the client needs to draw the board and show the rules. */
export function clientConfig() {
  return {
    board: BOARD,
    ladders: LADDERS,
    snakes: SNAKES,
    modes: MODE_INFO,
    limits: PLAYER_LIMITS,
    rules: RULES,
    timing: {
      turnSecondsOptions: TIMING.TURN_SECONDS_OPTIONS,
      turnSecondsDefault: TIMING.TURN_SECONDS_DEFAULT,
      roundWindowMs: TIMING.ROUND_WINDOW_MS,
      animationMs: TIMING.ANIMATION_MS,
      diceRevealMs: TIMING.DICE_REVEAL_MS,
      moveMs: TIMING.MOVE_MS,
    },
    teams: { min: TEAMS.MIN, max: TEAMS.MAX, default: TEAMS.DEFAULT, presets: TEAMS.PRESETS },
    reactions: REACTIONS,
  };
}
