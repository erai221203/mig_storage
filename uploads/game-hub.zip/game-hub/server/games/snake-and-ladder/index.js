/**
 * Snake & Ladder network layer.
 *
 * Every game in the hub gets its own Socket.IO namespace (`/snake-and-ladder`),
 * so event names can never collide between games and a client only receives
 * traffic for the game it is actually playing.
 *
 * Broadcast discipline
 * --------------------
 * Nothing in this game is private — all token positions are public — so state
 * goes out as ONE `snl:state` broadcast to the room, not a payload per player.
 * With 15 players that keeps a round at a handful of messages instead of
 * hundreds. The only per-action messages are tiny ones (`snl:rolled` carries
 * just an id).
 */

import { RoomStore, RoomState } from '../../shared/room-manager.js';
import { suggestNames } from '../../shared/players.js';
import { GAME_ID, MODES, PLAYER_LIMITS, REACTIONS, validateBoard } from './config.js';
import { SnakeLadderRoom } from './room.js';

export const gameId = GAME_ID;

/** Shared by the HTTP layer so `/api/rooms/:code` can find a room. */
export const rooms = new RoomStore((options) => new SnakeLadderRoom(options));

export function register(io) {
  validateBoard(); // fail loudly on a badly edited board, not mid-game

  const namespace = io.of(`/${GAME_ID}`);
  /** socket.id → { code, memberId } */
  const sessions = new Map();

  const fail = (message, code = 'ERROR') => ({ ok: false, code, message });

  // ── outbound ─────────────────────────────────────────────────────────────

  /** One snapshot, one broadcast, everyone. */
  function broadcastState(room) {
    namespace.to(room.code).emit('snl:state', room.publicState());
  }

  /** Wire a room's events to the wire, exactly once when it is created. */
  function bindRoom(room) {
    room.on('update', () => broadcastState(room));
    room.on('results', (payload) => namespace.to(room.code).emit('snl:results', payload));
    room.on('rolled', (payload) => namespace.to(room.code).emit('snl:rolled', payload));
    room.on('gameOver', (payload) => namespace.to(room.code).emit('snl:gameOver', payload));
  }

  function contextFor(socket) {
    const session = sessions.get(socket.id);
    if (!session) return null;
    const room = rooms.get(session.code);
    if (!room) return null;
    const member = room.getMember(session.memberId);
    if (!member) return null;
    return { room, member, isSpectator: Boolean(member.isSpectator) };
  }

  /** Attach a socket to a room and send it everything it needs to render. */
  function seat(socket, room, member) {
    member.socketId = socket.id;
    member.connected = true;
    sessions.set(socket.id, { code: room.code, memberId: member.id });
    socket.join(room.code);

    socket.emit('snl:welcome', {
      code: room.code,
      memberId: member.id,
      isSpectator: Boolean(member.isSpectator),
      state: room.publicState(),
      chat: room.chat,
    });
    broadcastState(room);
  }

  /** Release whatever seat a socket holds, cleaning up an empty room. */
  function detach(socket) {
    const context = contextFor(socket);
    sessions.delete(socket.id);
    if (!context) return;

    const { room, member } = context;
    room.removePlayer(member.id);
    socket.leave(room.code);

    if (room.players.length === 0 && room.spectators.length === 0) rooms.delete(room.code);
    else broadcastState(room);
  }

  // ── connection ───────────────────────────────────────────────────────────

  namespace.on('connection', (socket) => {
    /** Wrap handlers so a thrown error can never take the server down. */
    const handle = (event, fn) => {
      socket.on(event, async (payload, ack) => {
        const respond = typeof ack === 'function' ? ack : () => {};
        try {
          respond((await fn(payload ?? {})) ?? { ok: true });
        } catch (error) {
          console.error(`[snl] ${event} failed:`, error);
          respond(fail('Something went wrong on our side. Try again?'));
        }
      });
    };

    /** Host-only guard, used by every table-management action. */
    const asHost = (fn) => () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot do that.');
      if (!context.member.isHost) return fail('Only the host can do that.');
      return fn(context);
    };

    // ── joining ────────────────────────────────────────────────────────────

    handle('snl:create', ({ name, maxPlayers, mode }) => {
      detach(socket);

      const seats = Number(maxPlayers) || PLAYER_LIMITS.DEFAULT;
      if (seats < PLAYER_LIMITS.MIN || seats > PLAYER_LIMITS.MAX) {
        return fail(`Player count must be ${PLAYER_LIMITS.MIN}–${PLAYER_LIMITS.MAX}.`);
      }
      const chosenMode = Object.values(MODES).includes(mode) ? mode : MODES.CLASSIC;

      const room = rooms.create({ maxPlayers: seats, mode: chosenMode });
      bindRoom(room);
      if (chosenMode === MODES.TEAM) room.rebuildTeams();

      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id };
    });

    handle('snl:join', ({ code, name, spectate }) => {
      const room = rooms.get(code);
      const shown = String(code ?? '').trim().toUpperCase();
      if (!room) return fail(`No room called "${shown}" — double-check the code? 🤔`, 'NO_ROOM');

      // Same room, same name, still inside the grace window → take the seat back.
      const existing = room.findByName(String(name ?? '').trim());
      if (existing && !existing.connected) {
        room.reconnectPlayer(existing, socket.id);
        seat(socket, room, existing);
        return { ok: true, code: room.code, memberId: existing.id, resumed: true };
      }

      if (room.isFull || spectate) {
        // A full room isn't a dead end — you can still watch and chat.
        if (!room.isFull && !spectate) return fail('Could not join.', 'ERROR');
        const spectator = room.addSpectator(name, socket.id);
        seat(socket, room, spectator);
        return {
          ok: true,
          code: room.code,
          memberId: spectator.id,
          spectator: true,
          message: room.isFull ? 'That room is full — you joined as a spectator 👀' : undefined,
        };
      }

      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id, name: player.name };
    });

    /** Silent restore after a refresh or a dropped socket. */
    handle('snl:rejoin', ({ code, memberId }) => {
      const room = rooms.get(code);
      if (!room) return fail('That room has closed.', 'NO_ROOM');

      const member = room.getMember(memberId);
      if (!member) return fail('Your seat expired — rejoin with your name.', 'NO_SEAT');

      if (!member.isSpectator) room.reconnectPlayer(member, socket.id);
      seat(socket, room, member);
      return { ok: true, code: room.code, memberId: member.id, resumed: true };
    });

    handle('snl:leave', () => {
      detach(socket);
      return { ok: true };
    });

    // ── lobby ──────────────────────────────────────────────────────────────

    handle('snl:configure', (patch) => asHost(({ room }) => room.configure(patch))());

    handle('snl:switchTeam', ({ teamId }) => {
      const context = contextFor(socket);
      if (!context || context.isSpectator) return fail('You are not playing.');
      return context.room.switchTeam(context.member.id, teamId);
    });

    handle('snl:start', () => asHost(({ room }) => room.start())());

    handle('snl:kick', ({ playerId }) =>
      asHost(({ room, member }) => {
        if (playerId === member.id) return fail('You cannot remove yourself.');
        const target = room.getPlayer(playerId);
        if (!target) return fail('That player has already left.');

        namespace.to(room.code).emit('snl:kicked', { playerId, name: target.name });
        // Drop their socket out of the room so they stop receiving updates.
        if (target.socketId) {
          const targetSocket = namespace.sockets.get(target.socketId);
          if (targetSocket) {
            sessions.delete(targetSocket.id);
            targetSocket.leave(room.code);
          }
        }
        room.removePlayer(playerId);
        room.scheduleUpdate();
        return { ok: true };
      })(),
    );

    // ── playing ────────────────────────────────────────────────────────────

    /**
     * The only "move" a player can make. Note there is no die in the payload —
     * the server rolls, so a modified client cannot cheat.
     */
    handle('snl:roll', () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot roll.');

      const { room, member } = context;
      if (room.state !== RoomState.PLAYING) return fail('The game is not running.');

      if (room.mode === MODES.CLASSIC) {
        if (room.phase !== 'turn') return fail('Hold on — moves are still landing.');
        if (room.turnTokenId !== member.id) {
          const holder = room.getPlayer(room.turnTokenId);
          return fail(holder ? `It's ${holder.name}'s turn.` : 'Not your turn.');
        }
        room._takeTurn(member.id);
        return { ok: true };
      }

      return room.submitRoll(member.id);
    });

    handle('snl:endGame', () => asHost(({ room }) => room.endGame('host ended it'))());
    handle('snl:rematch', () => asHost(({ room }) => room.rematch())());

    // ── social ─────────────────────────────────────────────────────────────

    handle('snl:chat', ({ text }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');

      const result = context.room.addChatMessage(context.member, text);
      if (!result.ok) return fail(result.message ?? 'That message did not send.');

      namespace.to(context.room.code).emit('snl:chat', result.message);
      return { ok: true };
    });

    handle('snl:react', ({ emoji }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (!REACTIONS.includes(emoji)) return fail('Unknown reaction.');

      // One reaction per player every two seconds — with 15 players the screen
      // would otherwise fill with floating emoji.
      if (!context.room.canReact(context.member)) return { ok: false, code: 'RATE_LIMIT' };

      namespace.to(context.room.code).emit('snl:reaction', {
        emoji,
        playerId: context.member.id,
        name: context.member.name,
        color: context.member.color,
      });
      return { ok: true };
    });

    handle('snl:names', () => ({ ok: true, suggestions: suggestNames(3) }));

    // ── teardown ───────────────────────────────────────────────────────────

    socket.on('disconnect', () => {
      const session = sessions.get(socket.id);
      sessions.delete(socket.id);
      if (!session) return;

      const room = rooms.get(session.code);
      if (!room) return;
      room.handleDisconnect(session.memberId);
    });
  });

  return { namespace, rooms };
}
