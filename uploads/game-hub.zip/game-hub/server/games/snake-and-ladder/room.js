/**
 * A Snake & Ladder room: the rules of config.js and game.js, plus the state and
 * timers that make them a live game.
 *
 * Three modes share one machine:
 *
 *   Classic — one token rolls at a time, with a turn timer that auto-rolls.
 *   Race    — every token rolls inside a shared window, then all moves resolve
 *             together. Nobody ever waits for someone else's turn.
 *   Team    — Race rounds, but tokens belong to teams and one member per team
 *             rolls each round, rotating through the roster.
 *
 * The server owns all randomness and all round timing. Clients only render.
 */

import { BaseRoom, RoomState } from '../../shared/room-manager.js';
import {
  GAME_ID,
  MODES,
  PLAYER_LIMITS,
  RULES,
  TEAMS,
  TIMING,
} from './config.js';
import { LONGEST_SNAKE_DROP, rankTokens, resolveMove, rollDie, snakeLength } from './game.js';

/** What the room is doing right now. Drives most of the client UI. */
export const Phase = {
  LOBBY: 'lobby',
  COUNTDOWN: 'countdown', // brief pause before the first round
  TURN: 'turn', // classic: someone is on the clock
  ROLLING: 'rolling', // race/team: the roll window is open
  RESOLVING: 'resolving', // moves are animating on every client
  ENDED: 'ended',
};

export class SnakeLadderRoom extends BaseRoom {
  constructor({ maxPlayers = PLAYER_LIMITS.DEFAULT, mode = MODES.CLASSIC } = {}) {
    super({ gameId: GAME_ID, maxPlayers });

    this.mode = mode;
    this.phase = Phase.LOBBY;

    this.rules = {
      extraTurnOnSix: RULES.EXTRA_TURN_ON_SIX,
      exactFinish: RULES.EXACT_FINISH,
      needSixToStart: RULES.NEED_SIX_TO_START,
      finishMode: RULES.FINISH_MODE,
      turnSeconds: TIMING.TURN_SECONDS_DEFAULT,
    };

    this.teamCount = TEAMS.DEFAULT;
    this.teams = []; // populated only in team mode

    this.tokens = []; // one per player, or one per team
    this.round = 0;
    this.finishedCount = 0;

    // Classic-mode turn state
    this.turnTokenId = null;
    this.turnDeadline = null;
    this.extraTurn = false;

    // Race/Team round state
    this.roundDeadline = null;
    this.pendingRolls = new Map(); // tokenId → die

    this.lastResults = null;
    this.finalStretchAnnounced = false;

    this._timers = new Set();
  }

  // ── timer bookkeeping ────────────────────────────────────────────────────

  /** Every timer goes through here so `destroy()` can guarantee cleanup. */
  _later(fn, ms) {
    const timer = setTimeout(() => {
      this._timers.delete(timer);
      if (!this._destroyed) fn();
    }, ms);
    timer.unref?.();
    this._timers.add(timer);
    return timer;
  }

  _clearTimers() {
    for (const timer of this._timers) clearTimeout(timer);
    this._timers.clear();
  }

  onDestroy() {
    this._clearTimers();
  }

  // ── lobby configuration ──────────────────────────────────────────────────

  /** Host-only settings, all validated here rather than trusted from the wire. */
  configure(patch) {
    if (this.state !== RoomState.LOBBY) {
      return { ok: false, message: 'Settings can only change in the lobby.' };
    }

    if (patch.mode !== undefined) {
      if (!Object.values(MODES).includes(patch.mode)) {
        return { ok: false, message: 'Unknown game mode.' };
      }
      this.mode = patch.mode;
      if (this.mode === MODES.TEAM) this.rebuildTeams();
      else this.teams = [];
    }

    if (patch.maxPlayers !== undefined) {
      const value = Number(patch.maxPlayers);
      if (!Number.isInteger(value) || value < PLAYER_LIMITS.MIN || value > PLAYER_LIMITS.MAX) {
        return { ok: false, message: `Player count must be ${PLAYER_LIMITS.MIN}–${PLAYER_LIMITS.MAX}.` };
      }
      if (value < this.players.length) {
        return { ok: false, message: `There are already ${this.players.length} players here.` };
      }
      this.maxPlayers = value;
    }

    if (patch.teamCount !== undefined) {
      const value = Number(patch.teamCount);
      if (!Number.isInteger(value) || value < TEAMS.MIN || value > TEAMS.MAX) {
        return { ok: false, message: `Teams must be ${TEAMS.MIN}–${TEAMS.MAX}.` };
      }
      this.teamCount = value;
      if (this.mode === MODES.TEAM) this.rebuildTeams();
    }

    for (const key of ['extraTurnOnSix', 'exactFinish', 'needSixToStart']) {
      if (patch[key] !== undefined) this.rules[key] = Boolean(patch[key]);
    }

    if (patch.finishMode !== undefined) {
      if (!['first', 'podium', 'all'].includes(patch.finishMode)) {
        return { ok: false, message: 'Unknown finish rule.' };
      }
      this.rules.finishMode = patch.finishMode;
    }

    if (patch.turnSeconds !== undefined) {
      const value = Number(patch.turnSeconds);
      if (!TIMING.TURN_SECONDS_OPTIONS.includes(value)) {
        return { ok: false, message: 'Pick one of the offered turn timers.' };
      }
      this.rules.turnSeconds = value;
    }

    this.scheduleUpdate();
    return { ok: true };
  }

  // ── teams ────────────────────────────────────────────────────────────────

  /** Auto-balance everyone across the configured number of teams. */
  rebuildTeams() {
    this.teams = Array.from({ length: this.teamCount }, (_, index) => ({
      id: `team-${index}`,
      ...TEAMS.PRESETS[index],
      memberIds: [],
      rollerIndex: 0,
    }));

    // Snake-draft the join order so teams stay even as people arrive.
    this.players.forEach((player, index) => {
      this.teams[index % this.teamCount].memberIds.push(player.id);
    });
  }

  teamOf(playerId) {
    return this.teams.find((team) => team.memberIds.includes(playerId)) ?? null;
  }

  /** Let a player pick a different team in the lobby. */
  switchTeam(playerId, teamId) {
    if (this.mode !== MODES.TEAM) return { ok: false, message: 'Not a team game.' };
    if (this.state !== RoomState.LOBBY) {
      return { ok: false, message: 'Teams are locked once the game starts.' };
    }

    const target = this.teams.find((team) => team.id === teamId);
    if (!target) return { ok: false, message: 'That team does not exist.' };

    for (const team of this.teams) {
      team.memberIds = team.memberIds.filter((id) => id !== playerId);
    }
    target.memberIds.push(playerId);

    this.scheduleUpdate();
    return { ok: true };
  }

  // ── membership hooks (called by BaseRoom) ────────────────────────────────

  onPlayerAdded(player) {
    if (this.mode === MODES.TEAM && this.state === RoomState.LOBBY) {
      // Drop them into the smallest team so things stay balanced.
      if (this.teams.length === 0) this.rebuildTeams();
      const smallest = this.teams.reduce((a, b) => (a.memberIds.length <= b.memberIds.length ? a : b));
      smallest.memberIds.push(player.id);
    }

    // Somebody joining mid-game gets a token at the start line.
    if (this.state === RoomState.PLAYING && this.mode !== MODES.TEAM) {
      this.tokens.push(this._makePlayerToken(player, this.tokens.length));
    }
  }

  onPlayerRemoved(player) {
    for (const team of this.teams) {
      team.memberIds = team.memberIds.filter((id) => id !== player.id);
    }

    if (this.state !== RoomState.PLAYING) {
      this.tokens = this.tokens.filter((token) => token.id !== player.id);
      return;
    }

    if (this.mode === MODES.TEAM) {
      this._checkRoundComplete();
      return;
    }

    // Their token leaves with them; don't let the game stall on their turn.
    this.tokens = this.tokens.filter((token) => token.id !== player.id);
    if (this.turnTokenId === player.id) this._advanceTurn();
    else this._checkRoundComplete();
    this._checkGameOver();
  }

  onPlayerDisconnected(player) {
    if (this.state !== RoomState.PLAYING) return;

    // Classic: don't make everyone sit through the full timer for someone who
    // has clearly gone. Give them a moment to come back, then play for them.
    if (this.mode === MODES.CLASSIC && this.turnTokenId === player.id) {
      this._later(() => {
        const current = this.getPlayer(player.id);
        if (this.phase === Phase.TURN && this.turnTokenId === player.id && current && !current.connected) {
          this._takeTurn(player.id, { auto: true });
        }
      }, 1500);
    } else {
      // Race/Team: they might have been the last roll the round was waiting on.
      this._checkRoundComplete();
    }
  }

  // ── starting ─────────────────────────────────────────────────────────────

  _makePlayerToken(player, order) {
    return {
      id: player.id,
      kind: 'player',
      name: player.name,
      initials: player.initials,
      color: player.color,
      memberIds: [player.id],
      position: 0,
      rank: null,
      finished: false,
      order,
    };
  }

  _makeTeamToken(team, order) {
    return {
      id: team.id,
      kind: 'team',
      name: team.name,
      initials: team.emoji,
      color: team.color,
      memberIds: [...team.memberIds],
      position: 0,
      rank: null,
      finished: false,
      order,
    };
  }

  start() {
    if (this.state === RoomState.PLAYING) {
      return { ok: false, message: 'The game is already running.' };
    }
    if (this.connectedPlayers.length < PLAYER_LIMITS.MIN_TO_START) {
      return { ok: false, message: `You need at least ${PLAYER_LIMITS.MIN_TO_START} players to start.` };
    }

    if (this.mode === MODES.TEAM) {
      if (this.teams.length === 0) this.rebuildTeams();
      const staffed = this.teams.filter((team) => team.memberIds.length > 0);
      if (staffed.length < 2) {
        return { ok: false, message: 'At least two teams need a player.' };
      }
      this.teams = staffed;
      this.tokens = this.teams.map((team, index) => this._makeTeamToken(team, index));
    } else {
      this.tokens = this.players.map((player, index) => this._makePlayerToken(player, index));
    }

    this._clearTimers();
    this.state = RoomState.PLAYING;
    this.phase = Phase.COUNTDOWN;
    this.round = 0;
    this.finishedCount = 0;
    this.lastResults = null;
    this.finalStretchAnnounced = false;
    this.pendingRolls.clear();

    this.emitUpdateNow();

    // A short beat so everyone can find their token before it all kicks off.
    this._later(() => {
      if (this.mode === MODES.CLASSIC) this._beginClassicTurn(this.tokens[0].id);
      else this._openRound();
    }, TIMING.START_DELAY_MS);

    return { ok: true };
  }

  // ── classic mode ─────────────────────────────────────────────────────────

  _beginClassicTurn(tokenId) {
    if (this.state !== RoomState.PLAYING) return;

    this.turnTokenId = tokenId;
    this.phase = Phase.TURN;
    this.turnDeadline = Date.now() + this.rules.turnSeconds * 1000;
    this.emitUpdateNow();

    this._later(() => {
      // Still the same player's turn when the clock ran out? Roll for them.
      if (this.phase === Phase.TURN && this.turnTokenId === tokenId) {
        this._takeTurn(tokenId, { auto: true });
      }
    }, this.rules.turnSeconds * 1000);
  }

  /** A classic-mode roll, whether tapped by the player or auto-rolled. */
  _takeTurn(tokenId, { auto = false } = {}) {
    const token = this.tokens.find((t) => t.id === tokenId);
    if (!token || token.finished) {
      this._advanceTurn();
      return;
    }

    this._clearTimers();
    const die = rollDie();
    const result = this._applyMove(token, die, auto);

    this.phase = Phase.RESOLVING;
    this.lastResults = [result];
    this.emit('results', { round: this.round, results: [result], mode: this.mode });
    this.emitUpdateNow();

    // A 6 earns another go — but never after finishing.
    this.extraTurn = this.rules.extraTurnOnSix && die === 6 && !token.finished;

    this._later(() => {
      if (this._checkGameOver()) return;
      if (this.extraTurn) {
        this.extraTurn = false;
        this._beginClassicTurn(tokenId);
      } else {
        this._advanceTurn();
      }
    }, this._animationBudget([result]));
  }

  _advanceTurn() {
    if (this.state !== RoomState.PLAYING) return;
    if (this._checkGameOver()) return;

    const playable = this.tokens.filter((t) => !t.finished);
    if (playable.length === 0) {
      this.endGame('everyone home');
      return;
    }

    const currentIndex = this.tokens.findIndex((t) => t.id === this.turnTokenId);
    for (let step = 1; step <= this.tokens.length; step++) {
      const candidate = this.tokens[(currentIndex + step + this.tokens.length) % this.tokens.length];
      if (candidate && !candidate.finished) {
        this._beginClassicTurn(candidate.id);
        return;
      }
    }
    this._beginClassicTurn(playable[0].id);
  }

  // ── race & team modes ────────────────────────────────────────────────────

  _openRound() {
    if (this.state !== RoomState.PLAYING) return;
    if (this._checkGameOver()) return;

    this.round += 1;
    this.phase = Phase.ROLLING;
    this.pendingRolls.clear();
    this.roundDeadline = Date.now() + TIMING.ROUND_WINDOW_MS;

    // Team mode: rotate which member rolls for each team this round.
    if (this.mode === MODES.TEAM) {
      for (const team of this.teams) {
        if (team.memberIds.length > 0) {
          team.rollerIndex = (this.round - 1) % team.memberIds.length;
        }
      }
    }

    this.emitUpdateNow();

    this._later(() => {
      if (this.phase === Phase.ROLLING) this._resolveRound();
    }, TIMING.ROUND_WINDOW_MS);
  }

  /** Who is allowed to roll for this token right now? */
  rollerFor(tokenId) {
    if (this.mode !== MODES.TEAM) return tokenId;
    const team = this.teams.find((t) => t.id === tokenId);
    if (!team || team.memberIds.length === 0) return null;
    return team.memberIds[team.rollerIndex % team.memberIds.length] ?? null;
  }

  /** Which token, if any, is this player rolling for? */
  tokenForPlayer(playerId) {
    if (this.mode === MODES.TEAM) {
      const team = this.teamOf(playerId);
      return team ? this.tokens.find((t) => t.id === team.id) ?? null : null;
    }
    return this.tokens.find((t) => t.id === playerId) ?? null;
  }

  /** A player tapping ROLL during the window. */
  submitRoll(playerId) {
    if (this.phase !== Phase.ROLLING) {
      return { ok: false, message: 'The roll window is not open.' };
    }

    const token = this.tokenForPlayer(playerId);
    if (!token) return { ok: false, message: 'You do not have a token in this game.' };
    if (token.finished) return { ok: false, message: 'You are already home!' };

    if (this.mode === MODES.TEAM && this.rollerFor(token.id) !== playerId) {
      const roller = this.getPlayer(this.rollerFor(token.id));
      return { ok: false, message: roller ? `${roller.name} is rolling for your team.` : 'Not your roll.' };
    }

    if (this.pendingRolls.has(token.id)) {
      return { ok: false, message: 'You already rolled this round.' };
    }

    // The die is generated here, on the server — never sent up by the client.
    this.pendingRolls.set(token.id, rollDie());

    // Tell the room somebody is ready. This is a tiny payload, one per roll,
    // rather than a full state broadcast per player.
    this.emit('rolled', { tokenId: token.id, playerId, round: this.round });

    this._checkRoundComplete();
    return { ok: true };
  }

  /** Close the window early once every token that can roll has rolled. */
  _checkRoundComplete() {
    if (this.phase !== Phase.ROLLING) return;

    const waitingOn = this.tokens.filter(
      (token) => !token.finished && !this.pendingRolls.has(token.id),
    );
    if (waitingOn.length === 0) this._resolveRound();
  }

  _resolveRound() {
    if (this.phase !== Phase.ROLLING) return;
    this._clearTimers();

    const results = [];
    for (const token of this.tokens) {
      if (token.finished) continue;

      const submitted = this.pendingRolls.get(token.id);
      const auto = submitted === undefined;
      const die = auto ? rollDie() : submitted;
      results.push(this._applyMove(token, die, auto));
    }

    this.pendingRolls.clear();
    this.phase = Phase.RESOLVING;
    this.lastResults = results;

    // ONE broadcast carrying every move, rather than fifteen separate ones.
    this.emit('results', { round: this.round, results, mode: this.mode });
    this.emitUpdateNow();

    this._later(() => {
      if (this._checkGameOver()) return;
      this._later(() => this._openRound(), TIMING.ROUND_GAP_MS);
    }, this._animationBudget(results));
  }

  // ── shared movement ──────────────────────────────────────────────────────

  /** Apply one roll to one token and describe it for the client's animation. */
  _applyMove(token, die, auto) {
    const move = resolveMove(token.position, die, this.rules);
    token.position = move.to;

    if (move.finished && !token.finished) {
      token.finished = true;
      this.finishedCount += 1;
      token.rank = this.finishedCount;
    }

    return {
      tokenId: token.id,
      name: token.name,
      color: token.color,
      auto,
      ...move,
      rank: token.rank,
      // Flags the UI uses for its dramatic moments.
      bigBite: move.via === 'snake' && snakeLength(move.landed) >= LONGEST_SNAKE_DROP,
      soClose: !move.finished && move.to >= 90,
    };
  }

  /**
   * How long clients need before the next round may open.
   *
   * Always includes the dice reveal: the client spins the die, lands it on the
   * real number and holds it before a single token moves. Race mode then
   * budgets the full move window so fifteen tokens land together; classic
   * scales with its one move.
   */
  _animationBudget(results) {
    if (this.mode !== MODES.CLASSIC) return TIMING.ANIMATION_MS;

    const move = results[0];
    if (!move) return TIMING.DICE_REVEAL_MS + 400;

    const steps = Math.abs(move.landed - move.from);
    const hop = 140;
    const movement = 400 + steps * hop + (move.via ? 600 : 0);
    return Math.min(TIMING.ANIMATION_MS, TIMING.DICE_REVEAL_MS + movement);
  }

  // ── ending ───────────────────────────────────────────────────────────────

  /** Have we reached the configured finish condition? */
  _checkGameOver() {
    if (this.state !== RoomState.PLAYING) return true;

    const unfinished = this.tokens.filter((t) => !t.finished);
    const { finishMode } = this.rules;

    let done = false;
    if (this.finishedCount > 0 && finishMode === 'first') done = true;
    else if (this.finishedCount >= 3 && finishMode === 'podium') done = true;
    else if (unfinished.length === 0) done = true;
    // With one token left there is nobody to race, so wrap it up.
    else if (unfinished.length <= 1 && this.finishedCount > 0) done = true;

    if (done) {
      this.endGame('finished');
      return true;
    }
    return false;
  }

  /** Host can also stop early; everyone still on the board is ranked by position. */
  endGame(reason = 'ended') {
    if (this.state === RoomState.ENDED) return { ok: true };

    this._clearTimers();

    // Anyone who didn't reach 100 is ranked by how far they got.
    const remaining = rankTokens(this.tokens.filter((t) => !t.finished));
    remaining.forEach((token) => {
      this.finishedCount += 1;
      token.rank = this.finishedCount;
    });

    this.state = RoomState.ENDED;
    this.phase = Phase.ENDED;
    this.turnTokenId = null;
    this.turnDeadline = null;
    this.roundDeadline = null;

    this.emit('gameOver', { standings: this.standings(), reason });
    this.emitUpdateNow();
    return { ok: true };
  }

  /** Reset to the lobby for a rematch, keeping the room and its players. */
  rematch() {
    this._clearTimers();
    this.state = RoomState.LOBBY;
    this.phase = Phase.LOBBY;
    this.tokens = [];
    this.round = 0;
    this.finishedCount = 0;
    this.turnTokenId = null;
    this.turnDeadline = null;
    this.roundDeadline = null;
    this.lastResults = null;
    this.finalStretchAnnounced = false;
    this.pendingRolls.clear();
    if (this.mode === MODES.TEAM) this.rebuildTeams();
    this.emitUpdateNow();
    return { ok: true };
  }

  standings() {
    return rankTokens(this.tokens).map((token, index) => ({
      place: token.rank ?? index + 1,
      tokenId: token.id,
      name: token.name,
      color: token.color,
      initials: token.initials,
      position: token.position,
      finished: token.finished,
    }));
  }

  // ── serialization ────────────────────────────────────────────────────────

  /**
   * One snapshot for the whole room. There is nothing private in Snake &
   * Ladder — every position is public — so this goes out as a single
   * broadcast rather than a per-player payload.
   */
  publicState() {
    const anyPastThreshold = this.tokens.some((t) => t.position > 85 && !t.finished);

    return {
      ...this.baseState(),
      mode: this.mode,
      phase: this.phase,
      rules: { ...this.rules },
      round: this.round,
      tokens: this.tokens.map((token) => ({
        id: token.id,
        kind: token.kind,
        name: token.name,
        initials: token.initials,
        color: token.color,
        // Only teams need a roster: for a player token the id *is* the player,
        // so shipping it again would be dead weight on every broadcast.
        ...(token.kind === 'team' ? { memberIds: token.memberIds } : {}),
        position: token.position,
        rank: token.rank,
        finished: token.finished,
      })),
      teams:
        this.mode === MODES.TEAM
          ? this.teams.map((team) => ({
              id: team.id,
              name: team.name,
              color: team.color,
              emoji: team.emoji,
              memberIds: [...team.memberIds],
              rollerId: this.rollerFor(team.id),
            }))
          : [],
      turnTokenId: this.turnTokenId,
      turnDeadline: this.turnDeadline,
      roundDeadline: this.roundDeadline,
      /** Who has already rolled this round — drives the "ready" ticks. */
      rolled: [...this.pendingRolls.keys()],
      standings: this.state === RoomState.ENDED ? this.standings() : null,
      finalStretch: anyPastThreshold,
      finishedCount: this.finishedCount,
    };
  }
}
