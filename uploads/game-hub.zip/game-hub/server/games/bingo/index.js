/**
 * Bingo network layer, on its own Socket.IO namespace (`/bingo`).
 *
 * Unlike Snake & Ladder, this game has one private thing per player — their
 * card — so state goes out per player rather than as a single room broadcast.
 * The payload is small and the room caps well below Snake & Ladder's fifteen,
 * so that costs little; everything transient (a call, a chat line, a reaction)
 * is still a single broadcast.
 */

import { RoomStore, RoomState } from '../../shared/room-manager.js';
import { GAME_ID, PLAYER_LIMITS, REACTIONS } from './config.js';
import { BingoRoom } from './room.js';

export const gameId = GAME_ID;

export const rooms = new RoomStore((options) => new BingoRoom(options));

export function register(io) {
  const namespace = io.of(`/${GAME_ID}`);
  /** socket.id → { code, memberId } */
  const sessions = new Map();

  const fail = (message, code = 'ERROR') => ({ ok: false, code, message });

  /** Public state to all, plus each player's own card. */
  function pushState(room) {
    const shared = room.publicState();
    for (const player of room.players) {
      if (!player.connected || !player.socketId) continue;
      namespace.to(player.socketId).emit('bingo:state', {
        ...shared,
        you: room.privateState(player),
      });
    }
    for (const spectator of room.spectators) {
      if (spectator.socketId) {
        namespace.to(spectator.socketId).emit('bingo:state', { ...shared, you: null });
      }
    }
  }

  function bindRoom(room) {
    room.on('update', () => pushState(room));
    room.on('called', (payload) => namespace.to(room.code).emit('bingo:called', payload));
    room.on('gameOver', (payload) => namespace.to(room.code).emit('bingo:gameOver', payload));
  }

  function contextFor(socket) {
    const session = sessions.get(socket.id);
    if (!session) return null;
    const room = rooms.get(session.code);
    if (!room) return null;
    const member = room.getMember(session.memberId);
    if (!member) return null;
    return { room, member, isSpectator: Boolean(member.isSpectator) };
  }

  function seat(socket, room, member) {
    member.socketId = socket.id;
    member.connected = true;
    sessions.set(socket.id, { code: room.code, memberId: member.id });
    socket.join(room.code);

    socket.emit('bingo:welcome', {
      code: room.code,
      memberId: member.id,
      isSpectator: Boolean(member.isSpectator),
      chat: room.chat,
    });
    pushState(room);
  }

  function detach(socket) {
    const context = contextFor(socket);
    sessions.delete(socket.id);
    if (!context) return;

    const { room, member } = context;
    room.removePlayer(member.id);
    socket.leave(room.code);

    if (room.players.length === 0 && room.spectators.length === 0) rooms.delete(room.code);
    else pushState(room);
  }

  namespace.on('connection', (socket) => {
    const handle = (event, fn) => {
      socket.on(event, async (payload, ack) => {
        const respond = typeof ack === 'function' ? ack : () => {};
        try {
          respond((await fn(payload ?? {})) ?? { ok: true });
        } catch (error) {
          console.error(`[bingo] ${event} failed:`, error);
          respond(fail('Something went wrong on our side. Try again?'));
        }
      });
    };

    const asHost = (fn) => () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot do that.');
      if (!context.member.isHost) return fail('Only the host can do that.');
      return fn(context);
    };

    // ── joining ────────────────────────────────────────────────────────────

    handle('bingo:create', ({ name, maxPlayers }) => {
      detach(socket);

      const seats = Number(maxPlayers) || PLAYER_LIMITS.DEFAULT;
      if (seats < PLAYER_LIMITS.MIN || seats > PLAYER_LIMITS.MAX) {
        return fail(`Player count must be ${PLAYER_LIMITS.MIN}–${PLAYER_LIMITS.MAX}.`);
      }

      const room = rooms.create({ maxPlayers: seats });
      bindRoom(room);
      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id };
    });

    handle('bingo:join', ({ code, name, spectate }) => {
      const room = rooms.get(code);
      const shown = String(code ?? '').trim().toUpperCase();
      if (!room) return fail(`No room called "${shown}" — double-check the code? 🤔`, 'NO_ROOM');

      const existing = room.findByName(String(name ?? '').trim());
      if (existing && !existing.connected) {
        room.reconnectPlayer(existing, socket.id);
        seat(socket, room, existing);
        return { ok: true, code: room.code, memberId: existing.id, resumed: true };
      }

      if (room.isFull || spectate) {
        const spectator = room.addSpectator(name, socket.id);
        seat(socket, room, spectator);
        return {
          ok: true,
          code: room.code,
          memberId: spectator.id,
          spectator: true,
          message: room.isFull ? 'That room is full — you joined as a spectator 👀' : undefined,
        };
      }

      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id, name: player.name };
    });

    handle('bingo:rejoin', ({ code, memberId }) => {
      const room = rooms.get(code);
      if (!room) return fail('That room has closed.', 'NO_ROOM');

      const member = room.getMember(memberId);
      if (!member) return fail('Your seat expired — rejoin with your name.', 'NO_SEAT');

      if (!member.isSpectator) room.reconnectPlayer(member, socket.id);
      seat(socket, room, member);
      return { ok: true, code: room.code, memberId: member.id, resumed: true };
    });

    handle('bingo:leave', () => {
      detach(socket);
      return { ok: true };
    });

    // ── lobby ──────────────────────────────────────────────────────────────

    handle('bingo:configure', (patch) => asHost(({ room }) => room.configure(patch))());
    handle('bingo:start', () => asHost(({ room }) => room.start())());

    /** Anyone may deal again once the round is over. */
    handle('bingo:rematch', () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.room.state === RoomState.PLAYING) return fail('The round is still going!');
      return context.room.rematch();
    });

    // ── playing ────────────────────────────────────────────────────────────

    handle('bingo:call', ({ number }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot call.');
      return context.room.callNumber(context.member.id, Number(number));
    });

    handle('bingo:mark', ({ index }) => {
      const context = contextFor(socket);
      if (!context || context.isSpectator) return fail('You are not playing.');
      return context.room.mark(context.member.id, Number(index));
    });

    handle('bingo:unmark', ({ index }) => {
      const context = contextFor(socket);
      if (!context || context.isSpectator) return fail('You are not playing.');
      return context.room.unmark(context.member.id, Number(index));
    });

    handle('bingo:claim', () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot claim.');
      return context.room.claimBingo(context.member.id);
    });

    // ── social ─────────────────────────────────────────────────────────────

    handle('bingo:chat', ({ text }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');

      const result = context.room.addChatMessage(context.member, text);
      if (!result.ok) return fail(result.message ?? 'That message did not send.');
      namespace.to(context.room.code).emit('bingo:chat', result.message);
      return { ok: true };
    });

    handle('bingo:react', ({ emoji }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (!REACTIONS.includes(emoji)) return fail('Unknown reaction.');
      if (!context.room.canReact(context.member)) return { ok: false, code: 'RATE_LIMIT' };

      namespace.to(context.room.code).emit('bingo:reaction', {
        emoji,
        playerId: context.member.id,
        name: context.member.name,
        color: context.member.color,
      });
      return { ok: true };
    });

    socket.on('disconnect', () => {
      const session = sessions.get(socket.id);
      sessions.delete(socket.id);
      if (!session) return;
      const room = rooms.get(session.code);
      if (room) room.handleDisconnect(session.memberId);
    });
  });

  return { namespace, rooms };
}
