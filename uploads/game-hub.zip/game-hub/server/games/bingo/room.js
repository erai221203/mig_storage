/**
 * A Bingo room: the rules of game.js plus the state and timers that make them
 * a live game.
 *
 * Every player's card holds all 25 numbers in their own arrangement, so there
 * is no hidden information to protect — but a card still belongs to one player,
 * which is the one place this game differs from Snake & Ladder: state goes out
 * per player rather than as a single room broadcast.
 */

import { BaseRoom, RoomState } from '../../shared/room-manager.js';
import { GAME_ID, PLAYER_LIMITS, TIMING } from './config.js';
import {
  canMark,
  findCompletedLines,
  generateCard,
  isValidNumber,
  isWinning,
  CELL_COUNT,
  LINES_TO_WIN,
} from './game.js';

export const Phase = {
  LOBBY: 'lobby',
  COUNTDOWN: 'countdown',
  TURN: 'turn',
  ENDED: 'ended',
};

export class BingoRoom extends BaseRoom {
  constructor({ maxPlayers = PLAYER_LIMITS.DEFAULT } = {}) {
    super({ gameId: GAME_ID, maxPlayers });

    this.phase = Phase.LOBBY;
    this.rules = { turnSeconds: TIMING.TURN_SECONDS_DEFAULT };

    this.called = [];
    this.calledSet = new Set();
    this.turnPlayerId = null;
    this.lastCallerId = null;
    this.winner = null;
    this.endReason = null;
    this.roundNumber = 0;
    this.turnDeadline = null;

    this._timers = new Set();
  }

  _later(fn, ms) {
    const timer = setTimeout(() => {
      this._timers.delete(timer);
      if (!this._destroyed) fn();
    }, ms);
    timer.unref?.();
    this._timers.add(timer);
    return timer;
  }

  _clearTimers() {
    for (const timer of this._timers) clearTimeout(timer);
    this._timers.clear();
  }

  onDestroy() {
    this._clearTimers();
  }

  // ── settings ─────────────────────────────────────────────────────────────

  configure(patch) {
    if (this.state !== RoomState.LOBBY) {
      return { ok: false, message: 'Settings can only change in the lobby.' };
    }

    if (patch.maxPlayers !== undefined) {
      const value = Number(patch.maxPlayers);
      if (!Number.isInteger(value) || value < PLAYER_LIMITS.MIN || value > PLAYER_LIMITS.MAX) {
        return { ok: false, message: `Player count must be ${PLAYER_LIMITS.MIN}–${PLAYER_LIMITS.MAX}.` };
      }
      if (value < this.players.length) {
        return { ok: false, message: `There are already ${this.players.length} players here.` };
      }
      this.maxPlayers = value;
    }

    if (patch.turnSeconds !== undefined) {
      const value = Number(patch.turnSeconds);
      if (!TIMING.TURN_SECONDS_OPTIONS.includes(value)) {
        return { ok: false, message: 'Pick one of the offered turn timers.' };
      }
      this.rules.turnSeconds = value;
    }

    this.scheduleUpdate();
    return { ok: true };
  }

  // ── membership hooks ─────────────────────────────────────────────────────

  onPlayerAdded(player) {
    if (this.state === RoomState.PLAYING) this._dealCard(player);
  }

  onPlayerRemoved(player) {
    if (this.state !== RoomState.PLAYING) return;
    if (this.turnPlayerId === player.id) this._advanceTurn();
    this._checkStillPlayable();
  }

  onPlayerDisconnected(player) {
    if (this.state !== RoomState.PLAYING) return;
    // Don't let the table wait on someone who has clearly gone.
    if (this.turnPlayerId === player.id) this._advanceTurn();
  }

  onPlayerReconnected(player) {
    if (this.state === RoomState.PLAYING && !this._turnIsValid()) {
      this.turnPlayerId = player.id;
      this._armTurnTimer();
    }
  }

  // ── turns ────────────────────────────────────────────────────────────────

  _turnIsValid() {
    const player = this.getPlayer(this.turnPlayerId);
    return Boolean(player && player.connected);
  }

  _advanceTurn(fromIndex = null) {
    const connected = this.connectedPlayers;
    if (connected.length === 0) {
      this.turnPlayerId = null;
      this.turnDeadline = null;
      return;
    }

    const start =
      fromIndex !== null ? fromIndex : this.players.findIndex((p) => p.id === this.turnPlayerId);

    for (let step = 1; step <= this.players.length; step++) {
      const candidate = this.players[(start + step + this.players.length) % this.players.length];
      if (candidate?.connected) {
        this.turnPlayerId = candidate.id;
        this._armTurnTimer();
        return;
      }
    }
    this.turnPlayerId = connected[0].id;
    this._armTurnTimer();
  }

  /** Auto-call for a caller who runs out of time, so a game never stalls. */
  _armTurnTimer() {
    this._clearTimers();
    this.turnDeadline = null;
    if (!this.rules.turnSeconds) return;

    this.turnDeadline = Date.now() + this.rules.turnSeconds * 1000;
    const holder = this.turnPlayerId;
    this._later(() => {
      if (this.state !== RoomState.PLAYING || this.turnPlayerId !== holder) return;
      const next = this._firstUncalled();
      if (next !== null) this.callNumber(holder, next, { auto: true });
    }, this.rules.turnSeconds * 1000);
  }

  _firstUncalled() {
    for (let n = 1; n <= CELL_COUNT; n++) if (!this.calledSet.has(n)) return n;
    return null;
  }

  // ── round flow ───────────────────────────────────────────────────────────

  _dealCard(player) {
    player.card = generateCard();
    player.marked = new Set(); // no free space in this variant
  }

  start() {
    if (this.state === RoomState.PLAYING) {
      return { ok: false, message: 'The game is already running.' };
    }
    if (this.connectedPlayers.length < PLAYER_LIMITS.MIN_TO_START) {
      return { ok: false, message: `You need at least ${PLAYER_LIMITS.MIN_TO_START} players to start.` };
    }

    this._clearTimers();
    this.called = [];
    this.calledSet = new Set();
    this.winner = null;
    this.endReason = null;
    this.lastCallerId = null;
    this.roundNumber += 1;
    this.state = RoomState.PLAYING;
    this.phase = Phase.COUNTDOWN;

    for (const player of this.players) this._dealCard(player);

    // Anyone at the table might open — pick at random so the host has no edge.
    const starters = this.connectedPlayers;
    this.turnPlayerId = starters[Math.floor(Math.random() * starters.length)].id;

    this.emitUpdateNow();

    this._later(() => {
      this.phase = Phase.TURN;
      this._armTurnTimer();
      this.emitUpdateNow();
    }, TIMING.START_DELAY_MS);

    return { ok: true };
  }

  /**
   * Call a number for the whole room. Only the player holding the turn may,
   * and only a number nobody has called yet. The caller's own card marks
   * itself — they clearly saw it.
   */
  callNumber(playerId, number, { auto = false } = {}) {
    if (this.state !== RoomState.PLAYING || this.phase !== Phase.TURN) {
      return { ok: false, message: 'The round is not running.' };
    }
    if (this.turnPlayerId !== playerId) {
      const holder = this.getPlayer(this.turnPlayerId);
      return {
        ok: false,
        message: holder ? `It's ${holder.name}'s turn to call.` : 'It is not your turn.',
      };
    }
    if (!isValidNumber(number)) {
      return { ok: false, message: `Pick a number between 1 and ${CELL_COUNT}.` };
    }
    if (this.calledSet.has(number)) {
      return { ok: false, message: `${number} has already been called!` };
    }

    const player = this.getPlayer(playerId);
    this.called.push(number);
    this.calledSet.add(number);
    this.lastCallerId = playerId;

    const index = player.card.indexOf(number);
    if (index !== -1) player.marked.add(index);

    this._advanceTurn();
    this.touch();

    this.events.emit('called', {
      number,
      auto,
      by: { id: player.id, name: player.name, color: player.color },
    });
    this.emitUpdateNow();

    // Every number is on every card, so once all 25 are out there is nothing
    // left to mark.
    if (this.called.length >= CELL_COUNT) this.endRound(null, 'exhausted');

    return { ok: true };
  }

  mark(playerId, index) {
    const player = this.getPlayer(playerId);
    if (!player || !player.card) return { ok: false };
    if (this.state !== RoomState.PLAYING) return { ok: false };
    if (!canMark(player.card, index, this.calledSet)) return { ok: false };

    player.marked.add(index);
    this.scheduleUpdate();
    return { ok: true };
  }

  unmark(playerId, index) {
    const player = this.getPlayer(playerId);
    if (!player || this.state !== RoomState.PLAYING) return { ok: false };
    if (!player.marked.delete(index)) return { ok: false };
    this.scheduleUpdate();
    return { ok: true };
  }

  lineCount(player) {
    if (!player.marked) return 0;
    return findCompletedLines(player.marked).length;
  }

  /**
   * Validate a BINGO! claim. Marks can only exist for numbers the server
   * actually called, so this transitively verifies the claim while still
   * requiring the player to have marked their card.
   */
  claimBingo(playerId) {
    const player = this.getPlayer(playerId);
    if (!player || !player.card) return { ok: false, message: 'You are not in this round.' };
    if (this.state === RoomState.ENDED) return { ok: false, message: 'This round is already over!' };
    if (this.state !== RoomState.PLAYING) return { ok: false, message: 'The round has not started.' };

    const lines = findCompletedLines(player.marked);
    if (!isWinning(lines.length)) {
      const short = LINES_TO_WIN - lines.length;
      return {
        ok: false,
        message:
          lines.length === 0
            ? 'Not yet! Keep playing 😄'
            : `${lines.length} of ${LINES_TO_WIN} lines — ${short} to go! 😄`,
      };
    }

    this.endRound({ id: player.id, name: player.name, color: player.color, lines }, 'bingo');
    return { ok: true, lines };
  }

  _checkStillPlayable() {
    if (this.state === RoomState.PLAYING && this.players.length < 2) {
      this.endRound(null, 'abandoned');
    }
  }

  endRound(winner, reason) {
    if (this.state === RoomState.ENDED) return { ok: true };
    this._clearTimers();
    this.state = RoomState.ENDED;
    this.phase = Phase.ENDED;
    this.winner = winner;
    this.endReason = reason;
    this.turnPlayerId = null;
    this.turnDeadline = null;
    this.events.emit('gameOver', { standings: this.standings(), winner, reason });
    this.emitUpdateNow();
    return { ok: true };
  }

  rematch() {
    this._clearTimers();
    this.state = RoomState.LOBBY;
    this.phase = Phase.LOBBY;
    this.called = [];
    this.calledSet = new Set();
    this.winner = null;
    this.endReason = null;
    this.turnPlayerId = null;
    this.turnDeadline = null;
    this.emitUpdateNow();
    return { ok: true };
  }

  /** Everyone ranked by lines, with the declared winner always first. */
  standings() {
    const ranked = [...this.players].sort((a, b) => {
      if (this.winner) {
        if (a.id === this.winner.id) return -1;
        if (b.id === this.winner.id) return 1;
      }
      const diff = this.lineCount(b) - this.lineCount(a);
      if (diff) return diff;
      return (b.marked?.size ?? 0) - (a.marked?.size ?? 0);
    });

    return ranked.map((player, index) => ({
      place: index + 1,
      id: player.id,
      name: player.name,
      initials: player.initials,
      color: player.color,
      lineCount: this.lineCount(player),
      markCount: player.marked?.size ?? 0,
      isWinner: this.winner?.id === player.id,
    }));
  }

  // ── serialization ────────────────────────────────────────────────────────

  publicState() {
    return {
      ...this.baseState(),
      phase: this.phase,
      rules: { ...this.rules },
      roundNumber: this.roundNumber,
      linesToWin: LINES_TO_WIN,
      cellCount: CELL_COUNT,
      called: this.called,
      lastCalled: this.called.length ? this.called[this.called.length - 1] : null,
      lastCallerId: this.lastCallerId,
      turnPlayerId: this.turnPlayerId,
      turnDeadline: this.turnDeadline,
      remaining: CELL_COUNT - this.called.length,
      winner: this.winner,
      endReason: this.endReason,
      standings: this.state === RoomState.ENDED ? this.standings() : null,
      scores: this.players.map((p) => ({
        id: p.id,
        lineCount: this.lineCount(p),
        markCount: p.marked?.size ?? 0,
      })),
    };
  }

  /** The one private thing in this game: your own card. */
  privateState(player) {
    return {
      id: player.id,
      card: player.card,
      marked: player.marked ? [...player.marked] : [],
      lineCount: this.lineCount(player),
    };
  }
}
