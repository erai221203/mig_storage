/**
 * The rules of the game. No networking, no state — just cards, lines and win
 * detection, so it's easy to reason about (and easy to test).
 *
 * This is the 1–25 grid variant of bingo, not the 75-ball hall version:
 *
 *   • Every player's card holds **all** the numbers 1–25, in their own random
 *     arrangement. Nobody has a number their opponents lack; the luck is
 *     entirely in the layout.
 *   • There is no free space and no ball machine. Players take turns calling
 *     a number that hasn't been called yet, and everyone marks it on their
 *     own card.
 *   • Each completed row, column or diagonal earns a letter of B-I-N-G-O.
 *     Five lines spells it, and wins.
 *
 * Card layout — a flat array of 25 cells in row-major order:
 *
 *   ┌────┬────┬────┬────┬────┐      index = row * 5 + col
 *   │  0 │  1 │  2 │  3 │  4 │
 *   │  5 │  6 │  7 │  8 │  9 │      every cell holds a number 1–25,
 *   │ 10 │ 11 │ 12 │ 13 │ 14 │      each appearing exactly once
 *   │ 15 │ 16 │ 17 │ 18 │ 19 │
 *   │ 20 │ 21 │ 22 │ 23 │ 24 │
 *   └────┴────┴────┴────┴────┘
 */

export const LETTERS = ['B', 'I', 'N', 'G', 'O'];
export const CARD_SIZE = 5;
export const CELL_COUNT = CARD_SIZE * CARD_SIZE; // 25
export const HIGHEST_NUMBER = CELL_COUNT; // numbers run 1–25

/**
 * Lines needed to win — one per letter of B-I-N-G-O.
 * Lower it for shorter rounds; there are 12 lines available in total.
 */
export const LINES_TO_WIN = 5;

/** In-place Fisher–Yates shuffle. */
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

/**
 * A card is simply 1–25 in a random order. Every player gets every number,
 * so a card can never be "better" than another — only differently arranged.
 */
export function generateCard() {
  return shuffle(Array.from({ length: CELL_COUNT }, (_, i) => i + 1));
}

/**
 * The colour slot a number uses, 0–4.
 *
 * Keyed off the number itself rather than its position, so a given number
 * looks the same everywhere it appears — on the called ball, in the history
 * strip, and on every player's card, wherever it happens to sit.
 */
export function colorIndexFor(number) {
  return (number - 1) % LETTERS.length;
}

/**
 * The 12 ways to complete a line: 5 rows, 5 columns, 2 diagonals.
 * Precomputed once — checking is then just a set lookup per cell.
 */
export const LINES = (() => {
  const lines = [];

  for (let row = 0; row < CARD_SIZE; row++) {
    lines.push({
      id: `row-${row}`,
      label: `Row ${row + 1}`,
      cells: Array.from({ length: CARD_SIZE }, (_, col) => row * CARD_SIZE + col),
    });
  }

  for (let col = 0; col < CARD_SIZE; col++) {
    lines.push({
      id: `col-${col}`,
      label: `Column ${col + 1}`,
      cells: Array.from({ length: CARD_SIZE }, (_, row) => row * CARD_SIZE + col),
    });
  }

  lines.push({ id: 'diag-0', label: 'Diagonal ↘', cells: [0, 6, 12, 18, 24] });
  lines.push({ id: 'diag-1', label: 'Diagonal ↗', cells: [4, 8, 12, 16, 20] });

  return lines;
})();

/**
 * Every line on which all five cells are marked.
 * `marked` is a Set of cell indices.
 */
export function findCompletedLines(marked) {
  return LINES.filter((line) => line.cells.every((index) => marked.has(index)));
}

/** The B-I-N-G-O letters earned so far, one per completed line. */
export function lettersEarned(lineCount) {
  return LETTERS.slice(0, Math.min(lineCount, LETTERS.length));
}

/** Whether this many completed lines is a win. */
export function isWinning(lineCount) {
  return lineCount >= LINES_TO_WIN;
}

/** Is this a real number on the board? */
export function isValidNumber(number) {
  return Number.isInteger(number) && number >= 1 && number <= HIGHEST_NUMBER;
}

/**
 * Whether a cell may legally be marked right now.
 * The gate that stops false marks: the number must actually have been called.
 */
export function canMark(card, index, calledSet) {
  if (!Number.isInteger(index) || index < 0 || index >= card.length) return false;
  return calledSet.has(card[index]);
}
