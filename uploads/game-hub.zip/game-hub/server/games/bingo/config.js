/**
 * Bingo configuration — every tunable rule in one place.
 *
 * The client fetches this via `/api/games/bingo/config`, so the grid it draws
 * and the win rule it shows can never disagree with what the server enforces.
 */

import { CELL_COUNT, HIGHEST_NUMBER, LINES_TO_WIN, LETTERS } from './game.js';

export const GAME_ID = 'bingo';

export const PLAYER_LIMITS = {
  MIN: 2,
  MAX: 8,
  DEFAULT: 3,
  /** Players take turns calling, so a round needs at least two. */
  MIN_TO_START: 2,
};

export const RULES = {
  /**
   * How the turn to call moves around the table:
   *   'rotate' — round the table in seat order (default)
   *   'winner' — whoever called last calls again (fast and chaotic)
   */
  TURN_ORDER: 'rotate',
  /** Lines needed to spell B-I-N-G-O and win. */
  LINES_TO_WIN,
};

export const TIMING = {
  /** Seconds a caller has before the turn passes on. 0 disables the timer. */
  TURN_SECONDS_OPTIONS: [0, 15, 30],
  TURN_SECONDS_DEFAULT: 30,
  /** A beat before the first turn so people can look at their card. */
  START_DELAY_MS: 1_500,
};

/** Allowed emoji reactions — a fixed set, so this can't relay arbitrary text. */
export const REACTIONS = ['👏', '😂', '🎉', '😮', '🤞'];

/** Everything the client needs to draw the game. */
export function clientConfig() {
  return {
    cellCount: CELL_COUNT,
    highestNumber: HIGHEST_NUMBER,
    letters: LETTERS,
    linesToWin: LINES_TO_WIN,
    limits: PLAYER_LIMITS,
    rules: RULES,
    timing: {
      turnSecondsOptions: TIMING.TURN_SECONDS_OPTIONS,
      turnSecondsDefault: TIMING.TURN_SECONDS_DEFAULT,
    },
    reactions: REACTIONS,
  };
}
