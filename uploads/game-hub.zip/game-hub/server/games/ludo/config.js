/**
 * Ludo configuration — every tunable rule in one place.
 * The client fetches this, so the board it draws matches the rules enforced.
 */

import {
  GRID,
  HOME_COLUMN_LENGTH,
  HOME_POSITION,
  SAFE_SQUARES,
  SEATS,
  TOKENS_PER_PLAYER,
  TRACK,
  TRACK_LENGTH,
} from './game.js';

export const GAME_ID = 'ludo';

export const PLAYER_LIMITS = {
  MIN: 2,
  MAX: 4,
  DEFAULT: 4,
  MIN_TO_START: 2,
};

export const RULES = {
  /** Rolling a 6 earns another go. */
  EXTRA_TURN_ON_SIX: true,
  /** Three sixes in a row forfeits the turn — stops one player hogging it. */
  MAX_CONSECUTIVE_SIXES: 3,
  /** Sending an opponent home earns another go. */
  EXTRA_TURN_ON_CAPTURE: true,
  /** Getting a token all the way home earns another go. */
  EXTRA_TURN_ON_HOME: true,
  /** How many of your four tokens must get home to win. */
  TOKENS_TO_WIN: TOKENS_PER_PLAYER,
};

export const TIMING = {
  /** Seconds to roll, then to choose a token. 0 disables the timer. */
  TURN_SECONDS_OPTIONS: [0, 15, 30],
  TURN_SECONDS_DEFAULT: 30,
  /** A beat before the first turn so people can find their colour. */
  START_DELAY_MS: 1_800,
  /** The die spins, lands and is held before any token moves. */
  DICE_REVEAL_MS: 1_250,
  /** Budget for the token walk itself. */
  MOVE_MS: 2_200,
};

export const REACTIONS = ['😂', '🎲', '😱', '😭', '🎉'];

export function clientConfig() {
  return {
    grid: GRID,
    track: TRACK,
    trackLength: TRACK_LENGTH,
    homeColumnLength: HOME_COLUMN_LENGTH,
    homePosition: HOME_POSITION,
    tokensPerPlayer: TOKENS_PER_PLAYER,
    safeSquares: [...SAFE_SQUARES],
    seats: SEATS,
    limits: PLAYER_LIMITS,
    rules: RULES,
    timing: {
      turnSecondsOptions: TIMING.TURN_SECONDS_OPTIONS,
      turnSecondsDefault: TIMING.TURN_SECONDS_DEFAULT,
      diceRevealMs: TIMING.DICE_REVEAL_MS,
      moveMs: TIMING.MOVE_MS,
    },
    reactions: REACTIONS,
  };
}
