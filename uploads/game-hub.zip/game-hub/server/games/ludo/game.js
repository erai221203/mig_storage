/**
 * Pure Ludo rules and board geometry — no networking, no state.
 *
 * The board
 * ---------
 * A 15×15 grid in the classic cross shape. Four yards sit in the corners; a
 * 56-square track runs round the outside of the cross; each colour has a
 * 6-square home column running into the centre.
 *
 *        ┌─────┬───┬─────┐
 *        │ RED │ ↑ │GREEN│      · the track runs clockwise
 *        ├─────┼───┼─────┤      · each colour enters at its own start square
 *        │  ←  │ ✦ │  →  │      · and peels off into its home column after
 *        ├─────┼───┼─────┤        one full lap
 *        │BLUE │ ↓ │YELL │
 *        └─────┴───┴─────┘
 *
 * A token's position is stored as one number:
 *
 *    -1        in the yard
 *    0 … 55    steps along the track, counted from that colour's own start
 *    56 … 61   its home column
 *    62        home
 *
 * Storing it relative to the colour's start is what makes the rules simple:
 * every colour's journey is identical, and only the mapping to a board square
 * differs.
 *
 * A note on the lap length: the perimeter of a cross on a 15×15 grid is 56
 * squares, not the 52 often quoted. Using 56 (14 per quadrant) keeps every
 * consecutive pair of track squares orthogonally adjacent, so tokens hop
 * square to square instead of cutting diagonally across a corner. The game is
 * unchanged — the lap is simply four squares longer. `validateBoard()` enforces
 * that adjacency at boot.
 */

export const GRID = 15;
export const TRACK_LENGTH = 56;
export const HOME_COLUMN_LENGTH = 6;
/** Exactly this many steps takes a token from its start square to home. */
export const HOME_POSITION = TRACK_LENGTH + HOME_COLUMN_LENGTH; // 62
export const TOKENS_PER_PLAYER = 4;
export const IN_YARD = -1;

/**
 * The 56 track squares as [row, col], clockwise from Red's start.
 * Built as four identical quadrants rather than typed out, so the shape is
 * verifiable by eye and the adjacency check below has something to prove.
 */
export const TRACK = (() => {
  const cells = [];
  const add = (row, col) => cells.push([row, col]);

  // ── quadrant 1: Red's start, up the left arm and over the top ──────────
  for (let col = 0; col <= 6; col++) add(6, col); //  0– 6  out along the arm
  for (let row = 5; row >= 0; row--) add(row, 6); //  7–12  up beside the top arm
  add(0, 7); //                                        13  over the tip

  // ── quadrant 2: Green ──────────────────────────────────────────────────
  for (let row = 0; row <= 6; row++) add(row, 8); // 14–20
  for (let col = 9; col <= 14; col++) add(6, col); // 21–26
  add(7, 14); //                                       27

  // ── quadrant 3: Yellow ─────────────────────────────────────────────────
  for (let col = 14; col >= 8; col--) add(8, col); // 28–34
  for (let row = 9; row <= 14; row++) add(row, 8); // 35–40
  add(14, 7); //                                       41

  // ── quadrant 4: Blue ───────────────────────────────────────────────────
  for (let row = 14; row >= 8; row--) add(row, 6); // 42–48
  for (let col = 5; col >= 0; col--) add(8, col); // 49–54
  add(7, 0); //                                        55  and back to Red

  return cells;
})();

/**
 * The four seats. `startIndex` is where that colour joins the track; the home
 * column and yard slots are laid out to match.
 */
export const SEATS = [
  {
    id: 'red',
    name: 'Red',
    color: '#e17f7f',
    emoji: '🔴',
    startIndex: 0,
    homeColumn: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5], [7, 6]],
    yard: [[1, 1], [1, 4], [4, 1], [4, 4]],
  },
  {
    id: 'green',
    name: 'Green',
    color: '#7cc08c',
    emoji: '🟢',
    startIndex: 14,
    homeColumn: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7], [6, 7]],
    yard: [[1, 10], [1, 13], [4, 10], [4, 13]],
  },
  {
    id: 'yellow',
    name: 'Yellow',
    color: '#dfc06a',
    emoji: '🟡',
    startIndex: 28,
    homeColumn: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9], [7, 8]],
    yard: [[10, 10], [10, 13], [13, 10], [13, 13]],
  },
  {
    id: 'blue',
    name: 'Blue',
    color: '#7fb2e5',
    emoji: '🔵',
    startIndex: 42,
    homeColumn: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7], [8, 7]],
    yard: [[10, 1], [10, 4], [13, 1], [13, 4]],
  },
];

/**
 * Squares where a token cannot be captured: the four start squares and a star
 * eight steps on from each.
 */
export const SAFE_SQUARES = new Set([0, 8, 14, 22, 28, 36, 42, 50]);

/** Where a token sits on the board, or null while it's in the yard. */
export function cellFor(seat, position, tokenIndex) {
  if (position === IN_YARD) return seat.yard[tokenIndex];
  if (position >= HOME_POSITION) return [7, 7]; // the centre
  if (position >= TRACK_LENGTH) return seat.homeColumn[position - TRACK_LENGTH];
  return TRACK[trackIndex(seat, position)];
}

/** The absolute track square a relative position maps to. */
export function trackIndex(seat, position) {
  return (seat.startIndex + position) % TRACK_LENGTH;
}

/** Is this relative position out on the shared track (and so capturable)? */
export function isOnTrack(position) {
  return position >= 0 && position < TRACK_LENGTH;
}

export function isSafeSquare(absoluteIndex) {
  return SAFE_SQUARES.has(absoluteIndex);
}

export function rollDie() {
  return 1 + Math.floor(Math.random() * 6);
}

/**
 * Where a token would end up, or null if the move is illegal.
 *
 * Two rules do the work here: a token only leaves the yard on a 6, and the
 * final square needs an exact roll — overshooting home is not allowed.
 */
export function destinationFor(position, die) {
  if (position === IN_YARD) return die === 6 ? 0 : null;
  if (position >= HOME_POSITION) return null; // already home

  const target = position + die;
  if (target > HOME_POSITION) return null; // would overshoot home
  return target;
}

/**
 * Every legal move for one player's tokens on this roll.
 * Returns `{ tokenIndex, from, to, captures }`, where `captures` lists the
 * opponents' tokens that would be sent back to their yard.
 */
export function legalMoves(seats, playerSeatId, tokens, die) {
  const seat = SEATS.find((s) => s.id === playerSeatId);
  const moves = [];

  tokens[playerSeatId].forEach((position, tokenIndex) => {
    const to = destinationFor(position, die);
    if (to === null) return;

    moves.push({
      tokenIndex,
      from: position,
      to,
      captures: capturesAt(seats, playerSeatId, to),
    });
  });

  return moves;
}

/**
 * Which opponent tokens are sitting on the square this move ends on.
 * Nothing is captured in a home column, or on a safe square.
 */
export function capturesAt(seats, moverSeatId, position) {
  if (!isOnTrack(position)) return [];

  const moverSeat = SEATS.find((s) => s.id === moverSeatId);
  const absolute = trackIndex(moverSeat, position);
  if (isSafeSquare(absolute)) return [];

  const captured = [];
  for (const [seatId, positions] of Object.entries(seats)) {
    if (seatId === moverSeatId) continue;
    const seat = SEATS.find((s) => s.id === seatId);

    positions.forEach((theirPosition, tokenIndex) => {
      if (!isOnTrack(theirPosition)) return;
      if (trackIndex(seat, theirPosition) === absolute) {
        captured.push({ seatId, tokenIndex });
      }
    });
  }
  return captured;
}

/** All four tokens home. */
export function hasWon(positions) {
  return positions.every((position) => position >= HOME_POSITION);
}

/** How far round a player is, for the leaderboard. */
export function progressOf(positions) {
  return positions.reduce((sum, position) => sum + Math.max(0, position), 0);
}

/** Tokens safely home, shown as a 0–4 score. */
export function homeCount(positions) {
  return positions.filter((position) => position >= HOME_POSITION).length;
}

/**
 * Sanity-check the geometry at boot rather than discovering a bad square
 * mid-game.
 */
export function validateBoard() {
  const problems = [];

  if (TRACK.length !== TRACK_LENGTH) {
    problems.push(`track has ${TRACK.length} squares, expected ${TRACK_LENGTH}`);
  }

  const seen = new Set();
  for (const [row, col] of TRACK) {
    const key = `${row},${col}`;
    if (seen.has(key)) problems.push(`track square ${key} appears twice`);
    if (row < 0 || row >= GRID || col < 0 || col >= GRID) {
      problems.push(`track square ${key} is off the grid`);
    }
    seen.add(key);
  }

  // Consecutive track squares must be orthogonally adjacent, including the
  // wrap from the last square back to the first.
  for (let i = 0; i < TRACK.length; i++) {
    const [r1, c1] = TRACK[i];
    const [r2, c2] = TRACK[(i + 1) % TRACK.length];
    if (Math.abs(r1 - r2) + Math.abs(c1 - c2) !== 1) {
      problems.push(`track squares ${i} and ${(i + 1) % TRACK.length} are not adjacent`);
    }
  }

  for (const seat of SEATS) {
    if (seat.homeColumn.length !== HOME_COLUMN_LENGTH) {
      problems.push(`${seat.id} home column has ${seat.homeColumn.length} squares`);
    }
    if (seat.yard.length !== TOKENS_PER_PLAYER) {
      problems.push(`${seat.id} yard has ${seat.yard.length} slots`);
    }
    // The square before a colour's start is the last one it treads (index 51).
    const last = TRACK[(seat.startIndex + TRACK_LENGTH - 1) % TRACK_LENGTH];
    const firstHome = seat.homeColumn[0];
    if (Math.abs(last[0] - firstHome[0]) + Math.abs(last[1] - firstHome[1]) !== 1) {
      problems.push(`${seat.id}'s home column does not join its track exit`);
    }
  }

  if (problems.length) {
    throw new Error(`Invalid Ludo board:\n  - ${problems.join('\n  - ')}`);
  }
  return true;
}
