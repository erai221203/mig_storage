/**
 * A Ludo room.
 *
 * A turn has two beats: roll, then choose which token to move. The server owns
 * both — it generates the die and computes the legal moves, so the client can
 * only pick from a list the server already sanctioned.
 *
 * Nothing is private (all token positions are public), so state goes out as a
 * single room broadcast.
 */

import { BaseRoom, RoomState } from '../../shared/room-manager.js';
import { GAME_ID, PLAYER_LIMITS, RULES, TIMING } from './config.js';
import {
  HOME_POSITION,
  IN_YARD,
  SEATS,
  TOKENS_PER_PLAYER,
  hasWon,
  homeCount,
  legalMoves,
  progressOf,
  rollDie,
  trackIndex,
} from './game.js';

export const Phase = {
  LOBBY: 'lobby',
  COUNTDOWN: 'countdown',
  ROLL: 'roll', // waiting for the player to roll
  CHOOSE: 'choose', // rolled; waiting for them to pick a token
  MOVING: 'moving', // the move is animating on every client
  ENDED: 'ended',
};

export class LudoRoom extends BaseRoom {
  constructor({ maxPlayers = PLAYER_LIMITS.DEFAULT } = {}) {
    super({ gameId: GAME_ID, maxPlayers: Math.min(maxPlayers, PLAYER_LIMITS.MAX) });

    this.phase = Phase.LOBBY;
    this.rules = { turnSeconds: TIMING.TURN_SECONDS_DEFAULT };

    /** playerId → seat id ('red' | 'green' | 'yellow' | 'blue'). */
    this.seatOf = {};
    /** seatId → four token positions. */
    this.tokens = {};
    /** Seat order for turn rotation. */
    this.order = [];

    this.turnPlayerId = null;
    this.turnDeadline = null;
    this.die = null;
    this.moves = [];
    this.consecutiveSixes = 0;
    this.lastMove = null;
    this.finished = []; // playerIds in finishing order
    this.roundNumber = 0;

    this._timers = new Set();
  }

  _later(fn, ms) {
    const timer = setTimeout(() => {
      this._timers.delete(timer);
      if (!this._destroyed) fn();
    }, ms);
    timer.unref?.();
    this._timers.add(timer);
    return timer;
  }

  _clearTimers() {
    for (const timer of this._timers) clearTimeout(timer);
    this._timers.clear();
  }

  onDestroy() {
    this._clearTimers();
  }

  // ── settings ─────────────────────────────────────────────────────────────

  configure(patch) {
    if (this.state !== RoomState.LOBBY) {
      return { ok: false, message: 'Settings can only change in the lobby.' };
    }
    if (patch.maxPlayers !== undefined) {
      const value = Number(patch.maxPlayers);
      if (!Number.isInteger(value) || value < PLAYER_LIMITS.MIN || value > PLAYER_LIMITS.MAX) {
        return { ok: false, message: `Ludo takes ${PLAYER_LIMITS.MIN}–${PLAYER_LIMITS.MAX} players.` };
      }
      if (value < this.players.length) {
        return { ok: false, message: `There are already ${this.players.length} players here.` };
      }
      this.maxPlayers = value;
    }
    if (patch.turnSeconds !== undefined) {
      const value = Number(patch.turnSeconds);
      if (!TIMING.TURN_SECONDS_OPTIONS.includes(value)) {
        return { ok: false, message: 'Pick one of the offered turn timers.' };
      }
      this.rules.turnSeconds = value;
    }
    this.scheduleUpdate();
    return { ok: true };
  }

  // ── membership ───────────────────────────────────────────────────────────

  onPlayerRemoved(player) {
    delete this.seatOf[player.id];
    this.order = this.order.filter((id) => id !== player.id);

    if (this.state !== RoomState.PLAYING) return;
    if (this.turnPlayerId === player.id) this._nextTurn();
    // With one player left there is nobody to race.
    if (this.order.length < 2) this.endGame('everyone else left');
  }

  onPlayerDisconnected(player) {
    // Their clock keeps running; the auto-play covers them if they don't return.
    if (this.state === RoomState.PLAYING && this.turnPlayerId === player.id) this._armTurnTimer();
  }

  // ── starting ─────────────────────────────────────────────────────────────

  start() {
    if (this.state === RoomState.PLAYING) return { ok: false, message: 'Already playing.' };
    if (this.connectedPlayers.length < PLAYER_LIMITS.MIN_TO_START) {
      return { ok: false, message: `Ludo needs at least ${PLAYER_LIMITS.MIN_TO_START} players.` };
    }

    this._clearTimers();

    // Hand out colours in join order and seat everyone at the table.
    const seated = this.players.slice(0, PLAYER_LIMITS.MAX);
    this.seatOf = {};
    this.tokens = {};
    this.order = [];

    seated.forEach((player, index) => {
      const seat = SEATS[index];
      this.seatOf[player.id] = seat.id;
      this.tokens[seat.id] = new Array(TOKENS_PER_PLAYER).fill(IN_YARD);
      this.order.push(player.id);
    });

    this.state = RoomState.PLAYING;
    this.phase = Phase.COUNTDOWN;
    this.finished = [];
    this.roundNumber = 1;
    this.die = null;
    this.moves = [];
    this.lastMove = null;
    this.consecutiveSixes = 0;

    // A random player opens, so the host has no built-in advantage.
    this.turnPlayerId = this.order[Math.floor(Math.random() * this.order.length)];
    this.emitUpdateNow();

    this._later(() => {
      this.phase = Phase.ROLL;
      this._armTurnTimer();
      this.emitUpdateNow();
    }, TIMING.START_DELAY_MS);

    return { ok: true };
  }

  // ── turns ────────────────────────────────────────────────────────────────

  /**
   * Auto-play for whoever runs out of time, so the table never stalls: roll if
   * they haven't, otherwise take the most useful-looking move.
   */
  _armTurnTimer() {
    this._clearTimers();
    this.turnDeadline = null;
    if (!this.rules.turnSeconds) return;

    this.turnDeadline = Date.now() + this.rules.turnSeconds * 1000;
    const holder = this.turnPlayerId;
    const phase = this.phase;

    this._later(() => {
      if (this.state !== RoomState.PLAYING) return;
      if (this.turnPlayerId !== holder || this.phase !== phase) return;

      if (this.phase === Phase.ROLL) this.roll(holder, { auto: true });
      else if (this.phase === Phase.CHOOSE) {
        const best = this._bestMove(this.moves);
        if (best) this.moveToken(holder, best.tokenIndex, { auto: true });
      }
    }, this.rules.turnSeconds * 1000);
  }

  /** A reasonable pick for auto-play: capture, then get home, then leave the yard. */
  _bestMove(moves) {
    if (!moves.length) return null;
    return (
      moves.find((m) => m.captures.length > 0) ??
      moves.find((m) => m.to === HOME_POSITION) ??
      moves.find((m) => m.from === IN_YARD) ??
      moves.reduce((a, b) => (b.to > a.to ? b : a))
    );
  }

  _nextTurn() {
    if (this.state !== RoomState.PLAYING) return;

    this.die = null;
    this.moves = [];
    this.consecutiveSixes = 0;

    const active = this.order.filter((id) => !this.finished.includes(id));
    if (active.length <= 1) {
      this.endGame('everyone home');
      return;
    }

    const current = this.order.indexOf(this.turnPlayerId);
    for (let step = 1; step <= this.order.length; step++) {
      const candidate = this.order[(current + step + this.order.length) % this.order.length];
      if (!this.finished.includes(candidate)) {
        this.turnPlayerId = candidate;
        this.phase = Phase.ROLL;
        this.roundNumber += 1;
        this._armTurnTimer();
        this.emitUpdateNow();
        return;
      }
    }
    this.endGame('everyone home');
  }

  /** Same player goes again — after a 6, a capture, or getting a token home. */
  _sameTurnAgain() {
    this.die = null;
    this.moves = [];
    this.phase = Phase.ROLL;
    this._armTurnTimer();
    this.emitUpdateNow();
  }

  // ── rolling ──────────────────────────────────────────────────────────────

  roll(playerId, { auto = false } = {}) {
    if (this.state !== RoomState.PLAYING || this.phase !== Phase.ROLL) {
      return { ok: false, message: 'Not time to roll.' };
    }
    if (this.turnPlayerId !== playerId) {
      const holder = this.getPlayer(this.turnPlayerId);
      return { ok: false, message: holder ? `It's ${holder.name}'s turn.` : 'Not your turn.' };
    }

    this._clearTimers();
    const die = rollDie();
    this.die = die;

    if (die === 6) this.consecutiveSixes += 1;
    else this.consecutiveSixes = 0;

    const seatId = this.seatOf[playerId];
    this.moves = legalMoves(this.tokens, seatId, this.tokens, die);

    this.events.emit('rolled', { playerId, die, auto, moves: this.moves });

    // Three sixes running and the turn is forfeited.
    if (die === 6 && this.consecutiveSixes >= RULES.MAX_CONSECUTIVE_SIXES) {
      this.phase = Phase.MOVING;
      this.emitUpdateNow();
      this.events.emit('forfeit', { playerId, reason: 'three sixes' });
      this._later(() => this._nextTurn(), TIMING.DICE_REVEAL_MS + 600);
      return { ok: true, forfeited: true };
    }

    // Nothing playable — show the roll, then move on.
    if (this.moves.length === 0) {
      this.phase = Phase.MOVING;
      this.emitUpdateNow();
      this._later(() => {
        if (die === 6 && RULES.EXTRA_TURN_ON_SIX) this._sameTurnAgain();
        else this._nextTurn();
      }, TIMING.DICE_REVEAL_MS + 500);
      return { ok: true, noMoves: true };
    }

    // Exactly one option: play it rather than asking a pointless question.
    if (this.moves.length === 1) {
      this.phase = Phase.CHOOSE;
      this.emitUpdateNow();
      this._later(() => {
        if (this.phase === Phase.CHOOSE && this.turnPlayerId === playerId) {
          this.moveToken(playerId, this.moves[0].tokenIndex, { forced: true });
        }
      }, TIMING.DICE_REVEAL_MS + 350);
      return { ok: true, forced: true };
    }

    this.phase = Phase.CHOOSE;
    this._armTurnTimer();
    this.emitUpdateNow();
    return { ok: true };
  }

  // ── moving ───────────────────────────────────────────────────────────────

  moveToken(playerId, tokenIndex, { auto = false, forced = false } = {}) {
    if (this.state !== RoomState.PLAYING || this.phase !== Phase.CHOOSE) {
      return { ok: false, message: 'Not time to move.' };
    }
    if (this.turnPlayerId !== playerId) return { ok: false, message: 'Not your turn.' };

    const move = this.moves.find((m) => m.tokenIndex === Number(tokenIndex));
    if (!move) return { ok: false, message: 'That token cannot move on this roll.' };

    this._clearTimers();
    const seatId = this.seatOf[playerId];

    // Apply the move, then send any captured tokens back to their yard.
    this.tokens[seatId][move.tokenIndex] = move.to;
    for (const capture of move.captures) {
      this.tokens[capture.seatId][capture.tokenIndex] = IN_YARD;
    }

    const reachedHome = move.to >= HOME_POSITION;
    this.lastMove = {
      playerId,
      seatId,
      tokenIndex: move.tokenIndex,
      from: move.from,
      to: move.to,
      die: this.die,
      captures: move.captures,
      reachedHome,
      auto,
      forced,
    };

    this.phase = Phase.MOVING;
    this.events.emit('moved', this.lastMove);
    this.emitUpdateNow();

    // Did that finish them?
    if (hasWon(this.tokens[seatId]) && !this.finished.includes(playerId)) {
      this.finished.push(playerId);
      this.events.emit('playerHome', { playerId, place: this.finished.length });
    }

    const extra =
      (this.die === 6 && RULES.EXTRA_TURN_ON_SIX) ||
      (move.captures.length > 0 && RULES.EXTRA_TURN_ON_CAPTURE) ||
      (reachedHome && RULES.EXTRA_TURN_ON_HOME);

    const settle = TIMING.DICE_REVEAL_MS + TIMING.MOVE_MS;
    this._later(() => {
      if (this.state !== RoomState.PLAYING) return;

      const stillRacing = this.order.filter((id) => !this.finished.includes(id));
      if (stillRacing.length <= 1) {
        this.endGame('everyone home');
        return;
      }
      if (extra && !this.finished.includes(playerId)) this._sameTurnAgain();
      else this._nextTurn();
    }, settle);

    return { ok: true };
  }

  // ── ending ───────────────────────────────────────────────────────────────

  endGame(reason = 'ended') {
    if (this.state === RoomState.ENDED) return { ok: true };
    this._clearTimers();

    // Anyone not home is ranked by how far they got.
    const remaining = this.order
      .filter((id) => !this.finished.includes(id))
      .sort((a, b) => progressOf(this.tokens[this.seatOf[b]]) - progressOf(this.tokens[this.seatOf[a]]));
    this.finished.push(...remaining);

    this.state = RoomState.ENDED;
    this.phase = Phase.ENDED;
    this.turnPlayerId = null;
    this.turnDeadline = null;
    this.die = null;
    this.moves = [];

    this.events.emit('gameOver', { standings: this.standings(), reason });
    this.emitUpdateNow();
    return { ok: true };
  }

  rematch() {
    this._clearTimers();
    this.state = RoomState.LOBBY;
    this.phase = Phase.LOBBY;
    this.tokens = {};
    this.seatOf = {};
    this.order = [];
    this.finished = [];
    this.die = null;
    this.moves = [];
    this.lastMove = null;
    this.turnPlayerId = null;
    this.turnDeadline = null;
    this.emitUpdateNow();
    return { ok: true };
  }

  standings() {
    return this.finished.map((playerId, index) => {
      const player = this.getPlayer(playerId);
      const seatId = this.seatOf[playerId];
      const positions = this.tokens[seatId] ?? [];
      return {
        place: index + 1,
        id: playerId,
        name: player?.name ?? 'Player',
        initials: player?.initials ?? '?',
        color: SEATS.find((s) => s.id === seatId)?.color ?? player?.color,
        seatId,
        home: homeCount(positions),
        progress: progressOf(positions),
      };
    });
  }

  // ── serialization ────────────────────────────────────────────────────────

  publicState() {
    return {
      ...this.baseState(),
      phase: this.phase,
      rules: { ...this.rules },
      roundNumber: this.roundNumber,
      seatOf: { ...this.seatOf },
      tokens: Object.fromEntries(Object.entries(this.tokens).map(([k, v]) => [k, [...v]])),
      order: [...this.order],
      turnPlayerId: this.turnPlayerId,
      turnDeadline: this.turnDeadline,
      die: this.die,
      /** Only the moves the server has already sanctioned. */
      moves: this.moves.map((m) => ({
        tokenIndex: m.tokenIndex,
        from: m.from,
        to: m.to,
        captures: m.captures.length,
      })),
      lastMove: this.lastMove,
      consecutiveSixes: this.consecutiveSixes,
      finished: [...this.finished],
      scores: this.order.map((playerId) => {
        const seatId = this.seatOf[playerId];
        return {
          id: playerId,
          seatId,
          home: homeCount(this.tokens[seatId] ?? []),
          progress: progressOf(this.tokens[seatId] ?? []),
        };
      }),
      standings: this.state === RoomState.ENDED ? this.standings() : null,
    };
  }
}
