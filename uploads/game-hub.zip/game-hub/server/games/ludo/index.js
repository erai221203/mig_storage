/**
 * Ludo network layer, on its own Socket.IO namespace (`/ludo`).
 * Events are prefixed `ludo:`.
 */

import { RoomStore, RoomState } from '../../shared/room-manager.js';
import { GAME_ID, PLAYER_LIMITS, REACTIONS } from './config.js';
import { validateBoard } from './game.js';
import { LudoRoom } from './room.js';

export const gameId = GAME_ID;
export const rooms = new RoomStore((options) => new LudoRoom(options));

export function register(io) {
  validateBoard(); // fail loudly on a bad board rather than mid-game

  const namespace = io.of(`/${GAME_ID}`);
  const sessions = new Map();
  const fail = (message, code = 'ERROR') => ({ ok: false, code, message });

  /** Every position is public, so one broadcast serves the room. */
  const broadcast = (room) => namespace.to(room.code).emit('ludo:state', room.publicState());

  function bindRoom(room) {
    room.on('update', () => broadcast(room));
    room.on('rolled', (p) => namespace.to(room.code).emit('ludo:rolled', p));
    room.on('moved', (p) => namespace.to(room.code).emit('ludo:moved', p));
    room.on('forfeit', (p) => namespace.to(room.code).emit('ludo:forfeit', p));
    room.on('playerHome', (p) => namespace.to(room.code).emit('ludo:playerHome', p));
    room.on('gameOver', (p) => namespace.to(room.code).emit('ludo:gameOver', p));
  }

  function contextFor(socket) {
    const session = sessions.get(socket.id);
    if (!session) return null;
    const room = rooms.get(session.code);
    if (!room) return null;
    const member = room.getMember(session.memberId);
    if (!member) return null;
    return { room, member, isSpectator: Boolean(member.isSpectator) };
  }

  function seat(socket, room, member) {
    member.socketId = socket.id;
    member.connected = true;
    sessions.set(socket.id, { code: room.code, memberId: member.id });
    socket.join(room.code);
    socket.emit('ludo:welcome', {
      code: room.code,
      memberId: member.id,
      isSpectator: Boolean(member.isSpectator),
      state: room.publicState(),
      chat: room.chat,
    });
    broadcast(room);
  }

  function detach(socket) {
    const context = contextFor(socket);
    sessions.delete(socket.id);
    if (!context) return;
    const { room, member } = context;
    room.removePlayer(member.id);
    socket.leave(room.code);
    if (room.players.length === 0 && room.spectators.length === 0) rooms.delete(room.code);
    else broadcast(room);
  }

  namespace.on('connection', (socket) => {
    const handle = (event, fn) => {
      socket.on(event, async (payload, ack) => {
        const respond = typeof ack === 'function' ? ack : () => {};
        try {
          respond((await fn(payload ?? {})) ?? { ok: true });
        } catch (error) {
          console.error(`[ludo] ${event} failed:`, error);
          respond(fail('Something went wrong on our side. Try again?'));
        }
      });
    };

    const asHost = (fn) => () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot do that.');
      if (!context.member.isHost) return fail('Only the host can do that.');
      return fn(context);
    };

    handle('ludo:create', ({ name, maxPlayers }) => {
      detach(socket);
      const seats = Number(maxPlayers) || PLAYER_LIMITS.DEFAULT;
      if (seats < PLAYER_LIMITS.MIN || seats > PLAYER_LIMITS.MAX) {
        return fail(`Ludo takes ${PLAYER_LIMITS.MIN}–${PLAYER_LIMITS.MAX} players.`);
      }
      const room = rooms.create({ maxPlayers: seats });
      bindRoom(room);
      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id };
    });

    handle('ludo:join', ({ code, name, spectate }) => {
      const room = rooms.get(code);
      const shown = String(code ?? '').trim().toUpperCase();
      if (!room) return fail(`No room called "${shown}" — double-check the code? 🤔`, 'NO_ROOM');

      const existing = room.findByName(String(name ?? '').trim());
      if (existing && !existing.connected) {
        room.reconnectPlayer(existing, socket.id);
        seat(socket, room, existing);
        return { ok: true, code: room.code, memberId: existing.id, resumed: true };
      }

      if (room.isFull || spectate) {
        const spectator = room.addSpectator(name, socket.id);
        seat(socket, room, spectator);
        return {
          ok: true,
          code: room.code,
          memberId: spectator.id,
          spectator: true,
          message: room.isFull ? 'All four seats are taken — you joined as a spectator 👀' : undefined,
        };
      }

      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id, name: player.name };
    });

    handle('ludo:rejoin', ({ code, memberId }) => {
      const room = rooms.get(code);
      if (!room) return fail('That room has closed.', 'NO_ROOM');
      const member = room.getMember(memberId);
      if (!member) return fail('Your seat expired — rejoin with your name.', 'NO_SEAT');
      if (!member.isSpectator) room.reconnectPlayer(member, socket.id);
      seat(socket, room, member);
      return { ok: true, code: room.code, memberId: member.id, resumed: true };
    });

    handle('ludo:leave', () => {
      detach(socket);
      return { ok: true };
    });

    handle('ludo:configure', (patch) => asHost(({ room }) => room.configure(patch))());
    handle('ludo:start', () => asHost(({ room }) => room.start())());
    handle('ludo:endGame', () => asHost(({ room }) => room.endGame('host ended it'))());

    handle('ludo:rematch', () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.room.state === RoomState.PLAYING) return fail('The game is still going!');
      return context.room.rematch();
    });

    /** No die in the payload — the server rolls, so a client cannot cheat. */
    handle('ludo:roll', () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot roll.');
      return context.room.roll(context.member.id);
    });

    /** Only a token from the server's own list of legal moves is accepted. */
    handle('ludo:move', ({ tokenIndex }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot move.');
      return context.room.moveToken(context.member.id, Number(tokenIndex));
    });

    handle('ludo:chat', ({ text }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      const result = context.room.addChatMessage(context.member, text);
      if (!result.ok) return fail(result.message ?? 'That message did not send.');
      namespace.to(context.room.code).emit('ludo:chat', result.message);
      return { ok: true };
    });

    handle('ludo:react', ({ emoji }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (!REACTIONS.includes(emoji)) return fail('Unknown reaction.');
      if (!context.room.canReact(context.member)) return { ok: false, code: 'RATE_LIMIT' };
      namespace.to(context.room.code).emit('ludo:reaction', {
        emoji,
        playerId: context.member.id,
        name: context.member.name,
        color: context.member.color,
      });
      return { ok: true };
    });

    socket.on('disconnect', () => {
      const session = sessions.get(socket.id);
      sessions.delete(socket.id);
      if (!session) return;
      const room = rooms.get(session.code);
      if (room) room.handleDisconnect(session.memberId);
    });
  });

  return { namespace, rooms };
}
