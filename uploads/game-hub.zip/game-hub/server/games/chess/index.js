/**
 * Chess network layer, on its own Socket.IO namespace (`/chess`).
 * Events are prefixed `chess:`.
 *
 * The board is public, so state is one room broadcast — but each player also
 * gets their own legal-move list, which is both smaller and the only thing
 * their client is allowed to act on.
 */

import { RoomStore, RoomState } from '../../shared/room-manager.js';
import { GAME_ID, REACTIONS } from './config.js';
import { ChessRoom } from './room.js';

export const gameId = GAME_ID;
export const rooms = new RoomStore(() => new ChessRoom());

export function register(io) {
  const namespace = io.of(`/${GAME_ID}`);
  const sessions = new Map();
  const fail = (message, code = 'ERROR') => ({ ok: false, code, message });

  /** Shared position to everyone, plus each player's own move list. */
  function pushState(room) {
    const shared = room.publicState();
    for (const player of room.players) {
      if (!player.connected || !player.socketId) continue;
      namespace.to(player.socketId).emit('chess:state', {
        ...shared,
        yourMoves: room.privateMoves(player.id),
      });
    }
    for (const spectator of room.spectators) {
      if (spectator.socketId) {
        namespace.to(spectator.socketId).emit('chess:state', { ...shared, yourMoves: [] });
      }
    }
  }

  function bindRoom(room) {
    room.on('update', () => pushState(room));
    room.on('played', (p) => namespace.to(room.code).emit('chess:played', p));
    room.on('gameOver', (p) => namespace.to(room.code).emit('chess:gameOver', p));
  }

  function contextFor(socket) {
    const session = sessions.get(socket.id);
    if (!session) return null;
    const room = rooms.get(session.code);
    if (!room) return null;
    const member = room.getMember(session.memberId);
    if (!member) return null;
    return { room, member, isSpectator: Boolean(member.isSpectator) };
  }

  function seat(socket, room, member) {
    member.socketId = socket.id;
    member.connected = true;
    sessions.set(socket.id, { code: room.code, memberId: member.id });
    socket.join(room.code);
    socket.emit('chess:welcome', {
      code: room.code,
      memberId: member.id,
      isSpectator: Boolean(member.isSpectator),
      chat: room.chat,
    });
    pushState(room);
  }

  function detach(socket) {
    const context = contextFor(socket);
    sessions.delete(socket.id);
    if (!context) return;
    const { room, member } = context;
    room.removePlayer(member.id);
    socket.leave(room.code);
    if (room.players.length === 0 && room.spectators.length === 0) rooms.delete(room.code);
    else pushState(room);
  }

  namespace.on('connection', (socket) => {
    const handle = (event, fn) => {
      socket.on(event, async (payload, ack) => {
        const respond = typeof ack === 'function' ? ack : () => {};
        try {
          respond((await fn(payload ?? {})) ?? { ok: true });
        } catch (error) {
          console.error(`[chess] ${event} failed:`, error);
          respond(fail('Something went wrong on our side. Try again?'));
        }
      });
    };

    handle('chess:create', ({ name }) => {
      detach(socket);
      const room = rooms.create({});
      bindRoom(room);
      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id };
    });

    handle('chess:join', ({ code, name, spectate }) => {
      const room = rooms.get(code);
      const shown = String(code ?? '').trim().toUpperCase();
      if (!room) return fail(`No room called "${shown}" — double-check the code? 🤔`, 'NO_ROOM');

      const existing = room.findByName(String(name ?? '').trim());
      if (existing && !existing.connected) {
        room.reconnectPlayer(existing, socket.id);
        seat(socket, room, existing);
        return { ok: true, code: room.code, memberId: existing.id, resumed: true };
      }

      if (room.isFull || spectate) {
        const spectator = room.addSpectator(name, socket.id);
        seat(socket, room, spectator);
        return {
          ok: true,
          code: room.code,
          memberId: spectator.id,
          spectator: true,
          message: room.isFull ? 'Both seats are taken — you joined as a spectator 👀' : undefined,
        };
      }

      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id, name: player.name };
    });

    handle('chess:rejoin', ({ code, memberId }) => {
      const room = rooms.get(code);
      if (!room) return fail('That room has closed.', 'NO_ROOM');
      const member = room.getMember(memberId);
      if (!member) return fail('Your seat expired — rejoin with your name.', 'NO_SEAT');
      if (!member.isSpectator) room.reconnectPlayer(member, socket.id);
      seat(socket, room, member);
      return { ok: true, code: room.code, memberId: member.id, resumed: true };
    });

    handle('chess:leave', () => {
      detach(socket);
      return { ok: true };
    });

    const asHost = (fn) => () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot do that.');
      if (!context.member.isHost) return fail('Only the host can do that.');
      return fn(context);
    };

    handle('chess:configure', (patch) => asHost(({ room }) => room.configure(patch))());
    handle('chess:swap', () => asHost(({ room }) => room.swapColors())());
    handle('chess:start', () => asHost(({ room }) => room.start())());

    handle('chess:rematch', () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.room.state === RoomState.PLAYING) return fail('The game is still going!');
      return context.room.rematch();
    });

    /**
     * A move is just two squares (and a promotion choice). The server checks it
     * against its own legal-move list, so nothing else is trusted.
     */
    handle('chess:move', ({ from, to, promotion }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot move.');
      return context.room.play(context.member.id, Number(from), Number(to), promotion);
    });

    handle('chess:resign', () => {
      const context = contextFor(socket);
      if (!context || context.isSpectator) return fail('You are not playing.');
      return context.room.resign(context.member.id);
    });

    handle('chess:offerDraw', () => {
      const context = contextFor(socket);
      if (!context || context.isSpectator) return fail('You are not playing.');
      return context.room.offerDraw(context.member.id);
    });

    handle('chess:declineDraw', () => {
      const context = contextFor(socket);
      if (!context || context.isSpectator) return fail('You are not playing.');
      return context.room.declineDraw(context.member.id);
    });

    handle('chess:chat', ({ text }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      const result = context.room.addChatMessage(context.member, text);
      if (!result.ok) return fail(result.message ?? 'That message did not send.');
      namespace.to(context.room.code).emit('chess:chat', result.message);
      return { ok: true };
    });

    handle('chess:react', ({ emoji }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (!REACTIONS.includes(emoji)) return fail('Unknown reaction.');
      if (!context.room.canReact(context.member)) return { ok: false, code: 'RATE_LIMIT' };
      namespace.to(context.room.code).emit('chess:reaction', {
        emoji,
        playerId: context.member.id,
        name: context.member.name,
        color: context.member.color,
      });
      return { ok: true };
    });

    socket.on('disconnect', () => {
      const session = sessions.get(socket.id);
      sessions.delete(socket.id);
      if (!session) return;
      const room = rooms.get(session.code);
      if (room) room.handleDisconnect(session.memberId);
    });
  });

  return { namespace, rooms };
}
