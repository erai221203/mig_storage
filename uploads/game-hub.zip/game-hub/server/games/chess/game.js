/**
 * A complete chess rules engine — pure functions, no networking, no state.
 *
 * Board representation
 * --------------------
 * 64 squares in a flat array, `index = rank * 8 + file`, where rank 0 is the
 * TOP of the board (Black's back rank) and file 0 is the a-file. So index 0 is
 * a8 and index 63 is h1 — the order you'd read a diagram in.
 *
 * A square holds `null` or a two-character string: colour then piece, e.g.
 * 'wK' for the white king, 'bP' for a black pawn.
 *
 * Everything covered: sliding and stepping moves, pawn double-steps, captures,
 * en passant, promotion, both castles, check, checkmate, stalemate, the
 * fifty-move rule, insufficient material and threefold repetition.
 *
 * Move generation is verified against published perft node counts (see
 * `test/chess-perft.mjs`), which is the standard way to prove a chess engine's
 * move generator is exactly right rather than approximately right.
 */

export const WHITE = 'w';
export const BLACK = 'b';

const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

export const fileOf = (square) => square % 8;
export const rankOf = (square) => Math.floor(square / 8);
export const squareAt = (file, rank) => rank * 8 + file;
export const onBoard = (file, rank) => file >= 0 && file < 8 && rank >= 0 && rank < 8;

/** 'a8', 'e4' … — the name humans use. */
export function squareName(square) {
  return 'abcdefgh'[fileOf(square)] + (8 - rankOf(square));
}

export const colorOf = (piece) => (piece ? piece[0] : null);
export const typeOf = (piece) => (piece ? piece[1] : null);
export const opposite = (color) => (color === WHITE ? BLACK : WHITE);

/* ── Setting up ──────────────────────────────────────────────────────────── */

/** Parse a FEN string into a position. */
export function fromFEN(fen = START_FEN) {
  const [placement, turn, castling, enPassant, halfmove, fullmove] = fen.trim().split(/\s+/);

  const board = new Array(64).fill(null);
  let square = 0;
  for (const character of placement) {
    if (character === '/') continue;
    if (/\d/.test(character)) {
      square += Number(character);
      continue;
    }
    const color = character === character.toUpperCase() ? WHITE : BLACK;
    board[square] = color + character.toUpperCase();
    square += 1;
  }

  return {
    board,
    turn: turn === 'b' ? BLACK : WHITE,
    castling: {
      wK: castling.includes('K'),
      wQ: castling.includes('Q'),
      bK: castling.includes('k'),
      bQ: castling.includes('q'),
    },
    enPassant: enPassant && enPassant !== '-' ? nameToSquare(enPassant) : null,
    halfmove: Number(halfmove ?? 0),
    fullmove: Number(fullmove ?? 1),
  };
}

function nameToSquare(name) {
  const file = 'abcdefgh'.indexOf(name[0]);
  const rank = 8 - Number(name[1]);
  return squareAt(file, rank);
}

export function initialPosition() {
  return fromFEN(START_FEN);
}

/**
 * A compact key for the position, used to detect threefold repetition.
 * Deliberately excludes the move counters — repetition is about the position,
 * not how long it took to get there.
 */
export function positionKey(state) {
  const pieces = state.board.map((p) => p ?? '-').join('');
  const rights = `${state.castling.wK ? 'K' : ''}${state.castling.wQ ? 'Q' : ''}${
    state.castling.bK ? 'k' : ''}${state.castling.bQ ? 'q' : ''}` || '-';
  return `${pieces}|${state.turn}|${rights}|${state.enPassant ?? '-'}`;
}

/* ── Attack detection ────────────────────────────────────────────────────── */

const KNIGHT_STEPS = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];
const KING_STEPS = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]];
const ROOK_DIRS = [[0, 1], [0, -1], [1, 0], [-1, 0]];
const BISHOP_DIRS = [[1, 1], [1, -1], [-1, 1], [-1, -1]];

/**
 * Is `square` attacked by any piece of `byColor`?
 * Works outward from the square rather than looping every enemy piece, which
 * keeps it fast enough to call for every candidate move.
 */
export function isAttacked(board, square, byColor) {
  const file = fileOf(square);
  const rank = rankOf(square);

  // Pawns. White pawns capture toward rank 0, so a white attacker sits below.
  const pawnRank = byColor === WHITE ? rank + 1 : rank - 1;
  for (const df of [-1, 1]) {
    if (!onBoard(file + df, pawnRank)) continue;
    if (board[squareAt(file + df, pawnRank)] === byColor + 'P') return true;
  }

  for (const [df, dr] of KNIGHT_STEPS) {
    if (!onBoard(file + df, rank + dr)) continue;
    if (board[squareAt(file + df, rank + dr)] === byColor + 'N') return true;
  }

  for (const [df, dr] of KING_STEPS) {
    if (!onBoard(file + df, rank + dr)) continue;
    if (board[squareAt(file + df, rank + dr)] === byColor + 'K') return true;
  }

  const slide = (dirs, types) => {
    for (const [df, dr] of dirs) {
      let f = file + df;
      let r = rank + dr;
      while (onBoard(f, r)) {
        const piece = board[squareAt(f, r)];
        if (piece) {
          if (colorOf(piece) === byColor && types.includes(typeOf(piece))) return true;
          break; // a piece blocks the ray, friendly or not
        }
        f += df;
        r += dr;
      }
    }
    return false;
  };

  if (slide(ROOK_DIRS, ['R', 'Q'])) return true;
  if (slide(BISHOP_DIRS, ['B', 'Q'])) return true;
  return false;
}

export function findKing(board, color) {
  return board.indexOf(color + 'K');
}

export function inCheck(state, color = state.turn) {
  const king = findKing(state.board, color);
  if (king === -1) return false;
  return isAttacked(state.board, king, opposite(color));
}

/* ── Move generation ─────────────────────────────────────────────────────── */

/**
 * Moves for one piece, ignoring whether they leave the king in check.
 * `legalMoves` filters those out.
 */
export function pseudoMovesFrom(state, from) {
  const piece = state.board[from];
  if (!piece || colorOf(piece) !== state.turn) return [];

  const { board } = state;
  const color = colorOf(piece);
  const enemy = opposite(color);
  const file = fileOf(from);
  const rank = rankOf(from);
  const moves = [];

  const push = (to, extra = {}) => moves.push({ from, to, piece, ...extra });

  const stepper = (steps) => {
    for (const [df, dr] of steps) {
      const f = file + df;
      const r = rank + dr;
      if (!onBoard(f, r)) continue;
      const to = squareAt(f, r);
      const target = board[to];
      if (target && colorOf(target) === color) continue;
      push(to, target ? { captured: target } : {});
    }
  };

  const slider = (dirs) => {
    for (const [df, dr] of dirs) {
      let f = file + df;
      let r = rank + dr;
      while (onBoard(f, r)) {
        const to = squareAt(f, r);
        const target = board[to];
        if (target) {
          if (colorOf(target) !== color) push(to, { captured: target });
          break;
        }
        push(to);
        f += df;
        r += dr;
      }
    }
  };

  switch (typeOf(piece)) {
    case 'P': {
      const dr = color === WHITE ? -1 : 1;
      const startRank = color === WHITE ? 6 : 1;
      const promotionRank = color === WHITE ? 0 : 7;

      // One forward.
      const oneRank = rank + dr;
      if (onBoard(file, oneRank) && !board[squareAt(file, oneRank)]) {
        const to = squareAt(file, oneRank);
        if (oneRank === promotionRank) {
          for (const promotion of ['Q', 'R', 'B', 'N']) push(to, { promotion });
        } else {
          push(to);
          // Two forward, only from the starting rank and only if both are clear.
          const twoRank = rank + dr * 2;
          if (rank === startRank && !board[squareAt(file, twoRank)]) {
            push(squareAt(file, twoRank), { doubleStep: true });
          }
        }
      }

      // Captures, including en passant.
      for (const df of [-1, 1]) {
        if (!onBoard(file + df, oneRank)) continue;
        const to = squareAt(file + df, oneRank);
        const target = board[to];

        if (target && colorOf(target) === enemy) {
          if (oneRank === promotionRank) {
            for (const promotion of ['Q', 'R', 'B', 'N']) {
              push(to, { promotion, captured: target });
            }
          } else {
            push(to, { captured: target });
          }
        } else if (!target && to === state.enPassant) {
          // The captured pawn sits beside us, not on the destination square.
          const victim = squareAt(file + df, rank);
          push(to, { captured: board[victim], enPassant: true, victimSquare: victim });
        }
      }
      break;
    }

    case 'N':
      stepper(KNIGHT_STEPS);
      break;
    case 'B':
      slider(BISHOP_DIRS);
      break;
    case 'R':
      slider(ROOK_DIRS);
      break;
    case 'Q':
      slider([...ROOK_DIRS, ...BISHOP_DIRS]);
      break;

    case 'K': {
      stepper(KING_STEPS);

      // Castling: rights intact, squares empty, and the king may not start in,
      // pass through, or land on an attacked square.
      const homeRank = color === WHITE ? 7 : 0;
      if (rank === homeRank && file === 4 && !isAttacked(board, from, enemy)) {
        const rights = state.castling;

        const kingSide = color === WHITE ? rights.wK : rights.bK;
        if (kingSide
          && !board[squareAt(5, homeRank)]
          && !board[squareAt(6, homeRank)]
          && board[squareAt(7, homeRank)] === color + 'R'
          && !isAttacked(board, squareAt(5, homeRank), enemy)
          && !isAttacked(board, squareAt(6, homeRank), enemy)) {
          push(squareAt(6, homeRank), { castle: 'K' });
        }

        const queenSide = color === WHITE ? rights.wQ : rights.bQ;
        if (queenSide
          && !board[squareAt(3, homeRank)]
          && !board[squareAt(2, homeRank)]
          && !board[squareAt(1, homeRank)]
          && board[squareAt(0, homeRank)] === color + 'R'
          && !isAttacked(board, squareAt(3, homeRank), enemy)
          && !isAttacked(board, squareAt(2, homeRank), enemy)) {
          push(squareAt(2, homeRank), { castle: 'Q' });
        }
      }
      break;
    }

    default:
      break;
  }

  return moves;
}

/** Every move the side to move may legally play. */
export function legalMoves(state) {
  const moves = [];
  for (let square = 0; square < 64; square++) {
    const piece = state.board[square];
    if (!piece || colorOf(piece) !== state.turn) continue;

    for (const move of pseudoMovesFrom(state, square)) {
      const next = applyMove(state, move);
      // A move is only legal if it doesn't leave your own king attacked.
      if (!inCheck(next, state.turn)) moves.push(move);
    }
  }
  return moves;
}

export function movesFrom(state, from) {
  return legalMoves(state).filter((move) => move.from === from);
}

/* ── Making a move ───────────────────────────────────────────────────────── */

/** Apply a move and return the new position. The input is never mutated. */
export function applyMove(state, move) {
  const board = [...state.board];
  const piece = board[move.from];
  const color = colorOf(piece);
  const type = typeOf(piece);

  board[move.from] = null;

  // En passant removes a pawn that isn't on the destination square.
  if (move.enPassant) board[move.victimSquare] = null;

  board[move.to] = move.promotion ? color + move.promotion : piece;

  // Castling moves the rook too.
  if (move.castle) {
    const homeRank = color === WHITE ? 7 : 0;
    if (move.castle === 'K') {
      board[squareAt(5, homeRank)] = board[squareAt(7, homeRank)];
      board[squareAt(7, homeRank)] = null;
    } else {
      board[squareAt(3, homeRank)] = board[squareAt(0, homeRank)];
      board[squareAt(0, homeRank)] = null;
    }
  }

  const castling = { ...state.castling };
  // Moving your king or rook — or having your rook captured — costs the right.
  if (type === 'K') {
    if (color === WHITE) { castling.wK = false; castling.wQ = false; }
    else { castling.bK = false; castling.bQ = false; }
  }
  if (move.from === 63 || move.to === 63) castling.wK = false;
  if (move.from === 56 || move.to === 56) castling.wQ = false;
  if (move.from === 7 || move.to === 7) castling.bK = false;
  if (move.from === 0 || move.to === 0) castling.bQ = false;

  // A double step leaves an en-passant square behind it for one move only.
  const enPassant = move.doubleStep
    ? squareAt(fileOf(move.from), (rankOf(move.from) + rankOf(move.to)) / 2)
    : null;

  return {
    board,
    turn: opposite(color),
    castling,
    enPassant,
    // The fifty-move counter resets on a pawn move or a capture.
    halfmove: type === 'P' || move.captured ? 0 : state.halfmove + 1,
    fullmove: color === BLACK ? state.fullmove + 1 : state.fullmove,
  };
}

/* ── Game state ──────────────────────────────────────────────────────────── */

/** Neither side can possibly force mate. */
export function insufficientMaterial(board) {
  const pieces = board.filter(Boolean).map(typeOf);
  if (pieces.some((type) => type === 'P' || type === 'R' || type === 'Q')) return false;

  const minors = pieces.filter((type) => type === 'B' || type === 'N');
  if (minors.length <= 1) return true; // K v K, K+B v K, K+N v K

  // Two bishops on the same colour square can't mate either.
  if (minors.length === 2 && minors.every((type) => type === 'B')) {
    const bishops = board
      .map((piece, square) => ({ piece, square }))
      .filter(({ piece }) => piece && typeOf(piece) === 'B');
    if (bishops.length === 2) {
      const shade = (square) => (fileOf(square) + rankOf(square)) % 2;
      return shade(bishops[0].square) === shade(bishops[1].square);
    }
  }
  return false;
}

/**
 * How the game stands.
 * `history` is the list of position keys seen so far, for repetition.
 */
export function gameStatus(state, history = []) {
  const moves = legalMoves(state);
  const checked = inCheck(state);

  if (moves.length === 0) {
    return checked
      ? { over: true, result: opposite(state.turn), reason: 'checkmate' }
      : { over: true, result: 'draw', reason: 'stalemate' };
  }

  if (state.halfmove >= 100) {
    return { over: true, result: 'draw', reason: 'fifty-move rule' };
  }
  if (insufficientMaterial(state.board)) {
    return { over: true, result: 'draw', reason: 'insufficient material' };
  }

  const key = positionKey(state);
  const repeats = history.filter((entry) => entry === key).length;
  if (repeats >= 3) {
    return { over: true, result: 'draw', reason: 'threefold repetition' };
  }

  return { over: false, check: checked, moves: moves.length };
}

/* ── Notation ────────────────────────────────────────────────────────────── */

/**
 * Standard algebraic notation for a move, in the position it's played from.
 * Includes the disambiguation rules (Nbd2, R1e2) and the check/mate suffix.
 */
export function toSAN(state, move) {
  if (move.castle) {
    const suffix = suffixFor(state, move);
    return (move.castle === 'K' ? 'O-O' : 'O-O-O') + suffix;
  }

  const type = typeOf(move.piece);
  const target = squareName(move.to);
  let text = '';

  if (type === 'P') {
    text = move.captured ? `${'abcdefgh'[fileOf(move.from)]}x${target}` : target;
    if (move.promotion) text += `=${move.promotion}`;
  } else {
    // Disambiguate against any other same-type piece that could also go there.
    const rivals = legalMoves(state).filter(
      (other) =>
        other.to === move.to &&
        other.from !== move.from &&
        typeOf(other.piece) === type &&
        colorOf(other.piece) === colorOf(move.piece),
    );

    let hint = '';
    if (rivals.length) {
      const sameFile = rivals.some((other) => fileOf(other.from) === fileOf(move.from));
      const sameRank = rivals.some((other) => rankOf(other.from) === rankOf(move.from));
      if (!sameFile) hint = 'abcdefgh'[fileOf(move.from)];
      else if (!sameRank) hint = String(8 - rankOf(move.from));
      else hint = squareName(move.from);
    }

    text = `${type}${hint}${move.captured ? 'x' : ''}${target}`;
  }

  return text + suffixFor(state, move);
}

function suffixFor(state, move) {
  const next = applyMove(state, move);
  if (!inCheck(next)) return '';
  return legalMoves(next).length === 0 ? '#' : '+';
}

/* ── Perft ───────────────────────────────────────────────────────────────── */

/**
 * Count the leaf nodes at a given depth.
 * The standard correctness test for a move generator: the numbers are
 * published, so any disagreement is a bug in this file.
 */
export function perft(state, depth) {
  if (depth === 0) return 1;
  const moves = legalMoves(state);
  if (depth === 1) return moves.length;

  let nodes = 0;
  for (const move of moves) nodes += perft(applyMove(state, move), depth - 1);
  return nodes;
}
