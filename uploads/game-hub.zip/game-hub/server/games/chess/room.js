/**
 * A Chess room: two players, an optional clock, and a spectator gallery.
 *
 * The server holds the position and generates the legal moves. A client sends
 * only "from → to (and a promotion piece)"; anything not in the server's own
 * legal-move list is refused, so a modified client cannot play an illegal move.
 */

import { BaseRoom, RoomState } from '../../shared/room-manager.js';
import { GAME_ID, PLAYER_LIMITS, TIMING } from './config.js';
import {
  BLACK,
  WHITE,
  applyMove,
  colorOf,
  gameStatus,
  initialPosition,
  legalMoves,
  opposite,
  positionKey,
  squareName,
  toSAN,
  typeOf,
} from './game.js';

export const Phase = {
  LOBBY: 'lobby',
  PLAYING: 'playing',
  ENDED: 'ended',
};

export class ChessRoom extends BaseRoom {
  constructor() {
    // Always exactly two seats; extra arrivals become spectators.
    super({ gameId: GAME_ID, maxPlayers: PLAYER_LIMITS.MAX });

    this.phase = Phase.LOBBY;
    this.rules = { clockMinutes: TIMING.CLOCK_MINUTES_DEFAULT };

    this.position = initialPosition();
    this.history = []; // position keys, for repetition
    this.moves = []; // { san, from, to, color, fen? }
    this.colorOfPlayer = {}; // playerId → 'w' | 'b'
    this.captured = { w: [], b: [] };

    this.result = null; // 'w' | 'b' | 'draw'
    this.reason = null;
    this.lastMove = null;
    this.drawOfferedBy = null;

    this.clock = null; // { w: ms, b: ms, since: timestamp }
    this._tick = null;
  }

  onDestroy() {
    if (this._tick) clearInterval(this._tick);
  }

  // ── settings ─────────────────────────────────────────────────────────────

  configure(patch) {
    if (this.state !== RoomState.LOBBY) {
      return { ok: false, message: 'Settings can only change in the lobby.' };
    }
    if (patch.clockMinutes !== undefined) {
      const value = Number(patch.clockMinutes);
      if (!TIMING.CLOCK_MINUTES_OPTIONS.includes(value)) {
        return { ok: false, message: 'Pick one of the offered time controls.' };
      }
      this.rules.clockMinutes = value;
    }
    this.scheduleUpdate();
    return { ok: true };
  }

  /** Swap who plays white, before the game starts. */
  swapColors() {
    if (this.state !== RoomState.LOBBY) {
      return { ok: false, message: 'Colours are fixed once the game starts.' };
    }
    this.players.reverse();
    this.scheduleUpdate();
    return { ok: true };
  }

  onPlayerRemoved() {
    if (this.state === RoomState.PLAYING && this.players.length < 2) {
      this._finish(this.players[0] ? this.colorOfPlayer[this.players[0].id] : 'draw',
        'opponent left');
    }
  }

  // ── the game ─────────────────────────────────────────────────────────────

  start() {
    if (this.state === RoomState.PLAYING) return { ok: false, message: 'Already playing.' };
    if (this.connectedPlayers.length < PLAYER_LIMITS.MIN_TO_START) {
      return { ok: false, message: 'Chess needs two players.' };
    }

    this.position = initialPosition();
    this.history = [positionKey(this.position)];
    this.moves = [];
    this.captured = { w: [], b: [] };
    this.result = null;
    this.reason = null;
    this.lastMove = null;
    this.drawOfferedBy = null;

    // First seat plays white.
    const [first, second] = this.players;
    this.colorOfPlayer = { [first.id]: WHITE, [second.id]: BLACK };

    if (this.rules.clockMinutes > 0) {
      const ms = this.rules.clockMinutes * 60_000;
      this.clock = { w: ms, b: ms, since: Date.now() };
      this._startTicking();
    } else {
      this.clock = null;
    }

    this.state = RoomState.PLAYING;
    this.phase = Phase.PLAYING;
    this.emitUpdateNow();
    return { ok: true };
  }

  /** Charge the mover's clock for the time they just used. */
  _chargeClock() {
    if (!this.clock) return;
    const now = Date.now();
    const mover = this.position.turn;
    this.clock[mover] = Math.max(0, this.clock[mover] - (now - this.clock.since));
    this.clock.since = now;
  }

  _startTicking() {
    if (this._tick) clearInterval(this._tick);
    // A coarse tick is fine: the authoritative maths happens on each move.
    this._tick = setInterval(() => {
      if (this.state !== RoomState.PLAYING || !this.clock) return;
      const mover = this.position.turn;
      const left = this.clock[mover] - (Date.now() - this.clock.since);
      if (left <= 0) {
        this.clock[mover] = 0;
        this._finish(opposite(mover), 'time');
      }
    }, 1000);
    this._tick.unref?.();
  }

  /** The legal moves available to a player right now, for the client's hints. */
  legalMovesFor(playerId) {
    if (this.state !== RoomState.PLAYING) return [];
    if (this.colorOfPlayer[playerId] !== this.position.turn) return [];
    return legalMoves(this.position);
  }

  play(playerId, from, to, promotion) {
    if (this.state !== RoomState.PLAYING) return { ok: false, message: 'The game is not running.' };

    const color = this.colorOfPlayer[playerId];
    if (!color) return { ok: false, message: 'You are not playing this game.' };
    if (color !== this.position.turn) return { ok: false, message: 'It is not your move.' };

    // Only a move from the server's own list is ever accepted.
    const candidates = legalMoves(this.position).filter(
      (move) => move.from === from && move.to === to,
    );
    if (candidates.length === 0) return { ok: false, message: 'That move is not legal.' };

    const move = candidates.length === 1
      ? candidates[0]
      : candidates.find((m) => m.promotion === (promotion ?? 'Q'));
    if (!move) return { ok: false, message: 'Choose a piece to promote to.' };

    this._chargeClock();
    const san = toSAN(this.position, move);

    if (move.captured) {
      // Record it for the taken-pieces tray, from the capturing side's view.
      this.captured[color].push(move.captured);
    }

    this.position = applyMove(this.position, move);
    this.history.push(positionKey(this.position));
    this.drawOfferedBy = null;

    this.lastMove = {
      from,
      to,
      san,
      color,
      promotion: move.promotion ?? null,
      castle: move.castle ?? null,
      captured: move.captured ?? null,
      enPassant: Boolean(move.enPassant),
      fromName: squareName(from),
      toName: squareName(to),
    };
    this.moves.push({ san, color, number: Math.ceil(this.moves.length / 2) + 1 });

    // The increment is added after the move, as a Fischer clock does.
    if (this.clock) this.clock[color] += TIMING.INCREMENT_SECONDS * 1000;

    this.events.emit('played', this.lastMove);

    const status = gameStatus(this.position, this.history);
    if (status.over) {
      this._finish(status.result, status.reason);
    } else {
      this.emitUpdateNow();
    }
    return { ok: true, san };
  }

  resign(playerId) {
    if (this.state !== RoomState.PLAYING) return { ok: false, message: 'No game to resign.' };
    const color = this.colorOfPlayer[playerId];
    if (!color) return { ok: false, message: 'You are not playing.' };
    this._finish(opposite(color), 'resignation');
    return { ok: true };
  }

  offerDraw(playerId) {
    if (this.state !== RoomState.PLAYING) return { ok: false, message: 'No game in progress.' };
    const color = this.colorOfPlayer[playerId];
    if (!color) return { ok: false, message: 'You are not playing.' };

    // A second player offering while one is pending accepts it.
    if (this.drawOfferedBy && this.drawOfferedBy !== playerId) {
      this._finish('draw', 'agreement');
      return { ok: true, agreed: true };
    }
    this.drawOfferedBy = playerId;
    this.scheduleUpdate();
    return { ok: true };
  }

  declineDraw(playerId) {
    if (this.drawOfferedBy && this.drawOfferedBy !== playerId) {
      this.drawOfferedBy = null;
      this.scheduleUpdate();
    }
    return { ok: true };
  }

  _finish(result, reason) {
    if (this.state === RoomState.ENDED) return;
    if (this._tick) clearInterval(this._tick);
    this._tick = null;

    this.result = result;
    this.reason = reason;
    this.state = RoomState.ENDED;
    this.phase = Phase.ENDED;

    this.events.emit('gameOver', { result, reason, standings: this.standings() });
    this.emitUpdateNow();
  }

  rematch() {
    if (this._tick) clearInterval(this._tick);
    this._tick = null;
    this.state = RoomState.LOBBY;
    this.phase = Phase.LOBBY;
    this.position = initialPosition();
    this.moves = [];
    this.history = [];
    this.captured = { w: [], b: [] };
    this.result = null;
    this.reason = null;
    this.lastMove = null;
    this.clock = null;
    this.drawOfferedBy = null;
    // Swap colours so the same player doesn't always have white.
    this.players.reverse();
    this.emitUpdateNow();
    return { ok: true };
  }

  standings() {
    return this.players.map((player) => {
      const color = this.colorOfPlayer[player.id];
      const won = this.result === color;
      return {
        place: this.result === 'draw' ? 1 : won ? 1 : 2,
        id: player.id,
        name: player.name,
        initials: player.initials,
        color: player.color,
        side: color === WHITE ? 'White' : 'Black',
        isWinner: won,
      };
    }).sort((a, b) => a.place - b.place);
  }

  publicState() {
    const status = this.state === RoomState.PLAYING
      ? gameStatus(this.position, this.history)
      : { over: this.state === RoomState.ENDED, check: false };

    // Time remaining, with the mover's clock counted down live.
    let clock = null;
    if (this.clock) {
      const elapsed = this.state === RoomState.PLAYING ? Date.now() - this.clock.since : 0;
      clock = {
        w: Math.max(0, this.clock.w - (this.position.turn === WHITE ? elapsed : 0)),
        b: Math.max(0, this.clock.b - (this.position.turn === BLACK ? elapsed : 0)),
      };
    }

    return {
      ...this.baseState(),
      phase: this.phase,
      rules: { ...this.rules },
      board: [...this.position.board],
      turn: this.position.turn,
      colorOfPlayer: { ...this.colorOfPlayer },
      moves: this.moves.map((m) => m.san),
      lastMove: this.lastMove,
      captured: { w: [...this.captured.w], b: [...this.captured.b] },
      check: Boolean(status.check),
      result: this.result,
      reason: this.reason,
      drawOfferedBy: this.drawOfferedBy,
      clock,
      increment: TIMING.INCREMENT_SECONDS,
      standings: this.state === RoomState.ENDED ? this.standings() : null,
    };
  }

  /** The moves for one player, in the shape the client's hints want. */
  privateMoves(playerId) {
    return this.legalMovesFor(playerId).map((move) => ({
      from: move.from,
      to: move.to,
      promotion: move.promotion ?? null,
      captured: move.captured ? typeOf(move.captured) : null,
      castle: move.castle ?? null,
    }));
  }
}
