/** Chess configuration. Two players; everyone else watches. */

export const GAME_ID = 'chess';

export const PLAYER_LIMITS = {
  MIN: 2,
  MAX: 2,
  DEFAULT: 2,
  MIN_TO_START: 2,
};

export const TIMING = {
  /**
   * Minutes on each player's clock. 0 means no clock — the usual choice for a
   * casual game between coworkers.
   */
  CLOCK_MINUTES_OPTIONS: [0, 5, 10, 30],
  CLOCK_MINUTES_DEFAULT: 10,
  /** Seconds added after each move (Fischer increment). */
  INCREMENT_SECONDS: 5,
};

export const REACTIONS = ['🤔', '😱', '😂', '🎉', '🫡'];

export function clientConfig() {
  return {
    limits: PLAYER_LIMITS,
    timing: {
      clockMinutesOptions: TIMING.CLOCK_MINUTES_OPTIONS,
      clockMinutesDefault: TIMING.CLOCK_MINUTES_DEFAULT,
      incrementSeconds: TIMING.INCREMENT_SECONDS,
    },
    reactions: REACTIONS,
  };
}
