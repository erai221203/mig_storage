/**
 * Tic Tac Toe configuration.
 *
 * A single game is over in a minute, so the unit here is a *match*: first to
 * `WINS_NEEDED` games takes it, and who goes first alternates each game.
 */

export const GAME_ID = 'tic-tac-toe';

export const PLAYER_LIMITS = {
  MIN: 2,
  MAX: 2,
  DEFAULT: 2,
  MIN_TO_START: 2,
};

export const RULES = {
  /** Games needed to win the match — 3 makes it a best-of-five. */
  WINS_NEEDED: 3,
};

export const TIMING = {
  /** Seconds per move before it is played for you. 0 disables the timer. */
  TURN_SECONDS_OPTIONS: [0, 10, 20],
  TURN_SECONDS_DEFAULT: 20,
  /** A beat between games so the winning line can be seen. */
  NEXT_GAME_DELAY_MS: 2_400,
};

export const REACTIONS = ['😂', '😮', '🎉', '😭', '🤞'];

export function clientConfig() {
  return {
    cells: 9,
    limits: PLAYER_LIMITS,
    rules: RULES,
    timing: {
      turnSecondsOptions: TIMING.TURN_SECONDS_OPTIONS,
      turnSecondsDefault: TIMING.TURN_SECONDS_DEFAULT,
      nextGameDelayMs: TIMING.NEXT_GAME_DELAY_MS,
    },
    reactions: REACTIONS,
  };
}
