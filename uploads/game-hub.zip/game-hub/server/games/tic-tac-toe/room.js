/**
 * A Tic Tac Toe room: a best-of-five match between two players.
 *
 * Nothing here is private — both players see the whole board — so state goes
 * out as a single room broadcast.
 */

import { BaseRoom, RoomState } from '../../shared/room-manager.js';
import { GAME_ID, PLAYER_LIMITS, RULES, TIMING } from './config.js';
import { canPlay, emptyBoard, findWin, isFull, MARKS, suggestMove } from './game.js';

export const Phase = {
  LOBBY: 'lobby',
  TURN: 'turn',
  GAME_OVER: 'gameOver', // one game finished, next one coming
  ENDED: 'ended', // the whole match is done
};

export class TicTacToeRoom extends BaseRoom {
  constructor({ maxPlayers = PLAYER_LIMITS.MAX } = {}) {
    // Always exactly two seats; extra arrivals become spectators.
    super({ gameId: GAME_ID, maxPlayers: PLAYER_LIMITS.MAX });

    this.phase = Phase.LOBBY;
    this.rules = { turnSeconds: TIMING.TURN_SECONDS_DEFAULT, winsNeeded: RULES.WINS_NEEDED };

    this.board = emptyBoard();
    this.marks = {}; // playerId → 'X' | 'O'
    this.wins = {}; // playerId → games won
    this.draws = 0;
    this.gameNumber = 0;
    this.turnPlayerId = null;
    this.turnDeadline = null;
    this.lastWin = null; // { mark, line, playerId }
    this.matchWinner = null;
    /** Who starts — alternates each game so X isn't a permanent advantage. */
    this._startIndex = 0;

    this._timers = new Set();
  }

  _later(fn, ms) {
    const timer = setTimeout(() => {
      this._timers.delete(timer);
      if (!this._destroyed) fn();
    }, ms);
    timer.unref?.();
    this._timers.add(timer);
    return timer;
  }

  _clearTimers() {
    for (const timer of this._timers) clearTimeout(timer);
    this._timers.clear();
  }

  onDestroy() {
    this._clearTimers();
  }

  // ── settings ─────────────────────────────────────────────────────────────

  configure(patch) {
    if (this.state !== RoomState.LOBBY) {
      return { ok: false, message: 'Settings can only change in the lobby.' };
    }
    if (patch.turnSeconds !== undefined) {
      const value = Number(patch.turnSeconds);
      if (!TIMING.TURN_SECONDS_OPTIONS.includes(value)) {
        return { ok: false, message: 'Pick one of the offered move timers.' };
      }
      this.rules.turnSeconds = value;
    }
    if (patch.winsNeeded !== undefined) {
      const value = Number(patch.winsNeeded);
      if (![1, 2, 3, 4].includes(value)) {
        return { ok: false, message: 'Matches run to 1, 2, 3 or 4 wins.' };
      }
      this.rules.winsNeeded = value;
    }
    this.scheduleUpdate();
    return { ok: true };
  }

  // ── membership ───────────────────────────────────────────────────────────

  onPlayerRemoved() {
    if (this.state === RoomState.PLAYING && this.players.length < 2) {
      this._clearTimers();
      this.state = RoomState.ENDED;
      this.phase = Phase.ENDED;
      this.turnPlayerId = null;
      this.matchWinner = this.players[0]?.id ?? null;
      this.events.emit('matchOver', { standings: this.standings(), reason: 'opponent left' });
    }
  }

  onPlayerDisconnected(player) {
    // Their clock keeps running; the auto-move covers them if they don't return.
    if (this.state === RoomState.PLAYING && this.turnPlayerId === player.id) this._armTurnTimer();
  }

  // ── match flow ───────────────────────────────────────────────────────────

  start() {
    if (this.state === RoomState.PLAYING) return { ok: false, message: 'Already playing.' };
    if (this.connectedPlayers.length < PLAYER_LIMITS.MIN_TO_START) {
      return { ok: false, message: 'Tic Tac Toe needs two players.' };
    }

    this._clearTimers();
    this.state = RoomState.PLAYING;
    this.gameNumber = 0;
    this.draws = 0;
    this.matchWinner = null;
    this.wins = Object.fromEntries(this.players.map((p) => [p.id, 0]));
    // X and O are fixed for the match; who moves first alternates.
    this.marks = Object.fromEntries(this.players.slice(0, 2).map((p, i) => [p.id, MARKS[i]]));
    this._startIndex = 0;

    this._beginGame();
    return { ok: true };
  }

  _beginGame() {
    this.board = emptyBoard();
    this.lastWin = null;
    this.gameNumber += 1;
    this.phase = Phase.TURN;

    const seats = this.players.slice(0, 2);
    this.turnPlayerId = seats[this._startIndex % seats.length]?.id ?? seats[0]?.id ?? null;

    this._armTurnTimer();
    this.emitUpdateNow();
  }

  _armTurnTimer() {
    this._clearTimers();
    this.turnDeadline = null;
    if (!this.rules.turnSeconds) return;

    this.turnDeadline = Date.now() + this.rules.turnSeconds * 1000;
    const holder = this.turnPlayerId;
    this._later(() => {
      if (this.phase !== Phase.TURN || this.turnPlayerId !== holder) return;
      // Play a sensible move rather than a random one, so a timeout doesn't
      // hand the game away.
      const index = suggestMove(this.board, this.marks[holder]);
      if (index !== null) this.play(holder, index, { auto: true });
    }, this.rules.turnSeconds * 1000);
  }

  play(playerId, index, { auto = false } = {}) {
    if (this.state !== RoomState.PLAYING || this.phase !== Phase.TURN) {
      return { ok: false, message: 'The game is not running.' };
    }
    if (this.turnPlayerId !== playerId) {
      const holder = this.getPlayer(this.turnPlayerId);
      return { ok: false, message: holder ? `It's ${holder.name}'s turn.` : 'Not your turn.' };
    }
    if (!canPlay(this.board, index)) {
      return { ok: false, message: 'That square is taken.' };
    }

    const mark = this.marks[playerId];
    this.board[index] = mark;
    this._clearTimers();

    this.events.emit('played', { index, mark, playerId, auto });

    const win = findWin(this.board);
    if (win) {
      this.wins[playerId] = (this.wins[playerId] ?? 0) + 1;
      this.lastWin = { ...win, playerId };
      return this._finishGame();
    }
    if (isFull(this.board)) {
      this.draws += 1;
      this.lastWin = null;
      return this._finishGame();
    }

    // Hand over to the other seat.
    const seats = this.players.slice(0, 2);
    const other = seats.find((p) => p.id !== playerId);
    this.turnPlayerId = other?.id ?? playerId;
    this._armTurnTimer();
    this.emitUpdateNow();
    return { ok: true };
  }

  /** One game ended: either the match is over, or the next game starts. */
  _finishGame() {
    this.phase = Phase.GAME_OVER;
    this.turnPlayerId = null;
    this.turnDeadline = null;
    this._startIndex += 1; // the other player opens the next game

    const leader = Object.entries(this.wins).find(([, n]) => n >= this.rules.winsNeeded);
    this.events.emit('gameEnded', {
      win: this.lastWin,
      board: [...this.board],
      wins: { ...this.wins },
      draws: this.draws,
    });

    if (leader) {
      this.matchWinner = leader[0];
      this.state = RoomState.ENDED;
      this.phase = Phase.ENDED;
      this.events.emit('matchOver', { standings: this.standings(), reason: 'match won' });
      this.emitUpdateNow();
      return { ok: true };
    }

    this.emitUpdateNow();
    this._later(() => {
      if (this.state === RoomState.PLAYING) this._beginGame();
    }, TIMING.NEXT_GAME_DELAY_MS);
    return { ok: true };
  }

  rematch() {
    this._clearTimers();
    this.state = RoomState.LOBBY;
    this.phase = Phase.LOBBY;
    this.board = emptyBoard();
    this.lastWin = null;
    this.matchWinner = null;
    this.turnPlayerId = null;
    this.turnDeadline = null;
    this.gameNumber = 0;
    this.emitUpdateNow();
    return { ok: true };
  }

  standings() {
    return [...this.players]
      .sort((a, b) => (this.wins[b.id] ?? 0) - (this.wins[a.id] ?? 0))
      .map((player, index) => ({
        place: index + 1,
        id: player.id,
        name: player.name,
        initials: player.initials,
        color: player.color,
        mark: this.marks[player.id] ?? null,
        wins: this.wins[player.id] ?? 0,
        isWinner: this.matchWinner === player.id,
      }));
  }

  publicState() {
    return {
      ...this.baseState(),
      phase: this.phase,
      rules: { ...this.rules },
      board: [...this.board],
      marks: { ...this.marks },
      wins: { ...this.wins },
      draws: this.draws,
      gameNumber: this.gameNumber,
      turnPlayerId: this.turnPlayerId,
      turnDeadline: this.turnDeadline,
      lastWin: this.lastWin,
      matchWinner: this.matchWinner,
      standings: this.state === RoomState.ENDED ? this.standings() : null,
    };
  }
}
