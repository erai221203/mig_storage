/**
 * Pure Tic Tac Toe rules — no networking, no state.
 *
 * The board is a flat array of 9 cells in row-major order, each holding
 * 'X', 'O' or null:
 *
 *    0 | 1 | 2
 *    3 | 4 | 5
 *    6 | 7 | 8
 */

export const CELLS = 9;
export const MARKS = ['X', 'O'];

/** The eight ways to win: 3 rows, 3 columns, 2 diagonals. */
export const WIN_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
  [0, 4, 8], [2, 4, 6], // diagonals
];

export function emptyBoard() {
  return new Array(CELLS).fill(null);
}

/** The completed line, or null. Returns the mark and the cells that made it. */
export function findWin(board) {
  for (const line of WIN_LINES) {
    const [a, b, c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { mark: board[a], line };
    }
  }
  return null;
}

export function isFull(board) {
  return board.every((cell) => cell !== null);
}

export function canPlay(board, index) {
  return Number.isInteger(index) && index >= 0 && index < CELLS && board[index] === null;
}

/**
 * A decent move for the auto-play that covers a player who has run out of
 * time: win if you can, block if you must, otherwise take the centre, a
 * corner, or whatever is left. Keeps a timed-out turn from feeling random.
 */
export function suggestMove(board, mark) {
  const opponent = mark === 'X' ? 'O' : 'X';
  const free = board.map((cell, i) => (cell === null ? i : -1)).filter((i) => i >= 0);
  if (free.length === 0) return null;

  const completes = (who) => {
    for (const line of WIN_LINES) {
      const marks = line.map((i) => board[i]);
      const blanks = line.filter((i) => board[i] === null);
      if (blanks.length === 1 && marks.filter((m) => m === who).length === 2) return blanks[0];
    }
    return null;
  };

  return (
    completes(mark) ??
    completes(opponent) ??
    (board[4] === null ? 4 : null) ??
    [0, 2, 6, 8].find((i) => board[i] === null) ??
    free[0]
  );
}
