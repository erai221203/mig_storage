/**
 * Tic Tac Toe network layer, on its own Socket.IO namespace (`/tic-tac-toe`).
 * Events are prefixed `ttt:`.
 */

import { RoomStore, RoomState } from '../../shared/room-manager.js';
import { GAME_ID, REACTIONS } from './config.js';
import { TicTacToeRoom } from './room.js';

export const gameId = GAME_ID;
export const rooms = new RoomStore((options) => new TicTacToeRoom(options));

export function register(io) {
  const namespace = io.of(`/${GAME_ID}`);
  const sessions = new Map();
  const fail = (message, code = 'ERROR') => ({ ok: false, code, message });

  /** Nothing is private here, so one broadcast serves the whole room. */
  const broadcast = (room) => namespace.to(room.code).emit('ttt:state', room.publicState());

  function bindRoom(room) {
    room.on('update', () => broadcast(room));
    room.on('played', (p) => namespace.to(room.code).emit('ttt:played', p));
    room.on('gameEnded', (p) => namespace.to(room.code).emit('ttt:gameEnded', p));
    room.on('matchOver', (p) => namespace.to(room.code).emit('ttt:matchOver', p));
  }

  function contextFor(socket) {
    const session = sessions.get(socket.id);
    if (!session) return null;
    const room = rooms.get(session.code);
    if (!room) return null;
    const member = room.getMember(session.memberId);
    if (!member) return null;
    return { room, member, isSpectator: Boolean(member.isSpectator) };
  }

  function seat(socket, room, member) {
    member.socketId = socket.id;
    member.connected = true;
    sessions.set(socket.id, { code: room.code, memberId: member.id });
    socket.join(room.code);
    socket.emit('ttt:welcome', {
      code: room.code,
      memberId: member.id,
      isSpectator: Boolean(member.isSpectator),
      state: room.publicState(),
      chat: room.chat,
    });
    broadcast(room);
  }

  function detach(socket) {
    const context = contextFor(socket);
    sessions.delete(socket.id);
    if (!context) return;
    const { room, member } = context;
    room.removePlayer(member.id);
    socket.leave(room.code);
    if (room.players.length === 0 && room.spectators.length === 0) rooms.delete(room.code);
    else broadcast(room);
  }

  namespace.on('connection', (socket) => {
    const handle = (event, fn) => {
      socket.on(event, async (payload, ack) => {
        const respond = typeof ack === 'function' ? ack : () => {};
        try {
          respond((await fn(payload ?? {})) ?? { ok: true });
        } catch (error) {
          console.error(`[ttt] ${event} failed:`, error);
          respond(fail('Something went wrong on our side. Try again?'));
        }
      });
    };

    handle('ttt:create', ({ name }) => {
      detach(socket);
      const room = rooms.create({});
      bindRoom(room);
      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id };
    });

    handle('ttt:join', ({ code, name, spectate }) => {
      const room = rooms.get(code);
      const shown = String(code ?? '').trim().toUpperCase();
      if (!room) return fail(`No room called "${shown}" — double-check the code? 🤔`, 'NO_ROOM');

      const existing = room.findByName(String(name ?? '').trim());
      if (existing && !existing.connected) {
        room.reconnectPlayer(existing, socket.id);
        seat(socket, room, existing);
        return { ok: true, code: room.code, memberId: existing.id, resumed: true };
      }

      // Only two can play, so anyone else watches.
      if (room.isFull || spectate) {
        const spectator = room.addSpectator(name, socket.id);
        seat(socket, room, spectator);
        return {
          ok: true,
          code: room.code,
          memberId: spectator.id,
          spectator: true,
          message: room.isFull ? 'Both seats are taken — you joined as a spectator 👀' : undefined,
        };
      }

      const player = room.addPlayer(name, socket.id);
      seat(socket, room, player);
      return { ok: true, code: room.code, memberId: player.id, name: player.name };
    });

    handle('ttt:rejoin', ({ code, memberId }) => {
      const room = rooms.get(code);
      if (!room) return fail('That room has closed.', 'NO_ROOM');
      const member = room.getMember(memberId);
      if (!member) return fail('Your seat expired — rejoin with your name.', 'NO_SEAT');
      if (!member.isSpectator) room.reconnectPlayer(member, socket.id);
      seat(socket, room, member);
      return { ok: true, code: room.code, memberId: member.id, resumed: true };
    });

    handle('ttt:leave', () => {
      detach(socket);
      return { ok: true };
    });

    handle('ttt:configure', (patch) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (!context.member.isHost) return fail('Only the host can change the setup.');
      return context.room.configure(patch);
    });

    handle('ttt:start', () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (!context.member.isHost) return fail('Only the host can start the match.');
      return context.room.start();
    });

    handle('ttt:play', ({ index }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.isSpectator) return fail('Spectators cannot play.');
      return context.room.play(context.member.id, Number(index));
    });

    handle('ttt:rematch', () => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (context.room.state === RoomState.PLAYING) return fail('The match is still going!');
      return context.room.rematch();
    });

    handle('ttt:chat', ({ text }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      const result = context.room.addChatMessage(context.member, text);
      if (!result.ok) return fail(result.message ?? 'That message did not send.');
      namespace.to(context.room.code).emit('ttt:chat', result.message);
      return { ok: true };
    });

    handle('ttt:react', ({ emoji }) => {
      const context = contextFor(socket);
      if (!context) return fail('You are not in a room.');
      if (!REACTIONS.includes(emoji)) return fail('Unknown reaction.');
      if (!context.room.canReact(context.member)) return { ok: false, code: 'RATE_LIMIT' };
      namespace.to(context.room.code).emit('ttt:reaction', {
        emoji,
        playerId: context.member.id,
        name: context.member.name,
        color: context.member.color,
      });
      return { ok: true };
    });

    socket.on('disconnect', () => {
      const session = sessions.get(socket.id);
      sessions.delete(socket.id);
      if (!session) return;
      const room = rooms.get(session.code);
      if (room) room.handleDisconnect(session.memberId);
    });
  });

  return { namespace, rooms };
}
