/**
 * The hub's game catalogue — the single place a game is announced.
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  TO ADD A GAME TO THE HUB: add one entry to the GAMES array below.
 * ══════════════════════════════════════════════════════════════════════════
 *
 * The landing page cards, the `/api/games` endpoint, the setup screen and the
 * join-by-code routing are all generated from this list. A `status: 'coming-soon'`
 * entry renders as a placeholder card and needs no code at all.
 *
 * A playable entry additionally needs:
 *   1. `server/games/<id>/index.js` exporting `register(io)`  — see snake-and-ladder
 *   2. `client/games/<id>/<id>.js`  exporting `mount(context)`
 * See the "How to add a new game" section of the README for the full walkthrough.
 */

/**
 * `eventPrefix` namespaces a game's Socket.IO events (`snl:create`,
 * `bingo:create`). The setup screen uses it to create a room without knowing
 * anything else about the game.
 */
export const GAMES = [
  {
    id: 'snake-and-ladder',
    eventPrefix: 'snl',
    title: 'Snake & Ladder',
    tagline: 'Climb the ladders, dodge the snakes. Pure luck, zero stress.',
    icon: '🐍',
    minPlayers: 2,
    maxPlayers: 15,
    accent: '#6bbf8a',
    status: 'live',
  },
  {
    id: 'bingo',
    eventPrefix: 'bingo',
    title: 'Bingo',
    tagline: 'Call numbers, mark your card, race to spell B-I-N-G-O.',
    icon: '🎱',
    minPlayers: 2,
    maxPlayers: 8,
    accent: '#e8a15f',
    status: 'live',
  },
  {
    id: 'ludo',
    eventPrefix: 'ludo',
    title: 'Ludo',
    tagline: 'Four tokens, one home. The classic race around the board.',
    icon: '🎲',
    minPlayers: 2,
    maxPlayers: 4,
    accent: '#7fb2e5',
    status: 'live',
  },
  {
    id: 'chess',
    eventPrefix: 'chess',
    title: 'Chess',
    tagline: 'Slow, thoughtful, and quietly ruthless.',
    icon: '♟️',
    minPlayers: 2,
    maxPlayers: 2,
    accent: '#b0a2d8',
    status: 'live',
  },
  {
    id: 'tic-tac-toe',
    eventPrefix: 'ttt',
    title: 'Tic Tac Toe',
    tagline: 'Three in a row. Best of five, obviously.',
    icon: '⭕',
    minPlayers: 2,
    maxPlayers: 2,
    accent: '#e595b4',
    status: 'live',
  },
];

export const LIVE_GAMES = GAMES.filter((game) => game.status === 'live');

export function findGame(id) {
  return GAMES.find((game) => game.id === id) ?? null;
}
