/**
 * Player identity helpers shared by every game in the hub.
 *
 * Names, initials and token colours all live here so a new game gets the same
 * treatment for free — including the rule that at 15 players colour alone is
 * not enough to tell people apart, so every token also carries initials.
 */

export const NAME_MAX_LENGTH = 16;

/**
 * Fifteen tokens that stay distinguishable at a glance and are light enough to
 * carry dark initials (every one clears 5:1 against the token text colour —
 * an equal-lightness ramp would have failed in the blues, which read darker
 * than their lightness suggests).
 */
/**
 * Ordered so any prefix is spread around the colour wheel: a 3-player game
 * gets coral / green / lavender rather than three adjacent greens. Colours are
 * handed out in this order as players join.
 */
export const TOKEN_COLORS = [
  '#e17f7f', // coral
  '#62da62', // green
  '#a2a2ec', // lavender
  '#e1a67f', // apricot
  '#62da92', // mint
  '#bfa2ec', // violet
  '#dac262', // butter
  '#62dac2', // aqua
  '#dda2ec', // orchid
  '#c2da62', // lime
  '#62c2da', // sky
  '#e17fcd', // magenta
  '#92da62', // spring
  '#a2bfec', // periwinkle
  '#e17fa6', // rose
];

/** Fun defaults offered on the join screen. */
export const NAME_SUGGESTIONS = [
  'Lucky Ducky',
  'Ladder Legend',
  'Snake Charmer',
  'Coffee Break',
  'Dice Goblin',
  'Sir Slides-a-Lot',
  'Nearly There',
  'Desk Champion',
  'The Hopeful',
  'Chai Break',
];

/** Trim, collapse whitespace, strip control characters, and cap the length. */
export function sanitizeName(raw) {
  return String(raw ?? '')
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, NAME_MAX_LENGTH);
}

/**
 * Make a name unique inside a room by appending a number.
 * The spec asks for auto-append rather than an error: at 15 people a second
 * "Sam" is likely and shouldn't be a dead end.
 */
export function uniqueName(desired, taken) {
  const existing = new Set([...taken].map((n) => n.toLowerCase()));
  if (!existing.has(desired.toLowerCase())) return desired;

  for (let suffix = 2; suffix < 100; suffix++) {
    // Keep the result within the length cap even after the suffix.
    const tag = ` ${suffix}`;
    const base = desired.slice(0, NAME_MAX_LENGTH - tag.length);
    const candidate = `${base}${tag}`;
    if (!existing.has(candidate.toLowerCase())) return candidate;
  }
  return `${desired.slice(0, NAME_MAX_LENGTH - 5)} ${Date.now() % 1000}`;
}

/**
 * Up to two initials for the token face — "Priya Rao" → "PR", "Sam" → "SA".
 * Falls back gracefully for emoji or single-character names.
 */
export function initialsFor(name) {
  const words = String(name).trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return '??';

  if (words.length === 1) {
    const letters = [...words[0]];
    return (letters[0] + (letters[1] ?? '')).toUpperCase();
  }
  return ([...words[0]][0] + [...words[1]][0]).toUpperCase();
}

/** First colour nobody in the room is using; falls back to wrapping around. */
export function nextColor(takenColors) {
  const taken = new Set(takenColors);
  return TOKEN_COLORS.find((color) => !taken.has(color)) ?? TOKEN_COLORS[taken.size % TOKEN_COLORS.length];
}

/** Three distinct suggestions for the name field. */
export function suggestNames(count = 3) {
  const pool = [...NAME_SUGGESTIONS];
  const picks = [];
  while (picks.length < count && pool.length) {
    picks.push(...pool.splice(Math.floor(Math.random() * pool.length), 1));
  }
  return picks;
}
