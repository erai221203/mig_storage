/**
 * Generic room lifecycle, shared by every game in the hub.
 *
 * `BaseRoom` owns everything that is true of *any* multiplayer room — players,
 * seats, the host role, spectators, chat, reconnect grace and expiry — and
 * knows nothing about dice, boards or turns. A game subclasses it and adds only
 * its own rules (see `server/games/snake-and-ladder/room.js`).
 *
 * Broadcast policy
 * ----------------
 * Rooms emit a single `update` event when their state changes, and the socket
 * layer turns that into ONE broadcast to the whole room — not one message per
 * player. With 15 players that is the difference between 1 and 15 payloads per
 * change. Rapid changes are coalesced onto the next tick (see `scheduleUpdate`)
 * so a burst of fifteen simultaneous rolls still produces a single broadcast.
 */

import { EventEmitter } from 'node:events';
import { randomUUID } from 'node:crypto';

import { claimCode, releaseCode, normalize } from './codes.js';
import { initialsFor, nextColor, sanitizeName, uniqueName } from './players.js';

export const RoomState = {
  LOBBY: 'lobby',
  PLAYING: 'playing',
  ENDED: 'ended',
};

export const ROOM_DEFAULTS = {
  /** Rooms with no activity for this long are swept from memory. */
  INACTIVITY_MS: 60 * 60 * 1000, // 1 hour
  SWEEP_INTERVAL_MS: 5 * 60 * 1000,
  /** How long a seat is held after a disconnect. */
  RECONNECT_GRACE_PLAYING_MS: 5 * 60 * 1000,
  RECONNECT_GRACE_LOBBY_MS: 45 * 1000,
  /** Light chat rate limiting, per player. */
  CHAT_MIN_INTERVAL_MS: 400,
  CHAT_MAX_LENGTH: 140,
  CHAT_HISTORY: 60,
  /** Reactions are noisier than chat, so they get their own slower limit. */
  REACTION_MIN_INTERVAL_MS: 2000,
};

export class BaseRoom {
  /**
   * @param {object} options
   * @param {string} options.gameId   which game this room belongs to
   * @param {number} options.maxPlayers
   */
  constructor({ gameId, maxPlayers }) {
    this.id = randomUUID();
    this.gameId = gameId;
    this.code = claimCode(gameId, this.id);

    this.state = RoomState.LOBBY;
    this.players = [];
    this.spectators = [];
    this.chat = [];

    this.maxPlayers = maxPlayers;
    this.lastActivity = Date.now();

    this.events = new EventEmitter();
    this._updateScheduled = false;
    this._destroyed = false;
  }

  on(event, listener) {
    this.events.on(event, listener);
  }

  emit(event, payload) {
    if (!this._destroyed) this.events.emit(event, payload);
  }

  touch() {
    this.lastActivity = Date.now();
  }

  /**
   * Ask for a state broadcast. Multiple calls in the same tick collapse into
   * one — fifteen players rolling at once should not mean fifteen broadcasts.
   */
  scheduleUpdate() {
    this.touch();
    if (this._updateScheduled || this._destroyed) return;
    this._updateScheduled = true;
    queueMicrotask(() => {
      this._updateScheduled = false;
      if (!this._destroyed) this.events.emit('update', this);
    });
  }

  /** Force an immediate broadcast, for moments that must not be coalesced. */
  emitUpdateNow() {
    this.touch();
    if (!this._destroyed) this.events.emit('update', this);
  }

  // ── players ──────────────────────────────────────────────────────────────

  get connectedPlayers() {
    return this.players.filter((p) => p.connected);
  }

  get isFull() {
    return this.players.length >= this.maxPlayers;
  }

  get host() {
    return this.players.find((p) => p.isHost) ?? null;
  }

  getPlayer(playerId) {
    return this.players.find((p) => p.id === playerId) ?? null;
  }

  findByName(name) {
    const needle = String(name).toLowerCase();
    return this.players.find((p) => p.name.toLowerCase() === needle) ?? null;
  }

  /**
   * Seat a new player. Names are made unique by appending a number rather than
   * rejected — with a big group a second "Sam" is likely and shouldn't be a
   * dead end.
   */
  addPlayer(rawName, socketId) {
    const desired = sanitizeName(rawName) || 'Player';
    const name = uniqueName(desired, this.players.map((p) => p.name));

    const player = {
      id: randomUUID(),
      name,
      initials: initialsFor(name),
      color: nextColor(this.players.map((p) => p.color)),
      socketId,
      connected: true,
      isHost: this.players.length === 0,
      joinedAt: Date.now(),
      graceTimer: null,
      lastChatAt: 0,
      lastReactionAt: 0,
    };

    this.players.push(player);
    this.onPlayerAdded?.(player);
    this.touch();
    return player;
  }

  /** Watchers for a room that is already full. They can chat but not play. */
  addSpectator(rawName, socketId) {
    const desired = sanitizeName(rawName) || 'Watcher';
    const name = uniqueName(desired, [
      ...this.players.map((p) => p.name),
      ...this.spectators.map((s) => s.name),
    ]);

    const spectator = {
      id: randomUUID(),
      name,
      initials: initialsFor(name),
      color: '#b9adb4',
      socketId,
      connected: true,
      isSpectator: true,
      lastChatAt: 0,
      lastReactionAt: 0,
    };

    this.spectators.push(spectator);
    this.touch();
    return spectator;
  }

  /** Look up either a player or a spectator by id. */
  getMember(memberId) {
    return (
      this.players.find((p) => p.id === memberId) ??
      this.spectators.find((s) => s.id === memberId) ??
      null
    );
  }

  removePlayer(playerId) {
    const index = this.players.findIndex((p) => p.id === playerId);
    if (index !== -1) {
      const [player] = this.players.splice(index, 1);
      if (player.graceTimer) clearTimeout(player.graceTimer);
      if (player.isHost) this.promoteNewHost();
      this.onPlayerRemoved?.(player, index);
      this.touch();
      return;
    }

    const spectatorIndex = this.spectators.findIndex((s) => s.id === playerId);
    if (spectatorIndex !== -1) {
      this.spectators.splice(spectatorIndex, 1);
      this.touch();
    }
  }

  /**
   * Hold the seat for a grace period so a dropped player keeps their place,
   * but move host duties (and anything game-specific) on immediately so the
   * room is never stuck waiting for someone who left.
   */
  handleDisconnect(memberId) {
    const spectator = this.spectators.find((s) => s.id === memberId);
    if (spectator) {
      this.removePlayer(memberId);
      this.scheduleUpdate();
      return;
    }

    const player = this.getPlayer(memberId);
    if (!player) return;

    player.connected = false;
    player.socketId = null;

    if (player.isHost) this.promoteNewHost();
    this.onPlayerDisconnected?.(player);

    const graceMs =
      this.state === RoomState.LOBBY
        ? ROOM_DEFAULTS.RECONNECT_GRACE_LOBBY_MS
        : ROOM_DEFAULTS.RECONNECT_GRACE_PLAYING_MS;

    if (player.graceTimer) clearTimeout(player.graceTimer);
    player.graceTimer = setTimeout(() => {
      player.graceTimer = null;
      this.removePlayer(player.id);
      this.scheduleUpdate();
    }, graceMs);
    player.graceTimer.unref?.();

    this.scheduleUpdate();
  }

  reconnectPlayer(player, socketId) {
    if (player.graceTimer) {
      clearTimeout(player.graceTimer);
      player.graceTimer = null;
    }
    player.connected = true;
    player.socketId = socketId;
    this.onPlayerReconnected?.(player);
    this.touch();
  }

  /** Prefers a connected player; falls back to anyone still holding a seat. */
  promoteNewHost() {
    for (const p of this.players) p.isHost = false;
    const next = this.players.find((p) => p.connected) ?? this.players[0];
    if (next) next.isHost = true;
    return next ?? null;
  }

  // ── chat & reactions ─────────────────────────────────────────────────────

  addChatMessage(member, text) {
    const now = Date.now();
    if (now - member.lastChatAt < ROOM_DEFAULTS.CHAT_MIN_INTERVAL_MS) {
      return { ok: false, message: 'Slow down a touch 🙂' };
    }

    const clean = String(text ?? '')
      .replace(/[\u0000-\u001F\u007F]/g, '') // strip control characters
      .trim()
      .slice(0, ROOM_DEFAULTS.CHAT_MAX_LENGTH);
    if (!clean) return { ok: false };

    member.lastChatAt = now;
    const message = {
      id: randomUUID(),
      playerId: member.id,
      name: member.name,
      color: member.color,
      text: clean,
      at: now,
    };

    this.chat.push(message);
    if (this.chat.length > ROOM_DEFAULTS.CHAT_HISTORY) {
      this.chat = this.chat.slice(-ROOM_DEFAULTS.CHAT_HISTORY);
    }
    this.touch();
    return { ok: true, message };
  }

  /**
   * Reactions are rate limited harder than chat: with 15 players a shared
   * screen fills up fast, so it's one per player every two seconds.
   */
  canReact(member) {
    const now = Date.now();
    if (now - member.lastReactionAt < ROOM_DEFAULTS.REACTION_MIN_INTERVAL_MS) return false;
    member.lastReactionAt = now;
    return true;
  }

  // ── serialization ────────────────────────────────────────────────────────

  /** The parts of a room every game shares. Subclasses spread this. */
  baseState() {
    return {
      code: this.code,
      gameId: this.gameId,
      state: this.state,
      maxPlayers: this.maxPlayers,
      hostId: this.host?.id ?? null,
      players: this.players.map((p) => ({
        id: p.id,
        name: p.name,
        initials: p.initials,
        color: p.color,
        connected: p.connected,
        isHost: p.isHost,
      })),
      spectators: this.spectators.map((s) => ({
        id: s.id,
        name: s.name,
        initials: s.initials,
      })),
    };
  }

  destroy() {
    this._destroyed = true;
    for (const player of this.players) {
      if (player.graceTimer) clearTimeout(player.graceTimer);
    }
    this.onDestroy?.();
    releaseCode(this.code);
    this.events.removeAllListeners();
  }
}

/**
 * Holds every room for one game, plus the janitor that clears out abandoned
 * ones so a long-running server doesn't leak.
 */
export class RoomStore {
  /** @param {(options: object) => BaseRoom} createRoom */
  constructor(createRoom) {
    this.createRoom = createRoom;
    this.rooms = new Map(); // code → room
    this._sweeper = setInterval(() => this.sweep(), ROOM_DEFAULTS.SWEEP_INTERVAL_MS);
    this._sweeper.unref?.();
  }

  create(options) {
    const room = this.createRoom(options);
    this.rooms.set(room.code, room);
    return room;
  }

  get(code) {
    return this.rooms.get(normalize(code)) ?? null;
  }

  delete(code) {
    const room = this.rooms.get(normalize(code));
    if (!room) return;
    room.destroy();
    this.rooms.delete(normalize(code));
  }

  /** Drop rooms that are empty or idle past the inactivity window. */
  sweep() {
    const now = Date.now();
    for (const [code, room] of this.rooms) {
      const idle = now - room.lastActivity > ROOM_DEFAULTS.INACTIVITY_MS;
      const abandoned = room.players.length === 0 && room.spectators.length === 0;
      if (idle || abandoned) this.delete(code);
    }
  }

  get size() {
    return this.rooms.size;
  }
}
