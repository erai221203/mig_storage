/**
 * Room codes, unique across every game in the hub.
 *
 * A single registry owns all codes, so a code can never collide between two
 * games — and, just as importantly, a player who types a code can be routed to
 * the right game without knowing which one it belongs to. That lookup is what
 * `GET /api/rooms/:code` and the join flow are built on.
 */

/** Excludes 0/O/1/I/L so nobody mistypes a code read out over a call. */
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const CODE_LENGTH = 5;

/** code → { gameId, roomId } */
const registry = new Map();

function randomCode() {
  let code = '';
  for (let i = 0; i < CODE_LENGTH; i++) {
    code += ALPHABET[Math.floor(Math.random() * ALPHABET.length)];
  }
  return code;
}

/** Codes are case-insensitive and tolerant of stray whitespace when shared. */
export function normalize(code) {
  return String(code ?? '').trim().toUpperCase();
}

/**
 * Reserve a fresh code for a room. Retries on the (very unlikely) collision
 * rather than risk pointing two rooms at the same code.
 */
export function claimCode(gameId, roomId) {
  for (let attempt = 0; attempt < 100; attempt++) {
    const code = randomCode();
    if (!registry.has(code)) {
      registry.set(code, { gameId, roomId });
      return code;
    }
  }
  // Pathological fallback: guaranteed unique, just longer.
  const code = `${Date.now().toString(36).toUpperCase()}`;
  registry.set(code, { gameId, roomId });
  return code;
}

/** Which game (and room) does this code belong to? */
export function lookupCode(code) {
  return registry.get(normalize(code)) ?? null;
}

export function releaseCode(code) {
  registry.delete(normalize(code));
}

export function codeCount() {
  return registry.size;
}
