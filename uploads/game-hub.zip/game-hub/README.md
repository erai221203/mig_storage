# 🎲 Games Hub

A cozy multiplayer game hub for remote coworkers. One landing page, one server,
one port — every game lives in its own folder and plugs into the same lobby,
chat, reactions and theme.

**Five games, all playable**

| Game | Players | What it is |
| --- | --- | --- |
| 🐍 **Snake & Ladder** | 2–15 | Three modes, including a Race mode where everyone rolls at once |
| 🎱 **Bingo** | 2–8 | The 1–25 grid variant — take turns calling, race to spell B-I-N-G-O |
| 🎲 **Ludo** | 2–4 | Four tokens each, captures, home columns, exact finish |
| ♟️ **Chess** | 2 + spectators | Full rules, optional clock, legal-move hints |
| ⭕ **Tic Tac Toe** | 2 + spectators | Best-of-five, alternating who opens |

---

## Quick start

```bash
npm install
npm start
```

Then open **http://localhost:3000** — it opens on the shared landing page.

No build step, no database, no API keys. The client is plain HTML/CSS/ES modules
served straight from `client/`, so `npm start` really is all it takes.

> **Requires Node 18+.** (Developed on Node 26.)

### Try it solo first

Open the hub in several browser tabs. Each tab is its own player — the session
lives in `sessionStorage`, so tabs don't share an identity. Create a room in one
tab, then join with the code from the others.

---

## Playing with people who aren't on your machine

`localhost` only works for you, so expose the port one of two ways.

### Option A — a quick tunnel (best for a one-off game)

```bash
ngrok http 3000                                    # needs a free account
cloudflared tunnel --url http://localhost:3000     # no account
npx localtunnel --port 3000                        # no account
```

Send the public URL round and everyone joins with the same room code.
WebSockets work through all three out of the box.

### Option B — deploy it (best if you'll play regularly)

Any host that runs Node and supports WebSockets. It reads `process.env.PORT`, so
no config changes are needed.

**Render** (free tier)
1. Push this folder to a GitHub repo.
2. New → **Web Service** → connect the repo.
3. Build command `npm install`, start command `npm start`.
4. Deploy and share the `…onrender.com` URL.

**Railway / Fly.io / Heroku** — same idea. There's a health check at `/healthz`.

> ⚠️ Free tiers sleep after inactivity, and all state is in memory, so a sleeping
> instance forgets open rooms. Fine for break-time games — just make a new room.

---

## The flow

```
Landing page (all games)
        │  click a game
        ▼
Player count & mode          ← creator picks 2–15 players and a mode
        │  Create room
        ▼
Lobby (code, players, rules) ← others join with the code
        │  Start game
        ▼
Game  ──────────────────────► Victory screen → Rematch / Back to Games
```

Anyone with a room code can skip straight to **Join a room** from the landing
page. Codes are unique across *every* game in the hub, so a code alone is enough
to route a player to the right game — they never have to know which one it was.

"← Games" is available in the lobby and during a game; leaving mid-game asks for
confirmation first.

---

## Snake & Ladder

The classic 100-square board, numbered 1–100 in the traditional bottom-left
zig-zag, with 9 ladders up and 10 snakes down.

### The three modes

| Mode | Best for | How it plays |
| --- | --- | --- |
| **Classic** | 2–4 players | One player rolls at a time. A 6 earns another go. A turn timer (10/20/30s, default 20) auto-rolls if someone's away. |
| **Race** | 5–15 players | Every round, **everyone rolls at once** inside a 10-second window, then all tokens move together. Nobody ever waits for someone else's turn. |
| **Team** | Big groups | 2–4 teams share one token each. Race-style rounds, with one member per team rolling — rotating automatically through the roster. |

The setup screen recommends a mode based on the player count you pick.

### Shared rules

- Ladder foot → climbs to its top. Snake head → slides to its tail.
- **Exact finish** (default on): you need the exact roll to land on 100;
  overshooting keeps you where you are.
- **Need a 6 to start** (default off, so games start fast).
- **Play until**: first home / top 3 (default) / everyone. The host can also end
  a game early at any point — everyone still on the board is ranked by how far
  they got.
- Dice are generated **on the server**. The client never sends a roll, only "I'd
  like to roll", so a modified client can't cheat.

### Built for a full room of 15

- Tokens are a colour **plus initials** ("PR" for Priya) — at 15 players colour
  alone stops being enough. The 15 colours are ordered so that any smaller game
  still gets well-separated ones.
- Crowded squares cluster tokens tightly and collapse past three into a **"+n"**
  badge; tap it to fan them out.
- Tap any name in the leaderboard to make that token **pulse** on the board.
- The leaderboard reorders with a smooth slide each round.
- On phones the sidebar becomes a **swipe-up drawer** so the board stays full size.
- Reactions (😂 🐍 🪜 😭 🎉) float up briefly and are rate-limited to one per
  player every 2 seconds, so fifteen people can't bury the board.

---

## Bingo

The 1–25 grid variant, not the 75-ball hall version. Every player's card holds
**all** the numbers 1–25 in their own random arrangement, so nobody has a number
the others lack — the luck is entirely in the layout.

- Players take turns calling. On your turn, tap any un-called number on your own
  card; that calls it for the room and marks it for you.
- Everyone else finds that number on their card and taps it. You can only mark
  numbers that have genuinely been called.
- Each full row, column or diagonal earns a letter of **B-I-N-G-O**. Five lines
  spells it — hit the BINGO! button to claim, and the server checks it.
- A turn timer (off / 15s / 30s) auto-calls for anyone who wanders off.

There's no separate "all numbers" board: your own card already holds every
number, so it *is* the board. A called number you haven't marked is ringed in
its colour.

## Ludo

The classic cross board: four tokens each, out of the yard on a 6, round the
track and up your own home column.

- **A 6 gets you out** of the yard — and earns another roll.
- **Landing on an opponent** sends their token home, unless the square is a
  star. Capturing earns another roll too.
- **Getting a token home** needs an exact roll, and also earns another roll.
- **Three sixes in a row forfeits the turn**, so nobody can hog the dice.
- Get all four tokens home to win. The rest are ranked by how far they got.
- A turn timer (off / 15s / 30s) auto-plays for anyone who wanders off, and it
  picks a sensible move — capture, then get home, then leave the yard.

> **On the lap length:** the perimeter of a cross on a 15×15 grid is 56 squares,
> not the 52 often quoted. Using 56 (14 per quadrant) keeps every consecutive
> pair of squares orthogonally adjacent, so tokens hop cleanly instead of
> cutting diagonally across a corner. `validateBoard()` enforces that adjacency
> at boot, along with each colour's home column joining its track exit.

## Chess

Full rules, for two players with spectators welcome.

- Click a piece to see **exactly where it may legally go** — dots for quiet
  moves, rings for captures. The hints come from the server, so they can never
  disagree with what's allowed.
- Castling, en passant, promotion (with a piece picker), check, checkmate,
  stalemate, the fifty-move rule, insufficient material and threefold
  repetition are all handled.
- Optional clock (none / 5 / 10 / 30 minutes) with a 5-second increment.
- Offer a draw or resign; a rematch swaps colours.
- Black's board is flipped, so both players look at it from their own side.

> **Correctness:** the move generator is verified with **perft** — counting the
> leaf nodes at each depth from known positions and comparing against the
> published totals. It matches exactly at every depth tested, including the
> `Kiwipete` position that is dense with castling, en passant and pins. That's
> the standard way to prove a chess move generator is exactly right rather than
> approximately right. Run it with `npm run test:chess`.

## Tic Tac Toe

Two players, best-of-five by default (host can set 1–4 wins). A third arrival
becomes a spectator and watches live.

- X and O are fixed for the match; **who opens alternates each game**, so X
  isn't a standing advantage.
- A move timer (off / 10s / 20s) plays for you if you stall — and it plays a
  *sensible* move (win if it can, block if it must, else centre/corner) rather
  than a random one, so a timeout doesn't hand the game away.

---

## Project structure

```
game-hub/
├── server/
│   ├── index.js                    Express + Socket.IO, one port, the API
│   ├── shared/                     Reusable across every game
│   │   ├── room-manager.js           BaseRoom + RoomStore: players, host,
│   │   │                             spectators, chat, reconnect, expiry
│   │   ├── codes.js                  hub-wide unique room codes
│   │   └── players.js                names, initials, token colours
│   └── games/
│       ├── registry.js             ⚙️  THE GAME CATALOGUE — add a game here
│       ├── snake-and-ladder/
│       │   ├── index.js              Socket.IO namespace + handlers
│       │   ├── config.js           ⚙️  snakes, ladders, modes, timers, rules
│       │   ├── game.js               pure rules: geometry, dice, movement
│       │   └── room.js               room state, turns, rounds, timers
│       ├── bingo/                    same four-file shape
│       ├── ludo/                     same four-file shape
│       ├── chess/                    same four-file shape
│       └── tic-tac-toe/              same four-file shape
├── client/
│   ├── index.html                  the single page
│   ├── landing/                    the hub: game cards, setup, join
│   ├── shared/                     router, net, UI kit, lobby, chat, effects
│   │   └── theme.css               🎨 all colours and shapes
│   └── games/
│       ├── snake-and-ladder/         board.js, snl.js, snl.css
│       ├── bingo/                    bingo.js, bingo.css
│       ├── ludo/                     ludo.js, ludo.css
│       ├── chess/                    chess.js, chess.css
│       └── tic-tac-toe/              tic-tac-toe.js, tic-tac-toe.css
├── test/
│   ├── smoke.mjs                   rules + full socket integration
│   ├── chess-perft.mjs             chess move generation vs published counts
│   └── load-15.mjs                 a whole 15-player game, with metrics
└── package.json
```

### Design notes worth knowing

- **One namespace per game.** Snake & Ladder lives on `/snake-and-ladder`, so
  event names can never collide between games and a client only receives traffic
  for the game it's actually in.
- **One broadcast, not one per player.** Nothing in Snake & Ladder is private —
  all positions are public — so a state change goes out as a single
  `snl:state` to the room. `BaseRoom.scheduleUpdate()` also coalesces bursts onto
  the next tick, so fifteen simultaneous rolls still produce one broadcast.
  Measured at 15 players: **1.0 results broadcast and ~2.2 state broadcasts per
  round**, with roll pings scaling linearly, not quadratically.
- **The server is the referee.** It owns the dice, the turn order and the round
  clock. The client renders and animates; it decides nothing.
- **A token never moves until its die has stopped.** The die spins, lands on the
  number the server rolled, and is held long enough to read — only then does the
  token walk, one hop per pip. The server's animation budget is the sum of the
  two phases (`DICE_REVEAL_MS + MOVE_MS`) so the next round can't open early.
- **Players are identified by a server-issued id** kept in `sessionStorage`, not
  by socket id (which changes on reconnect). That's what makes refreshes and
  flaky wifi invisible.
- **Rooms are in memory only**, swept when empty or after an hour idle.

---

## How to add a new game to the hub

Adding **Tic Tac Toe** end to end, as an example.

### 1. Announce it — one entry

`server/games/registry.js`:

```js
{
  id: 'tic-tac-toe',
  title: 'Tic Tac Toe',
  tagline: 'Three in a row. Best of five, obviously.',
  icon: '⭕',
  minPlayers: 2,
  maxPlayers: 2,
  accent: '#e595b4',
  status: 'live',        // 'coming-soon' renders a placeholder card and stops here
}
```

A `coming-soon` entry needs nothing else — you're done. For a playable game,
carry on.

### 2. Server: rules, room, handlers

Create `server/games/tic-tac-toe/`:

- **`config.js`** — the board, win lines, timers, and a `clientConfig()` that
  returns whatever the client needs to draw it.
- **`game.js`** — pure functions. Keep all rules here; it makes them testable
  without a socket.
- **`room.js`** — `export class TicTacToeRoom extends BaseRoom`. You inherit
  players, host transfer, spectators, chat, reactions, reconnect grace and
  expiry. Add only your own state, and implement `publicState()`:

  ```js
  publicState() {
    return { ...this.baseState(), board: this.board, turn: this.turnId };
  }
  ```

  Optional hooks fire automatically: `onPlayerAdded`, `onPlayerRemoved`,
  `onPlayerDisconnected`, `onPlayerReconnected`, `onDestroy`.

- **`index.js`** — mirror `snake-and-ladder/index.js`:

  ```js
  export const gameId = 'tic-tac-toe';
  export const rooms = new RoomStore((options) => new TicTacToeRoom(options));

  export function register(io) {
    const namespace = io.of(`/${gameId}`);
    namespace.on('connection', (socket) => { /* ttt:create, ttt:join, ttt:move … */ });
  }
  ```

  Prefix your events (`ttt:`) and always broadcast state with **one**
  `namespace.to(room.code).emit(...)`.

### 3. Register it on the server

`server/index.js` — two lines:

```js
import * as ticTacToe from './games/tic-tac-toe/index.js';

const PLAYABLE = [snakeAndLadder, ticTacToe];
const GAME_CONFIGS = { 'snake-and-ladder': snlClientConfig, 'tic-tac-toe': tttClientConfig };
```

### 4. Client: one mount function

Create `client/games/tic-tac-toe/tic-tac-toe.js` exporting:

```js
export async function mount({ root, code, intent, name }) { … }
```

Reuse the shared kit — `el`, `render`, `toast`, `confirmDialog`, `playerGrid`,
`chatPanel`, `tokenFace` from `client/shared/ui.js`, plus `confetti`, `sound`
and `floatReaction` from `effects.js`. Your game inherits the whole look.

### 5. Point the router at it

`client/shared/app.js` — one line:

```js
const GAME_MOUNTS = {
  'snake-and-ladder': () => import('../games/snake-and-ladder/snl.js'),
  'tic-tac-toe': () => import('../games/tic-tac-toe/tic-tac-toe.js'),
};
```

Add `<link rel="stylesheet" href="/games/tic-tac-toe/tic-tac-toe.css" />` to
`client/index.html` and you're done. Room codes, join-by-code routing, the
landing card, lobby, chat and reactions all work already.

---

## Customizing

### Snakes and ladders

`server/games/snake-and-ladder/config.js`:

```js
export const LADDERS = { 1: 38, 4: 14, 9: 31, /* … */ 80: 100 };
export const SNAKES  = { 16: 6, 47: 26, 49: 11, /* … */ 98: 78 };
```

Keys are the square you land on, values where you end up. The board **redraws
itself** from these — the client fetches them, so the artwork can never disagree
with the rules. `validateBoard()` runs at boot and refuses to start on an
impossible board (a snake that goes up, a ladder onto another ladder, a snake
head on square 100, …), so a typo fails loudly instead of mid-game.

### Player counts, modes and timers

Same file:

```js
export const PLAYER_LIMITS = { MIN: 2, MAX: 15, DEFAULT: 4, MIN_TO_START: 2 };

export const RULES = {
  EXTRA_TURN_ON_SIX: true,
  EXACT_FINISH: true,
  NEED_SIX_TO_START: false,
  FINISH_MODE: 'podium',        // 'first' | 'podium' | 'all'
};

export const TIMING = {
  TURN_SECONDS_OPTIONS: [10, 20, 30],   // Classic mode; lobby buttons follow
  TURN_SECONDS_DEFAULT: 20,
  ROUND_WINDOW_MS: 10_000,              // Race/Team roll window
  DICE_REVEAL_MS: 1_250,                // die spins, lands, and is held
  MOVE_MS: 3_000,                       // budget for the tokens themselves
  ANIMATION_MS: 4_250,                  // = reveal + move
  ROUND_GAP_MS: 700,
  START_DELAY_MS: 2_000,
};

export const TEAMS = { MIN: 2, MAX: 4, DEFAULT: 2, PRESETS: [ /* names, colours */ ] };
```

Raising `PLAYER_LIMITS.MAX` past 15 also means adding entries to `TOKEN_COLORS`
in `server/shared/players.js` so everyone keeps a distinct token.

Room lifetimes live in `server/shared/room-manager.js` (`ROOM_DEFAULTS`):
reconnect grace, idle expiry, chat and reaction rate limits.

### Theme colours

Everything visual comes from the `:root` block at the top of
`client/shared/theme.css`. Change it once and the hub and every game follow:

```css
:root {
  --bg: #fdf8f2;          /* page background */
  --surface: #ffffff;     /* panels */
  --ink: #38303a;         /* main text */
  --primary: #b8503f;     /* buttons, focus rings */
  --accent: #6bbf8a;      /* the hub's "go" green */
  --on-accent: #33292f;   /* text drawn ON a pastel accent or token */
}
```

Two things to keep in mind if you reskin it:

- **`--primary` and `--accent-strong` carry white label text.** Keep them dark
  enough to stay readable — aim for 4.5:1 against white.
- **Token colours carry `--on-accent` (dark ink), not white.** That's why they
  can stay soft: dark ink on them reaches ~5:1, whereas white would only manage
  ~2.4:1. If you switch to dark tokens, set `--on-accent` to `#ffffff`.

Per-game colours (the board's square tints, snake hues, ladder wood) are in
`client/games/snake-and-ladder/snl.css`.

---

## Tests

```bash
npm test            # game rules + socket integration + chess perft
npm run test:chess  # just the chess move generator
npm run test:load   # a whole 15-player Snake & Ladder game, with metrics
```

`smoke.mjs` checks the pure rules with fixed dice — board geometry, ladders,
snakes, exact finish, need-a-six, and an exhaustive sweep proving a token lands
**exactly `die` squares along and animates exactly one hop per pip** from every
square for every roll. It then drives the real server through all three modes,
joining rules, spectators, turn enforcement, host transfer, chat, reaction rate
limits and reconnects, and verifies the hub catalogue agrees with what the
server can actually serve.

`chess-perft.mjs` counts move-generation nodes against published totals from
four positions, then checks castling, en passant, promotion, pins, mate,
stalemate, the draw rules and algebraic notation individually.

`load-15.mjs` plays a full 15-player game and reports round times and broadcast
counts. On a laptop it reports a **median round of ~8ms** server-side (the window
closes as soon as everyone has rolled) against the 15-second budget, and
**exactly one results broadcast per round**.

### A note on modals

The game-over card attaches to `document.body`, not `#app`, so it can sit above
the board. That means the router — which only replaces `#app` — will not sweep
it away on navigation. `gameOverModal()` in `client/shared/ui.js` registers every
open card, and `dismissOverlays()` is wired to the router's `onNavigate` hook, so
a card can never outlive the screen it belongs to. Every card also has a close
button, a backdrop click and Escape, so it can never become a trap.

### A note on shared CSS

Every game's stylesheet is loaded on every page, so two games defining the same
class name would silently fight — and the one loaded last would win. Anything
genuinely shared (the die, the turn timer, the roll button, leaderboard rows)
lives in `client/shared/components.css`; anything game-specific stays in that
game's own file and is scoped. If you add a game, keep its selectors prefixed
(`.chess-square`, `.ludo-token`) rather than generic.

---

## Troubleshooting

**Port 3000 is taken** — `PORT=4000 npm start`.

**No sound** — browsers block audio until you interact with the page; the first
click unlocks it. There's a 🔊 toggle in the game's top bar.

**"That room is full"** — you're offered a spectator seat instead: you can watch
and chat, just not roll.

**A tunnel URL loads but the game never connects** — check the tunnel forwards to
the port the server logged, and that it allows WebSockets.

---

Have a good break 🎲
